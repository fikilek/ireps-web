/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
} from "firebase/firestore";

import { db } from "../../firebase";
import { useGetAvailableTeamsQuery } from "../../redux/teamsApi";
import { useGetAvailableServiceProvidersQuery } from "../../redux/serviceProvidersApi";
import { useGetUsersDirectoryQuery } from "../../redux/usersApi";
import {
  formatDateTime,
  formatNumber,
} from "./targeted-batches/targetedBatchUtils";
import {
  Badge,
  InfoCard,
  SummaryDetailRow,
} from "./targeted-batches/allocation/TargetedBatchAllocationPrimitives";
import styles from "./targeted-batches/allocation/targetedBatchAllocationStyles";
import {
  asArray,
  buildTargetPayload,
  buildUsersById,
  canAllocateRow,
  enrichServiceProvidersWithMembers,
  enrichTeamsWithMembers,
  getBackendAllocation,
  getProposedTrnType,
  getRowKey,
  getRowOutcome,
  getTargetLabel,
  getTargetOptionMicroText,
  getTargetOptionSubtitle,
  getTbRowId,
  getUserDisplayName,
  getUserRoleLabel,
  valueOrNav,
} from "./targeted-batches/allocation/targetedBatchAllocationUtils";

function timestampToIso(value) {
  if (!value) return null;
  if (typeof value === "string") return value;
  if (typeof value?.toDate === "function") return value.toDate().toISOString();
  if (typeof value?.seconds === "number") {
    return new Date(value.seconds * 1000).toISOString();
  }
  return null;
}

function mapPermanentTbRow(rowDoc) {
  const data = rowDoc.data() || {};
  const meterId = data?.refs?.meterId || null;
  const backendAllocation = data?.allocation || {};

  return {
    ...data,
    id: rowDoc.id,
    tbRowId: rowDoc.id,
    uploadRowId: rowDoc.id,
    rowNo: data.rowNo,
    salesAllMeterId: data.salesAllMeterId,
    sourceSalesAllMeterId: data.salesAllMeterId,
    rowDecision: data?.decision?.status || "ACCEPT",
    assessmentDecision: data?.decision?.status || "ACCEPT",
    meterNo: data?.meter?.numberRaw || data?.meter?.numberNormalized || "",
    meterNoNormalized: data?.meter?.numberNormalized || "",
    accountNumber: data?.customer?.accountNumber || "",
    customerName: data?.customer?.customerName || "",
    addressLine1: data?.location?.addressLine1 || "",
    town: data?.location?.town || "",
    standNumber: data?.location?.sgCode || "",
    wardNumberLabel: data?.location?.wardNumberLabel || "",
    wardNumbers: Array.isArray(data?.location?.wardNumbers)
      ? data.location.wardNumbers
      : [],
    actionReason: data?.selection?.actionReason || "",
    totalSalesC: Number(data?.salesSnapshot?.totalSalesC || 0),
    latestMonthSalesC: Number(data?.salesSnapshot?.latestMonthSalesC || 0),
    sales3MonthsC: Number(data?.salesSnapshot?.sales3MonthsC || 0),
    sales6MonthsC: Number(data?.salesSnapshot?.sales6MonthsC || 0),
    sales12MonthsC: Number(data?.salesSnapshot?.sales12MonthsC || 0),
    monthsWithoutSales: Number(data?.salesSnapshot?.monthsWithoutSales || 0),
    lastPositiveSalesMonth:
      data?.salesSnapshot?.lastPositiveSalesMonth || null,
    monthlySalesC: { ...(data?.salesSnapshot?.monthlySalesC || {}) },
    monthlyUnits: { ...(data?.salesSnapshot?.monthlyUnits || {}) },
    astId: meterId,
    astMatchStatus: meterId ? "MATCHED" : "NOT_MATCHED",
    proposedTrnType: meterId ? "METER_INSPECTION" : "METER_DISCOVERY",
    allocation: {
      ...backendAllocation,
      source:
        backendAllocation?.targetId &&
        backendAllocation?.status === "ALLOCATED"
          ? "BACKEND"
          : backendAllocation?.source,
    },
    confirmedAt: timestampToIso(data?.metadata?.createdAt),
  };
}

function getTargetMembers(target = {}) {
  return asArray(target.members);
}

function MembersList({ target, maxItems = 4 }) {
  const members = getTargetMembers(target);

  if (members.length === 0) {
    return (
      <div style={styles.memberEmpty}>
        {target.type === "TEAM"
          ? "No team members resolved yet."
          : "No SP members resolved yet."}
      </div>
    );
  }

  const visibleMembers = members.slice(0, maxItems);
  const hiddenCount = Math.max(members.length - visibleMembers.length, 0);

  return (
    <div style={styles.memberList}>
      {visibleMembers.map((member) => (
        <span
          key={member.id || member.uid || getUserDisplayName(member)}
          style={{
            ...styles.memberChip,
            ...(member.missing ? styles.memberChipWarning : null),
          }}
          title={getUserRoleLabel(member)}
        >
          <strong>{getUserDisplayName(member)}</strong>
          <small>{getUserRoleLabel(member)}</small>
        </span>
      ))}

      {hiddenCount > 0 ? (
        <span style={styles.memberMore}>+{hiddenCount} more</span>
      ) : null}
    </div>
  );
}

function getRowAddress(row = {}) {
  return [row.addressLine1, row.town].filter(Boolean).join(" • ") || "NAv";
}

function getRowWard(row = {}) {
  return row.wardNumberLabel || asArray(row.wardNumbers)[0] || "NAv";
}

function getAssignmentStatus(row, allocation) {
  if (allocation?.source === "BACKEND") {
    return {
      label: "ALLOCATED",
      tone: "success",
      editable: false,
    };
  }

  if (allocation?.id) {
    return {
      label: "ASSIGNED",
      tone: "info",
      editable: true,
    };
  }

  if (!canAllocateRow(row, "PREPAID_SALES")) {
    return {
      label: "LOCKED",
      tone: "neutral",
      editable: false,
    };
  }

  return {
    label: "WAITING",
    tone: "warning",
    editable: true,
  };
}

function AllocationCell({ allocation }) {
  if (!allocation?.id) {
    return (
      <div style={styles.allocationCell}>
        <Badge tone="warning">NOT ALLOCATED</Badge>
        <span style={styles.memberEmpty}>No TEAM/SP assigned</span>
      </div>
    );
  }

  return (
    <div style={styles.allocationCell}>
      <Badge tone="success">ALLOCATED</Badge>
      <span
        style={{
          ...styles.allocationTargetPill,
          ...(allocation.type === "TEAM"
            ? styles.allocationTargetPillTeam
            : styles.allocationTargetPillSp),
        }}
      >
        {getTargetLabel(allocation)}
      </span>
    </div>
  );
}

function Th({ children }) {
  return <th style={styles.th}>{children}</th>;
}

function Td({ children, strong = false }) {
  return (
    <td style={{ ...styles.td, ...(strong ? styles.strongCell : null) }}>
      {children}
    </td>
  );
}

export default function TargetedBatchAllocationPage() {
  const { tbId } = useParams();

  const [batch, setBatch] = useState(null);
  const [permanentRows, setPermanentRows] = useState([]);
  const [isBatchLoading, setIsBatchLoading] = useState(true);
  const [batchLoadError, setBatchLoadError] = useState("");
  const [plannedAllocationsByRowId, setPlannedAllocationsByRowId] = useState({});

  const [targetType, setTargetType] = useState("TEAM");
  const [targetId, setTargetId] = useState("");
  const [dragTarget, setDragTarget] = useState(null);
  const [dragOverRowId, setDragOverRowId] = useState(null);
  const [selectedTbRowId, setSelectedTbRowId] = useState(null);
  const [statusMessage, setStatusMessage] = useState("");

  const decodedTbId = decodeURIComponent(tbId || "");

  useEffect(() => {
    let active = true;

    async function loadPermanentTargetedBatch() {
      setIsBatchLoading(true);
      setBatchLoadError("");
      setBatch(null);
      setPermanentRows([]);
      setPlannedAllocationsByRowId({});
      setSelectedTbRowId(null);
      setStatusMessage("");

      if (!decodedTbId) {
        setBatchLoadError("The Targeted Batch ID is missing from the route.");
        setIsBatchLoading(false);
        return;
      }

      try {
        const parentRef = doc(db, "tb_uploads", decodedTbId);
        const rowsQuery = query(
          collection(db, "tb_rows"),
          where("tbId", "==", decodedTbId),
        );

        const [parentSnapshot, rowsSnapshot] = await Promise.all([
          getDoc(parentRef),
          getDocs(rowsQuery),
        ]);

        if (!active) return;

        if (!parentSnapshot.exists()) {
          setBatchLoadError(
            `Permanent Targeted Batch ${decodedTbId} was not found.`,
          );
          return;
        }

        const permanentBatch = {
          ...parentSnapshot.data(),
          id: parentSnapshot.id,
        };
        const loadedRows = rowsSnapshot.docs
          .map(mapPermanentTbRow)
          .sort((left, right) => Number(left.rowNo) - Number(right.rowNo));

        setBatch(permanentBatch);
        setPermanentRows(loadedRows);
      } catch (error) {
        if (!active) return;
        setBatchLoadError(
          error?.message ||
            "The permanent Targeted Batch could not be loaded from Firestore.",
        );
      } finally {
        if (active) setIsBatchLoading(false);
      }
    }

    loadPermanentTargetedBatch();

    return () => {
      active = false;
    };
  }, [decodedTbId]);

  const sourceType = batch?.source?.type || "";
  const isSalesSource = sourceType === "PREPAID_SALES";
  const isConfirmed = batch?.creation?.state === "READY";

  const rows = useMemo(
    () =>
      permanentRows.map((row, index) => ({
        ...row,
        _rowKey: getRowKey(row, index, batch?.id || decodedTbId),
        _rowOutcome: getRowOutcome(row, sourceType),
        _backendAllocation: getBackendAllocation(row),
      })),
    [batch?.id, decodedTbId, permanentRows, sourceType],
  );

  const readyRows = useMemo(
    () => rows.filter((row) => row._rowOutcome === "ACCEPT"),
    [rows],
  );

  const allocationsByRowId = useMemo(() => {
    const result = { ...plannedAllocationsByRowId };

    readyRows.forEach((row) => {
      if (row._backendAllocation?.id) {
        result[row._rowKey] = row._backendAllocation;
      }
    });

    return result;
  }, [plannedAllocationsByRowId, readyRows]);

  const {
    data: availableTeams = [],
    isLoading: areTeamsLoading,
    isError: areTeamsError,
    error: teamsError,
  } = useGetAvailableTeamsQuery({ limit: 500 });

  const {
    data: availableServiceProviders = [],
    isLoading: areServiceProvidersLoading,
    isError: areServiceProvidersError,
    error: serviceProvidersError,
  } = useGetAvailableServiceProvidersQuery({ limit: 500 });

  const {
    data: usersDirectory = [],
    isLoading: areUsersLoading,
    isError: areUsersError,
    error: usersError,
  } = useGetUsersDirectoryQuery({ limit: 1000 });

  const usersById = useMemo(
    () => buildUsersById(usersDirectory),
    [usersDirectory],
  );

  const availableTeamsWithMembers = useMemo(
    () => enrichTeamsWithMembers(availableTeams, usersById),
    [availableTeams, usersById],
  );

  const availableServiceProvidersWithMembers = useMemo(
    () =>
      enrichServiceProvidersWithMembers(
        availableServiceProviders,
        usersDirectory,
      ),
    [availableServiceProviders, usersDirectory],
  );

  const targetOptions =
    targetType === "SP"
      ? availableServiceProvidersWithMembers
      : availableTeamsWithMembers;

  const selectedTargetOption =
    targetOptions.find((item) => item.id === targetId) || null;

  const selectedTargetPayload = useMemo(
    () => buildTargetPayload(selectedTargetOption),
    [selectedTargetOption],
  );

  const selectedRow =
    readyRows.find((row) => row._rowKey === selectedTbRowId) || null;

  const backendAllocatedCount = readyRows.filter(
    (row) => allocationsByRowId[row._rowKey]?.source === "BACKEND",
  ).length;

  const assignedCount = readyRows.filter((row) =>
    Boolean(allocationsByRowId[row._rowKey]?.id),
  ).length;

  const plannedCount = Math.max(assignedCount - backendAllocatedCount, 0);
  const waitingCount = Math.max(readyRows.length - assignedCount, 0);

  const targetGroupCount = new Set(
    readyRows
      .map((row) => allocationsByRowId[row._rowKey])
      .filter((target) => target?.id)
      .map((target) => `${target.type}_${target.id}`),
  ).size;

  const targetContextLoading =
    areTeamsLoading || areServiceProvidersLoading || areUsersLoading;

  const targetContextError =
    areTeamsError || areServiceProvidersError || areUsersError;

  const targetContextErrorMessage =
    teamsError?.message ||
    serviceProvidersError?.message ||
    usersError?.message ||
    teamsError?.data?.message ||
    serviceProvidersError?.data?.message ||
    usersError?.data?.message ||
    "Could not load TEAM/SP allocation targets.";

  function handleTargetTypeChange(nextType) {
    setTargetType(nextType);
    setTargetId("");
    setStatusMessage("");
  }

  function handleSelectTarget(target) {
    const cleanTarget = buildTargetPayload(target);

    if (!cleanTarget) {
      setTargetId("");
      return;
    }

    setTargetType(cleanTarget.type);
    setTargetId(cleanTarget.id);
    setStatusMessage(`${getTargetLabel(cleanTarget)} selected.`);
  }

  function assignTargetToRow(row, target = selectedTargetPayload) {
    const cleanTarget = buildTargetPayload(target);

    if (!row?._rowKey || !cleanTarget) return;

    const existingAllocation = allocationsByRowId[row._rowKey];

    if (existingAllocation?.source === "BACKEND") {
      setStatusMessage(
        `${getTbRowId(row)} already has a permanent backend allocation.`,
      );
      return;
    }

    setSelectedTbRowId(row._rowKey);
    setPlannedAllocationsByRowId((current) => ({
      ...current,
      [row._rowKey]: {
        ...cleanTarget,
        source: "FRONTEND_PENDING_BACKEND",
        plannedAt: new Date().toISOString(),
      },
    }));
    setStatusMessage(
      `${getTbRowId(row)} assigned to ${getTargetLabel(cleanTarget)} in the frontend allocation plan.`,
    );
  }

  function clearTargetFromRow(row) {
    if (!row?._rowKey) return;

    const existingAllocation = allocationsByRowId[row._rowKey];

    if (existingAllocation?.source === "BACKEND") {
      setStatusMessage(
        `${getTbRowId(row)} has a permanent backend allocation and cannot be cleared here.`,
      );
      return;
    }

    setPlannedAllocationsByRowId((current) => {
      const next = { ...current };
      delete next[row._rowKey];
      return next;
    });

    setStatusMessage(`${getTbRowId(row)} frontend allocation cleared.`);
  }

  function handleTargetDragStart(event, target) {
    const cleanTarget = buildTargetPayload(target);

    if (!cleanTarget) return;

    setDragTarget(cleanTarget);
    event.dataTransfer.effectAllowed = "copy";
    event.dataTransfer.setData("application/json", JSON.stringify(cleanTarget));
    event.dataTransfer.setData("text/plain", getTargetLabel(cleanTarget));
  }

  function handleTargetDragEnd() {
    setDragTarget(null);
    setDragOverRowId(null);
  }

  function readDroppedTarget(event) {
    const jsonPayload = event.dataTransfer.getData("application/json");

    if (jsonPayload) {
      try {
        return buildTargetPayload(JSON.parse(jsonPayload));
      } catch (error) {
        console.warn("Could not parse dropped Targeted Batch target", error);
      }
    }

    return buildTargetPayload(dragTarget || selectedTargetPayload);
  }

  function handleDropTargetOnRow(event, row) {
    event.preventDefault();
    setDragOverRowId(null);

    const droppedTarget = readDroppedTarget(event);

    if (!droppedTarget) return;

    assignTargetToRow(row, droppedTarget);
    setDragTarget(null);
  }

  function handleTargetDragEnter(event, row) {
    event.preventDefault();

    if (!row?._rowKey) return;
    if (allocationsByRowId[row._rowKey]?.source === "BACKEND") return;
    if (!dragTarget && !selectedTargetPayload) return;

    event.dataTransfer.dropEffect = "copy";
    setDragOverRowId(row._rowKey);
  }

  function handleTargetDragLeave(event, row) {
    if (!row?._rowKey) return;

    const nextElement = event.relatedTarget;
    if (nextElement && event.currentTarget.contains(nextElement)) return;

    setDragOverRowId((current) =>
      current === row._rowKey ? null : current,
    );
  }

  function handleAllowTargetDrop(event, row) {
    if (allocationsByRowId[row._rowKey]?.source === "BACKEND") return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
  }

  if (isBatchLoading) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.notice}>
          Loading permanent Targeted Batch and TB Rows...
        </div>
      </section>
    );
  }

  if (batchLoadError || !batch) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.errorNotice}>
          <strong>Targeted Batch not available</strong>
          <p style={styles.noticeText}>
            {batchLoadError ||
              "The requested permanent Targeted Batch could not be loaded."}
          </p>
        </div>
      </section>
    );
  }

  if (!isSalesSource) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.deferredPanel}>
          <Badge tone="warning">SALES ALLOCATION ONLY</Badge>
          <h2 style={styles.title}>Targeted Batch source not supported</h2>
          <p style={styles.subtitle}>
            The current release allocates permanent Targeted Batches created
            from the Sales table.
          </p>
        </div>
      </section>
    );
  }

  if (!isConfirmed) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.deferredPanel}>
          <Badge tone="warning">BATCH NOT READY</Badge>
          <h2 style={styles.title}>Targeted Batch creation is not complete</h2>
          <p style={styles.subtitle}>
            Allocation is available only after permanent creation reaches
            READY.
          </p>
        </div>
      </section>
    );
  }

  if (permanentRows.length === 0) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.errorNotice}>
          <strong>Permanent TB Rows not available</strong>
          <p style={styles.noticeText}>
            No permanent TB rows were found for this batch.
          </p>
        </div>
      </section>
    );
  }

  const finalReportStatus = batch?.finalReport?.status || "DRAFT";
  const createDisabledReason =
    assignedCount === 0
      ? "Assign at least one ready TB row to a TEAM or SP."
      : "Backend Targeted Batch allocation persistence is not connected yet.";

  return (
    <section style={styles.page}>
      <div style={styles.backRow}>
        <Link
          to={`/operations/targeted-batches/${encodeURIComponent(batch.id)}`}
          style={styles.backLink}
        >
          ← Back to TB Rows
        </Link>

        <Link
          to={`/operations/targeted-batches/${encodeURIComponent(
            batch.id,
          )}/final-report`}
          style={styles.backLink}
        >
          Final Report ({finalReportStatus})
        </Link>
      </div>

      <div style={styles.header}>
        <div>
          <p style={styles.eyebrow}>
            Operations / Targeted Batch / Allocation
          </p>
          <h2 style={styles.title}>Targeted Batch Allocation</h2>
          <p style={styles.subtitle}>
            Allocate permanent TB Rows to a TEAM or Service Provider using the
            same select-and-drag board used by BGO. Individual FWR allocation
            remains outside this workflow.
          </p>
        </div>

        <Badge tone="warning">ALLOCATION BACKEND PENDING</Badge>
      </div>

      <div style={styles.summaryPanel}>
        <div style={styles.summaryMetaColumn}>
          <SummaryDetailRow label="TB ID" value={batch.id} />
          <SummaryDetailRow
            label="Confirmed"
            value={formatDateTime(
              timestampToIso(
                batch?.metadata?.confirmedAt ||
                  batch?.creation?.completedAt,
              ),
            )}
          />
          <SummaryDetailRow
            label="Source"
            value={batch?.source?.label || "Prepaid Sales"}
          />
        </div>

        <div style={styles.summaryMetricGrid}>
          <InfoCard
            label="LM"
            value={`${batch?.scope?.lmPcode || "NAv"} · ${
              batch?.scope?.lmName || "NAv"
            }`}
          />
          <InfoCard label="Ready Rows" value={formatNumber(readyRows.length)} />
          <InfoCard
            label="Allocated Rows"
            value={formatNumber(backendAllocatedCount)}
          />
          <InfoCard
            label="Assigned Plan"
            value={formatNumber(plannedCount)}
          />
          <InfoCard label="Waiting Rows" value={formatNumber(waitingCount)} />
          <InfoCard
            label="Target Groups"
            value={formatNumber(targetGroupCount)}
          />
        </div>
      </div>

      <div style={styles.infoBanner}>
        <strong>TB allocation board:</strong> select or drag a TEAM/SP target
        onto each ready TB Row. The Allocation Review table is the single
        allocation view for permanent allocations, assigned frontend plans,
        and waiting rows.
      </div>

      {targetContextLoading ? (
        <div style={styles.notice}>Loading TEAM/SP allocation targets...</div>
      ) : null}

      {targetContextError ? (
        <div style={styles.errorNotice}>{targetContextErrorMessage}</div>
      ) : null}

      {statusMessage ? (
        <div style={styles.statusMessage}>{statusMessage}</div>
      ) : null}

      <section style={styles.boardGrid}>
        <div style={styles.leftColumn}>
          <section style={styles.panel}>
            <div style={styles.panelHeader}>
              <div>
                <h3 style={styles.panelTitle}>TB Target Setup</h3>
                <p style={styles.panelSubtitle}>
                  Select or drag an available TEAM or Service Provider. Drop it
                  onto the permanent TB Row that must be allocated.
                </p>
              </div>

              <Badge tone={targetOptions.length > 0 ? "success" : "warning"}>
                {targetOptions.length} {targetType}(s)
              </Badge>
            </div>

            <div style={styles.targetToggleRow}>
              <button
                type="button"
                style={{
                  ...styles.targetToggleButton,
                  ...(targetType === "TEAM"
                    ? styles.targetToggleActive
                    : null),
                }}
                onClick={() => handleTargetTypeChange("TEAM")}
              >
                TEAM
              </button>

              <button
                type="button"
                style={{
                  ...styles.targetToggleButton,
                  ...(targetType === "SP"
                    ? styles.targetToggleActive
                    : null),
                }}
                onClick={() => handleTargetTypeChange("SP")}
              >
                SP
              </button>
            </div>

            {targetOptions.length === 0 ? (
              <div style={styles.emptyState}>
                No active{" "}
                {targetType === "TEAM"
                  ? "teams"
                  : "service providers"}{" "}
                found yet.
              </div>
            ) : (
              <div style={styles.targetOptionList}>
                {targetOptions.map((target) => {
                  const selected = target.id === targetId;

                  return (
                    <button
                      key={`${target.type}_${target.id}`}
                      type="button"
                      draggable
                      style={{
                        ...styles.targetOptionCard,
                        ...(selected
                          ? styles.targetOptionCardActive
                          : null),
                      }}
                      onClick={() => handleSelectTarget(target)}
                      onDragStart={(event) =>
                        handleTargetDragStart(event, target)
                      }
                      onDragEnd={handleTargetDragEnd}
                      title={`Select or drag ${target.type} ${target.name} onto a TB Row`}
                    >
                      <div style={styles.targetOptionHeader}>
                        <span style={styles.targetType}>{target.type}</span>
                        <strong style={styles.targetTitle}>
                          {target.name}
                        </strong>
                      </div>
                      <p style={styles.targetSub}>
                        {getTargetOptionSubtitle(target)}
                      </p>
                      <MembersList target={target} maxItems={4} />
                      <span style={styles.targetMicro}>
                        {getTargetOptionMicroText(target)}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </section>
        </div>

        <section style={styles.panel}>
          <div style={styles.panelHeader}>
            <div>
              <h3 style={styles.panelTitle}>Ready TB Rows</h3>
              <p style={styles.panelSubtitle}>
                Drag a TEAM/SP target onto each permanent TB Row that must be
                allocated.
              </p>
            </div>

            <Badge tone={readyRows.length > 0 ? "success" : "neutral"}>
              {readyRows.length} row(s)
            </Badge>
          </div>

          {readyRows.length === 0 ? (
            <div style={styles.emptyState}>
              No accepted permanent TB Rows are ready for allocation.
            </div>
          ) : (
            <div style={styles.groupList}>
              {readyRows.map((row) => {
                const allocation = allocationsByRowId[row._rowKey] || null;
                const assignmentStatus = getAssignmentStatus(row, allocation);
                const selected = selectedTbRowId === row._rowKey;
                const isDragFocused = dragOverRowId === row._rowKey;

                return (
                  <div
                    key={row._rowKey}
                    style={{
                      ...styles.groupCard,
                      ...(selected ? styles.groupCardActive : null),
                      ...(allocation?.id
                        ? styles.groupCardAllocated
                        : null),
                      ...(isDragFocused
                        ? styles.groupCardDragFocused
                        : null),
                    }}
                    onDragEnter={(event) =>
                      handleTargetDragEnter(event, row)
                    }
                    onDragLeave={(event) =>
                      handleTargetDragLeave(event, row)
                    }
                    onDragOver={(event) =>
                      handleAllowTargetDrop(event, row)
                    }
                    onDrop={(event) => handleDropTargetOnRow(event, row)}
                  >
                    <div style={styles.groupMain}>
                      <button
                        type="button"
                        style={styles.groupSelectButton}
                        onClick={() => setSelectedTbRowId(row._rowKey)}
                        title="Select this TB Row and preview its details"
                      >
                        <span style={styles.groupName}>
                          Row {row.rowNo} • {row.meterNo || "NAv"}
                        </span>
                        <span style={styles.groupMeta}>
                          {getRowAddress(row)}
                        </span>
                        <div style={styles.groupMetricRow}>
                          <span>{getTbRowId(row)}</span>
                          <span>{getProposedTrnType(row)}</span>
                          <span>Ward {getRowWard(row)}</span>
                        </div>
                      </button>

                      <div
                        style={{
                          ...styles.groupAllocationBox,
                          ...(allocation?.id
                            ? styles.groupAllocationBoxAssigned
                            : null),
                          ...(isDragFocused
                            ? styles.groupAllocationBoxDragFocused
                            : null),
                        }}
                      >
                        <span style={styles.groupAllocationLabel}>
                          Assigned target
                        </span>
                        <strong style={styles.groupAllocationTarget}>
                          {allocation?.id
                            ? getTargetLabel(allocation)
                            : "No TEAM/SP assigned"}
                        </strong>
                        <span style={styles.groupAllocationMembers}>
                          {allocation?.id
                            ? `${allocation.memberCount || 0} member(s)`
                            : isDragFocused
                              ? "Release to assign this TEAM/SP here."
                              : "Drop a TEAM/SP here."}
                        </span>
                        <Badge tone={assignmentStatus.tone}>
                          {assignmentStatus.label}
                        </Badge>
                      </div>
                    </div>

                    <div style={styles.groupActions}>
                      {allocation?.id && assignmentStatus.editable ? (
                        <button
                          type="button"
                          style={styles.clearAssignmentButton}
                          onClick={() => clearTargetFromRow(row)}
                        >
                          Clear
                        </button>
                      ) : null}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </section>

      <section style={styles.panel}>
        <div style={styles.panelHeader}>
          <div>
            <h3 style={styles.panelTitle}>Allocation Review</h3>
            <p style={styles.panelSubtitle}>
              This table remains visible before and after backend allocation.
              It shows every permanent TB Row and its current TEAM/SP state.
            </p>
          </div>

          <button
            type="button"
            style={{
              ...styles.createButton,
              ...styles.disabledButton,
            }}
            disabled
            title={createDisabledReason}
          >
            Create TB Allocation
          </button>
        </div>

        <div style={styles.tableWrap}>
          <table style={styles.table}>
            <thead>
              <tr>
                <Th>TB Row</Th>
                <Th>Meter</Th>
                <Th>Proposed TRN</Th>
                <Th>Allocation</Th>
                <Th>Status</Th>
                <Th>Actions</Th>
              </tr>
            </thead>

            <tbody>
              {readyRows.map((row) => {
                const allocation = allocationsByRowId[row._rowKey] || null;
                const assignmentStatus = getAssignmentStatus(row, allocation);

                return (
                  <tr key={`review-${row._rowKey}`}>
                    <Td strong>{getTbRowId(row)}</Td>
                    <Td>
                      <strong>{row.meterNo || "NAv"}</strong>
                      <div style={styles.rowSourceIdentity}>
                        {row.salesAllMeterId || "NAv"}
                      </div>
                    </Td>
                    <Td>
                      <Badge tone="info">{getProposedTrnType(row)}</Badge>
                    </Td>
                    <Td>
                      <AllocationCell allocation={allocation} />
                    </Td>
                    <Td>
                      <Badge tone={assignmentStatus.tone}>
                        {assignmentStatus.label}
                      </Badge>
                    </Td>
                    <Td>
                      {allocation?.id && assignmentStatus.editable ? (
                        <button
                          type="button"
                          style={styles.clearAssignmentButton}
                          onClick={() => clearTargetFromRow(row)}
                        >
                          Clear
                        </button>
                      ) : (
                        <span style={styles.memberEmpty}>
                          {assignmentStatus.label === "ALLOCATED"
                            ? "Permanent"
                            : "NAv"}
                        </span>
                      )}
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <p style={styles.noticeText}>
          {createDisabledReason} The current drag-and-drop plan changes frontend
          state only; it does not yet update Firestore.
        </p>
      </section>

      {selectedRow ? (
        <section style={styles.panel}>
          <div style={styles.panelHeader}>
            <div>
              <h3 style={styles.panelTitle}>
                Preview TB Row {selectedRow.rowNo}
              </h3>
              <p style={styles.panelSubtitle}>
                Permanent TB Row details used by this allocation board.
              </p>
            </div>

            <Badge tone="info">{getProposedTrnType(selectedRow)}</Badge>
          </div>

          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <Th>Meter</Th>
                  <Th>Account / Customer</Th>
                  <Th>Address</Th>
                  <Th>Ward</Th>
                  <Th>Sales Source ID</Th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <Td strong>{selectedRow.meterNo || "NAv"}</Td>
                  <Td>
                    {valueOrNav(selectedRow.accountNumber)} •{" "}
                    {valueOrNav(selectedRow.customerName)}
                  </Td>
                  <Td>{getRowAddress(selectedRow)}</Td>
                  <Td>{getRowWard(selectedRow)}</Td>
                  <Td>{valueOrNav(selectedRow.salesAllMeterId)}</Td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
    </section>
  );
}
