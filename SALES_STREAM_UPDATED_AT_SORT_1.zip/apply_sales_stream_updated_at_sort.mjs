import fs from "node:fs";
import path from "node:path";

const repoRoot = path.resolve(process.argv[2] || process.cwd());

const apiPath = path.join(repoRoot, "src", "redux", "demoSalesApi.js");
const tablePath = path.join(
  repoRoot,
  "src",
  "pages",
  "sales",
  "components",
  "SalesMetersTable.jsx",
);

for (const filePath of [apiPath, tablePath]) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Required file not found: ${filePath}`);
  }
}

function normalizeLf(value) {
  return String(value).replace(/\r\n/g, "\n");
}

function restoreLineEndings(value, original) {
  return original.includes("\r\n") ? value.replace(/\n/g, "\r\n") : value;
}

function countMatches(text, pattern) {
  return [...text.matchAll(new RegExp(
    pattern.source,
    pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`,
  ))].length;
}

function replaceRegexOnce(text, pattern, replacement, label) {
  const count = countMatches(text, pattern);

  if (count !== 1) {
    throw new Error(
      `${label}: expected exactly one match but found ${count}. No files were written.`,
    );
  }

  return text.replace(pattern, replacement);
}

function replaceOnce(text, search, replacement, label) {
  const count = text.split(search).length - 1;

  if (count !== 1) {
    throw new Error(
      `${label}: expected exactly one anchor but found ${count}. No files were written.`,
    );
  }

  return text.replace(search, replacement);
}

function patchApi(source) {
  let text = normalizeLf(source);

  if (!text.includes("normalizeDemoSalesRow")) {
    throw new Error(
      "demoSalesApi.js does not contain normalizeDemoSalesRow. No files were written.",
    );
  }

  if (!text.includes('const DEMO_SALES_COLLECTION = "demo_sales_meters";')) {
    throw new Error(
      "demoSalesApi.js is not the expected Sales API. No files were written.",
    );
  }

  text = replaceRegexOnce(
    text,
    /import\s*\{[\s\S]*?\}\s*from\s*"firebase\/firestore";/,
    'import { collection, onSnapshot } from "firebase/firestore";',
    "Firestore streaming import",
  );

  if (!text.includes("function getTimestampMs(value)")) {
    const helper = `function getTimestampMs(value) {
  if (!value) return 0;

  if (typeof value?.toMillis === "function") {
    const milliseconds = Number(value.toMillis());
    return Number.isFinite(milliseconds) ? milliseconds : 0;
  }

  if (typeof value?.toDate === "function") {
    const milliseconds = value.toDate().getTime();
    return Number.isFinite(milliseconds) ? milliseconds : 0;
  }

  if (Number.isFinite(Number(value?.seconds))) {
    const seconds = Number(value.seconds);
    const nanoseconds = Number(value?.nanoseconds || 0);
    return seconds * 1000 + nanoseconds / 1_000_000;
  }

  const milliseconds = new Date(value).getTime();
  return Number.isFinite(milliseconds) ? milliseconds : 0;
}

`;

    text = replaceOnce(
      text,
      'function normalizeDemoSalesRow(id, data = {}, requestedLmPcode = "") {',
      `${helper}function normalizeDemoSalesRow(id, data = {}, requestedLmPcode = "") {`,
      "Sales timestamp helper insertion",
    );
  }

  if (!text.includes("updatedAtMs: getTimestampMs(data.updatedAt)")) {
    text = replaceOnce(
      text,
      '    lmPcode: String(data.lmPcode || requestedLmPcode || ""),\n',
      `    lmPcode: String(data.lmPcode || requestedLmPcode || ""),
    createdAt: data.createdAt || null,
    updatedAt: data.updatedAt || null,
    createdAtMs: getTimestampMs(data.createdAt),
    updatedAtMs: getTimestampMs(data.updatedAt),
`,
      "Sales timestamp normalization",
    );
  }

  text = replaceRegexOnce(
    text,
    /function sortDemoSalesRows\(left, right\) \{[\s\S]*?\n\}/,
    `function sortDemoSalesRows(left, right) {
  const updatedAtComparison =
    Number(right?.updatedAtMs || 0) - Number(left?.updatedAtMs || 0);

  if (updatedAtComparison !== 0) return updatedAtComparison;

  return String(left?.meterNo || "").localeCompare(
    String(right?.meterNo || ""),
    undefined,
    {
      numeric: true,
      sensitivity: "base",
    },
  );
}`,
    "Sales default API sort",
  );

  const endpointPattern =
    /    getDemoSalesByLmPcode: builder\.query\(\{[\s\S]*?      keepUnusedDataFor: 300,\n    \}\),/;

  const endpointReplacement = `    getDemoSalesByLmPcode: builder.query({
      queryFn: () => ({ data: [] }),

      async onCacheEntryAdded(
        lmPcode,
        { updateCachedData, cacheDataLoaded, cacheEntryRemoved },
      ) {
        if (!lmPcode) return;

        let unsubscribe = () => {};

        try {
          await cacheDataLoaded;

          unsubscribe = onSnapshot(
            collection(db, DEMO_SALES_COLLECTION),
            (snapshot) => {
              const rows = snapshot.docs
                .map((documentSnapshot) =>
                  normalizeDemoSalesRow(
                    documentSnapshot.id,
                    documentSnapshot.data(),
                    lmPcode,
                  ),
                )
                .filter((row) => row.lmPcode === lmPcode)
                .sort(sortDemoSalesRows);

              updateCachedData(() => rows);
            },
            (error) => {
              console.error("demoSalesApi stream error:", error);
            },
          );
        } catch (error) {
          console.error("demoSalesApi stream setup error:", error);
        }

        await cacheEntryRemoved;
        unsubscribe();
      },

      keepUnusedDataFor: 300,
    }),`;

  text = replaceRegexOnce(
    text,
    endpointPattern,
    endpointReplacement,
    "Sales RTK Query streaming endpoint",
  );

  if (text.includes("getDocs(")) {
    throw new Error(
      "getDocs() remains in demoSalesApi.js after patching. No files were written.",
    );
  }

  if (!text.includes("onSnapshot(")) {
    throw new Error(
      "onSnapshot() was not installed in demoSalesApi.js. No files were written.",
    );
  }

  return text;
}

function patchTable(source) {
  let text = normalizeLf(source);

  text = replaceRegexOnce(
    text,
    /const DEFAULT_SORT = \{\s*key:\s*"[^"]+",\s*direction:\s*"(?:asc|desc)"\s*\};/,
    'const DEFAULT_SORT = { key: "updatedAt", direction: "desc" };',
    "Sales table default sort",
  );

  if (!text.includes('if (sortKey === "updatedAt")')) {
    const anchor = '  if (sortKey === "wardNo") return row?.wardNumberLabel || "";\n';

    text = replaceOnce(
      text,
      anchor,
      `  if (sortKey === "updatedAt") return Number(row?.updatedAtMs || 0);
${anchor}`,
      "Sales table updatedAt sort value",
    );
  }

  return text;
}

const apiOriginal = fs.readFileSync(apiPath, "utf8");
const tableOriginal = fs.readFileSync(tablePath, "utf8");

const apiPatchedLf = patchApi(apiOriginal);
const tablePatchedLf = patchTable(tableOriginal);

const apiPatched = restoreLineEndings(apiPatchedLf, apiOriginal);
const tablePatched = restoreLineEndings(tablePatchedLf, tableOriginal);

const apiTemp = `${apiPath}.sales-stream-temp`;
const tableTemp = `${tablePath}.sales-stream-temp`;

fs.writeFileSync(apiTemp, apiPatched, "utf8");
fs.writeFileSync(tableTemp, tablePatched, "utf8");

fs.renameSync(apiTemp, apiPath);
fs.renameSync(tableTemp, tablePath);

console.log("");
console.log("SALES STREAMING AND UPDATED-AT SORT APPLIED");
console.log(`Updated: ${path.relative(repoRoot, apiPath)}`);
console.log(`Updated: ${path.relative(repoRoot, tablePath)}`);
console.log("");
console.log("Implemented:");
console.log("- demo_sales_meters now streams with Firestore onSnapshot()");
console.log("- RTK Query unsubscribes when its cache entry is removed");
console.log("- createdAt and updatedAt are normalized onto Sales rows");
console.log("- Default Sales order is updatedAt descending");
console.log("- Documents without updatedAt remain visible at the bottom");
console.log("- Meter number is the tie-breaker for identical timestamps");
