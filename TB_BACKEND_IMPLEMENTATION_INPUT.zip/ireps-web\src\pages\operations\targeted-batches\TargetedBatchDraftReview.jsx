/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import { useMemo, useState } from "react";

import {
  getTargetedBatchDraftIntegrity,
  getTargetedBatchDraftView,
  TARGETED_BATCH_SOURCE_TYPES,
} from "../../../redux/targetedBatchDraftModel";
import { formatDateTime } from "./targetedBatchUtils";
import TargetedBatchDraftFilters, {
  EMPTY_DRAFT_FILTERS,
} from "./draft/TargetedBatchDraftFilters";
import TargetedBatchDraftSummary from "./draft/TargetedBatchDraftSummary";
import TargetedBatchDraftTable from "./draft/TargetedBatchDraftTable";
import { draftReviewStyles as styles } from "./draft/targetedBatchDraftReviewStyles";

const DEFAULT_PAGE_SIZE = 25;

function SourceBadge({ sourceType }) {
  const salesSource =
    sourceType === TARGETED_BATCH_SOURCE_TYPES.PREPAID_SALES;

  return (
    <span
      style={{
        ...styles.sourceBadge,
        ...(salesSource ? styles.salesBadge : styles.uploadBadge),
      }}
    >
      {salesSource ? "Prepaid Sales" : "CSV Upload"}
    </span>
  );
}

function normalizeSearchText(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function rowMatchesSearch(row, searchText) {
  const query = normalizeSearchText(searchText);
  if (!query) return true;

  return [
    row?.salesAllMeterId,
    row?.sourceSalesAllMeterId,
    row?.meterNo,
    row?.meterNoNormalized,
    row?.accountNumber,
    row?.customerName,
    row?.addressLine1,
    row?.town,
    row?.standNumber,
    row?.actionReason,
    row?.rowDecision,
    row?.rowDecisionReason,
  ].some((value) => normalizeSearchText(value).includes(query));
}

function buildOptions(rows, key, fallback) {
  return Array.from(
    new Set(
      rows
        .map((row) => String(row?.[key] || fallback).trim().toUpperCase())
        .filter(Boolean),
    ),
  ).sort((left, right) => left.localeCompare(right));
}

export default function TargetedBatchDraftReview({
  draft,
  onClear,
  onDownload,
}) {
  const [filters, setFilters] = useState(EMPTY_DRAFT_FILTERS);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

  const currentDraft = useMemo(
    () => getTargetedBatchDraftView(draft),
    [draft],
  );
  const rows = currentDraft?.displayRows || [];
  const csvSource =
    currentDraft?.source?.type === TARGETED_BATCH_SOURCE_TYPES.CSV_UPLOAD;
  const integrity = useMemo(
    () => getTargetedBatchDraftIntegrity(currentDraft),
    [currentDraft],
  );

  const summary = useMemo(() => {
    return rows.reduce(
      (result, row) => {
        const matchStatus = String(
          row?.astMatchStatus || "NOT_CHECKED",
        ).toUpperCase();
        const rowDecision = String(row?.rowDecision || "").toUpperCase();

        if (matchStatus === "MATCHED") result.astMatched += 1;
        else if (matchStatus === "NOT_MATCHED") result.astNotMatched += 1;
        else result.astNotChecked += 1;

        if (rowDecision === "ACCEPT") result.acceptedRows += 1;
        if (rowDecision === "REJECT") result.rejectedRows += 1;

        result.totalSalesC += Number(row?.totalSalesC || 0);
        return result;
      },
      {
        astMatched: 0,
        astNotMatched: 0,
        astNotChecked: 0,
        acceptedRows: 0,
        rejectedRows: 0,
        totalSalesC: 0,
      },
    );
  }, [rows]);

  const astOptions = useMemo(
    () => buildOptions(rows, "astMatchStatus", "NOT_CHECKED"),
    [rows],
  );
  const trnOptions = useMemo(
    () => buildOptions(rows, "proposedTrnType", "NOT_SET"),
    [rows],
  );

  const filteredRows = useMemo(() => {
    return rows.filter((row) => {
      const astStatus = String(
        row?.astMatchStatus || "NOT_CHECKED",
      ).toUpperCase();
      const proposedTrnType = String(
        row?.proposedTrnType || "NOT_SET",
      ).toUpperCase();
      const rowDecision = String(row?.rowDecision || "NOT_SET").toUpperCase();

      return (
        rowMatchesSearch(row, filters.searchText) &&
        (!csvSource ||
          filters.rowDecision === "ALL" ||
          rowDecision === filters.rowDecision) &&
        (filters.astMatchStatus === "ALL" ||
          astStatus === filters.astMatchStatus) &&
        (filters.proposedTrnType === "ALL" ||
          proposedTrnType === filters.proposedTrnType)
      );
    });
  }, [rows, filters, csvSource]);

  const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const safeCurrentPage = Math.max(1, Math.min(currentPage, totalPages));
  const pageStartIndex = (safeCurrentPage - 1) * pageSize;
  const paginatedRows = filteredRows.slice(
    pageStartIndex,
    pageStartIndex + pageSize,
  );

  function updateFilter(key, value) {
    setFilters((current) => ({ ...current, [key]: value }));
    setCurrentPage(1);
  }

  function clearFilters() {
    setFilters(EMPTY_DRAFT_FILTERS);
    setCurrentPage(1);
  }

  function changePage(nextPage) {
    const page = Number(nextPage);
    setCurrentPage(
      Math.max(1, Math.min(Number.isFinite(page) ? page : 1, totalPages)),
    );
  }

  function changePageSize(nextPageSize) {
    const size = Number(nextPageSize);
    setPageSize(Number.isFinite(size) && size > 0 ? size : DEFAULT_PAGE_SIZE);
    setCurrentPage(1);
  }

  if (!currentDraft) return null;

  return (
    <section style={styles.panel}>
      <div style={styles.header}>
        <div>
          <div style={styles.titleRow}>
            <p style={styles.eyebrow}>TB Draft</p>
            <SourceBadge sourceType={currentDraft.source.type} />
          </div>
          <h2 style={styles.title}>{currentDraft.id}</h2>
          <p style={styles.subtitle}>
            {currentDraft.scope.lmPcode || "NAv"} ·{" "}
            {currentDraft.scope.lmName || "NAv"} · Created{" "}
            {formatDateTime(currentDraft.createdAt)}
          </p>
        </div>

        <div style={styles.headerActions}>
          <span style={{ ...styles.statusBadge, ...styles.draftStatus }}>
            Draft
          </span>
          <button type="button" style={styles.secondaryButton} onClick={onDownload}>
            Download Draft
          </button>
          <button type="button" style={styles.dangerButton} onClick={onClear}>
            Clear Draft
          </button>
        </div>
      </div>

      <TargetedBatchDraftSummary
        draft={currentDraft}
        totalRows={rows.length}
        summary={summary}
        integrity={integrity}
      />

      <TargetedBatchDraftFilters
        filters={filters}
        totalRows={rows.length}
        filteredRows={filteredRows.length}
        showRowDecision={csvSource}
        astOptions={astOptions}
        trnOptions={trnOptions}
        onChange={updateFilter}
        onClear={clearFilters}
      />

      <TargetedBatchDraftTable
        rows={paginatedRows}
        totalRows={filteredRows.length}
        currentPage={safeCurrentPage}
        pageSize={pageSize}
        totalPages={totalPages}
        showRowDecision={csvSource}
        onPageChange={changePage}
        onPageSizeChange={changePageSize}
      />

      <div style={styles.confirmPanel}>
        <div>
          <strong>
            {integrity.canConfirm
              ? "Review complete: permanent creation is waiting for backend integration"
              : "Resolve the draft blockers before confirmation"}
          </strong>
          <p style={styles.confirmText}>
            Confirm TB Draft must create one permanent tb_uploads parent and all
            corresponding permanent tb_rows documents. That controlled backend
            operation is not connected yet, so this page does not perform a
            Redux-only confirmation and does not allow allocation from temporary
            draft rows.
          </p>
        </div>

        <button
          type="button"
          style={{ ...styles.primaryButton, ...styles.disabledButton }}
          disabled
          title="The controlled Targeted Batch backend creation operation has not been connected yet."
        >
          Confirm TB Draft (Backend Pending)
        </button>
      </div>
    </section>
  );
}
