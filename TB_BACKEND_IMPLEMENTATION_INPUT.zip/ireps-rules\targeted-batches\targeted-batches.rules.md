# iREPS Targeted Batches Rules

## Document Control

| Item | Value |
|---|---|
| Module | Targeted Batches |
| Canonical file | `targeted-batches.rules.md` |
| Version | `0.1.0` |
| Status | `DRAFT FOR REVIEW` |
| Date | 2026-08-01 |
| Rules folder | `C:\dev\ireps-rules\targeted-batches` |
| Parent collection | `tb_uploads` |
| Row collection | `tb_rows` |
| Current source | `PREPAID_SALES` |
| Future reserved source | `CSV_UPLOAD` |

> This draft records the agreed Targeted Batch business and page-flow rules. It does not authorise code changes by itself.

## 1. Purpose

This document governs the five Targeted Batch pages, the Targeted Batch flow, the exact point at which permanent Firestore documents are created, allocation behaviour, permanent row visibility, dashboard behaviour, and controlled deletion before execution.

The Targeted Batch process must mirror the established BGO process wherever the operating behaviour is equivalent.

## 2. Locked Page Names

The standard page names are:

1. **TB Draft**
2. **TB Allocation**
3. **TB Register**
4. **TB Rows**
5. **TB Dashboard**

`TB Uploads` is not the user-facing page name. The user-facing page name is **TB Register**.

The technical Firestore collection name `tb_uploads` may remain unchanged.

## 3. Source Rules

### TB-R001 — Current source

For the current release, Targeted Batches originate only from Prepaid Sales.

```text
PREPAID_SALES
```

### TB-R002 — Future CSV source

Manual CSV origination is paused, not removed. The permanent design must remain capable of supporting:

```text
CSV_UPLOAD
```

Both sources must use the same permanent collections:

```text
tb_uploads/{tbId}
tb_rows/{tbRowId}
```

## 4. Temporary and Permanent Data

### TB-R003 — TB Draft is temporary

TB Draft contains temporary working rows before permanent creation. Draft rows may be held in frontend state, but they are not permanent Firestore TB Rows.

### TB-R004 — Permanent parent

One permanent Targeted Batch is represented by one document:

```text
tb_uploads/{tbId}
```

Each TB Register line represents one `tb_uploads` document.

### TB-R005 — Permanent rows

Each permanent Targeted Batch row is represented by one document:

```text
tb_rows/{tbRowId}
```

Every `tb_rows` document must contain the parent `tbId`.

### TB-R006 — TB Rows displays Firestore rows only

TB Rows must show only documents that exist in `tb_rows`.

TB Rows must not:

- rebuild rows from Prepaid Sales;
- show Redux draft rows as permanent rows;
- mix draft rows with Firestore rows;
- invent missing rows;
- silently fall back to draft data after a browser refresh.

## 5. Locked Creation Point

### TB-R007 — Confirmation creates permanent data

The permanent parent and rows are created only when the user confirms TB Draft.

```text
Confirm TB Draft
= create one tb_uploads document
+ create all corresponding tb_rows documents
```

Selecting meters in Prepaid Sales does not create permanent Targeted Batch documents.

Opening, reviewing, filtering, or downloading TB Draft does not create permanent Targeted Batch documents.

### TB-R008 — All-or-nothing creation

Permanent creation must not expose:

- a `tb_uploads` parent without all required rows; or
- `tb_rows` documents without their parent.

Creation must succeed as one controlled unit or fail without exposing a usable partial batch.

The exact transaction, idempotency, retry, and rollback rules will be defined in `targeted-batches.backend.rules.md`.

### TB-R009 — Draft closes after successful creation

After permanent creation succeeds:

- that batch must not return to TB Draft;
- it becomes visible in TB Register;
- TB Rows reads its permanent `tb_rows` documents;
- TB Allocation reads its permanent rows;
- TB Dashboard reads permanent data only.

If creation fails, the user remains in TB Draft and receives a clear failure result.

## 6. Canonical Flow

```mermaid
flowchart TD
    SALES[Prepaid Sales] -->|Select meters and review| DRAFT[TB Draft]

    CSV[Future CSV Upload] --> VALIDATE{Validate complete file}
    VALIDATE -->|REJECTED| REJECTED[Show rejection reasons\nNo permanent TB created]
    VALIDATE -->|ACCEPTED| ASSESS[Assess each row\nACCEPT or REJECT]
    ASSESS --> DRAFT

    DRAFT --> CONFIRM{Confirm TB Draft?}
    CONFIRM -->|No| DRAFT
    CONFIRM -->|Yes| CREATE[Controlled permanent creation]

    CREATE --> PARENT[(Create tb_uploads parent)]
    CREATE --> ROWS[(Create all tb_rows documents)]

    PARENT --> CREATED[Permanent Targeted Batch]
    ROWS --> CREATED

    CREATED --> REGISTER[TB Register]
    CREATED --> ALLOCATION[TB Allocation]
    CREATED --> TBROWS[TB Rows]
    CREATED --> DASHBOARD[TB Dashboard]

    ALLOCATION --> CHECK{All allocatable rows allocated?}
    CHECK -->|No| ALLOCATE[Button reads Allocate]
    ALLOCATE --> ALLOCATION
    CHECK -->|Yes| ALLOCATED[Button reads Allocated]
```

## 7. TB Draft Rules

### TB-R010 — Entry point

TB Draft is the entry page for a proposed Targeted Batch.

Current flow:

```text
Prepaid Sales -> TB Draft
```

Future CSV flow:

```text
Select CSV -> validate file -> assess rows -> TB Draft
```

A separate permanent CSV validation page is not required. Validation may occur within the TB Draft entry flow.

### TB-R011 — Required draft information

TB Draft must show:

- proposed TB ID;
- source;
- LM scope;
- selection reason;
- source period where relevant;
- validation summary;
- row count;
- all draft rows;
- a clear confirmation action.

### TB-R012 — Confirmation wording

The confirmation action must make it clear that confirming TB Draft creates the permanent Targeted Batch and permanent TB Rows.

In the completed implementation, confirmation must not be only a frontend Redux status change.

## 8. TB Allocation Rules

### TB-R013 — Permanent rows only

TB Allocation may allocate only permanent rows read from `tb_rows` after successful batch creation.

### TB-R014 — BGO-equivalent page

TB Allocation must mirror the approved BGO Allocation page interaction and layout wherever the behaviour is equivalent.

### TB-R015 — Allocation targets

Accepted and allocatable TB Rows may be allocated only to:

```text
TEAM
SP
```

Direct allocation to an individual FWR is prohibited.

Where only one FWR exists, that user must still belong to a TEAM and the TEAM is allocated.

### TB-R016 — Rejected rows

A `REJECT` row remains visible for audit where required, but it is not allocatable.

### TB-R017 — Allocate and Allocated

The batch action must read:

```text
Allocate
```

while one or more allocatable rows remain unallocated.

It must read:

```text
Allocated
```

when all allocatable rows have been allocated.

`Allocated` is a completed status, not an invitation to repeat allocation.

### TB-R018 — Allocation is not execution

Allocation alone does not count as field execution.

A fully allocated batch may still qualify for controlled deletion when execution has not started.

## 9. TB Register Rules

### TB-R019 — Register purpose

TB Register is the permanent list of all Targeted Batches within the user's authorised scope.

It must include:

- Sales-originated batches now;
- CSV-originated batches later when enabled.

### TB-R020 — Register data source

TB Register must be driven by permanent `tb_uploads` Firestore documents, not only frontend session state.

A browser refresh must not remove permanent batches from the register.

### TB-R021 — Register actions

The governed action set may include:

- **TB Rows**;
- **Allocate** or **Allocated**;
- **TB Dashboard**;
- **Final Report (DRAFT)** or the later available report;
- **Delete Batch** when deletion is permitted.

## 10. TB Rows Rules

### TB-R022 — Permanent row register

TB Rows is the permanent row-level register for one Targeted Batch.

It must show the governed `tb_rows` documents linked to the selected `tbId`.

### TB-R023 — Row provenance

Every row must preserve enough source information to explain where it came from.

For Sales-originated rows, this includes the approved Sales source record identity and selection reason.

For future CSV rows, this includes the source file and row reference where available.

### TB-R024 — Row progress

TB Rows must expose the permanent row decision, allocation status, execution status, and approved references available for that row.

TB Rows is not a draft editor.

## 11. TB Dashboard Rules

### TB-R025 — Dashboard scope

TB Dashboard covers:

- an overall dashboard across authorised Targeted Batches; and
- an individual dashboard for a selected Targeted Batch.

### TB-R026 — Permanent data only

TB Dashboard must use permanent Firestore data only. TB Draft data must not contribute to permanent dashboard totals.

### TB-R027 — Minimum measures

The dashboard must be able to show at least:

- total batches;
- total permanent TB Rows;
- accepted and rejected rows;
- allocated and unallocated rows;
- rows where execution has started;
- completed rows;
- batch progress.

## 12. Validation Rules

### TB-R028 — Current Sales rows

For the current Sales flow, selected Sales records enter TB Draft as candidates selected by the user.

Before permanent creation, the backend must still confirm valid authentication, role, LM scope, batch identity, and acceptable row data.

### TB-R029 — Future CSV file decision

When CSV origination is enabled, the complete file receives one decision only:

```text
ACCEPTED
REJECTED
```

A rejected file must retain at least one rejection reason and must not create a permanent batch.

### TB-R030 — Future CSV row decision

After a CSV file is accepted, every row receives one decision only:

```text
ACCEPT
REJECT
```

Every rejected row must retain at least one rejection reason. Rejected rows are not allocatable.

## 13. Identity Rules

### TB-R031 — Targeted Batch ID

The approved Targeted Batch ID format is:

```text
TGB_YYYYMMDD_HHMMSS_XXXX
```

Rules:

- date and time use `Africa/Johannesburg`;
- `XXXX` contains four random uppercase letters and/or numbers;
- example: `TGB_20260731_140700_A7K2`;
- the `tb_uploads` document ID must equal the stored `id`.

### TB-R032 — TB Row ID

Every TB Row must have a stable Firestore document ID, and its stored `id` must equal that document ID.

The exact TB Row ID construction rule is deferred to the API and backend rules.

## 14. Canonical Statuses

### Parent status

```text
READY_FOR_ALLOCATION
PARTIALLY_ALLOCATED
ALLOCATED
IN_PROGRESS
COMPLETED
```

| Status | Meaning |
|---|---|
| `READY_FOR_ALLOCATION` | Permanent batch created and allocatable rows are not fully allocated. |
| `PARTIALLY_ALLOCATED` | Some but not all allocatable rows are allocated. |
| `ALLOCATED` | All allocatable rows are allocated and execution has not started. |
| `IN_PROGRESS` | Execution has started on at least one row and the batch is not complete. |
| `COMPLETED` | All governed executable work is complete. |

### Batch allocation status

```text
NOT_STARTED
PARTIAL
ALLOCATED
```

### Row allocation status

```text
NOT_APPLICABLE
UNALLOCATED
ALLOCATED
```

### Execution status

```text
NOT_STARTED
IN_PROGRESS
COMPLETED
```

## 15. Deletion Rules

### TB-R033 — Delete before execution only

A permanent Targeted Batch may be deleted only when execution has not happened on any linked TB Row and no linked operational record proves that execution has started.

```text
No execution on every row -> deletion may be allowed
Execution on any row -> deletion is blocked
```

### TB-R034 — Allocation alone does not block deletion

An allocated batch may still be deleted when execution has not started.

The backend must re-check permanent data before deletion. A frontend button state is not sufficient authority.

### TB-R035 — Complete controlled deletion

An approved deletion must not leave orphaned Targeted Batch data.

The controlled delete operation must deal safely with:

- the `tb_uploads` parent;
- every linked `tb_rows` document;
- linked allocation data;
- any unexecuted linked operational artifacts according to the later backend rules.

### TB-R036 — Execution permanently blocks deletion

Once execution has started on any row, the batch must remain available for history, audit, reporting, and final outcomes.

## 16. Final Report Rule

Final Report is a governed output, not a sixth mandatory page in the five-page Targeted Batch workflow.

Before the report is available, the action may read:

```text
Final Report (DRAFT)
```

## 17. Scope, Audit, and Integrity

- Every parent and row must contain the canonical LM scope needed to prevent cross-municipality mixing.
- Users may read or act only within their authorised role and workbase scope.
- Permanent backend writes must use server-authoritative timestamps.
- Parent and row counts must reconcile.
- The frontend must not silently repair missing parent or row documents.
- A parent/row mismatch must be reported for controlled backend reconciliation.

## 18. Change Control

Before changing Targeted Batch code:

1. read this rules file;
2. inspect the latest affected files;
3. state the exact intended change;
4. obtain user approval;
5. modify only approved files and behaviour;
6. test the change;
7. verify Firestore effects where applicable;
8. update rules and schemas when an approved rule changes.

No page, workflow, schema, filename, route, or business rule may be changed without permission.

## 19. Deferred Documents

The next governed documents are:

```text
C:\dev\ireps-rules\targeted-batches\targeted-batches.api.rules.md
C:\dev\ireps-rules\targeted-batches\targeted-batches.backend.rules.md
```

They will lock callable names, API requests and responses, role matrices, exact TB Row ID generation, transaction mechanics, idempotency, retries, deletion cascade, TRN origination, error codes, logging, and verification.

## 20. Approval Record

| Decision | Status |
|---|---|
| Five page names | Agreed |
| Current source is Prepaid Sales only | Agreed |
| CSV source remains reserved | Agreed |
| Confirm TB Draft creates `tb_uploads` and `tb_rows` | Agreed |
| TB Rows shows Firestore rows only | Agreed |
| Allocation targets are TEAM or SP only | Agreed |
| `Allocate` / `Allocated` behaviour | Agreed |
| Delete only before execution | Agreed |
| Full document | Draft for review |
