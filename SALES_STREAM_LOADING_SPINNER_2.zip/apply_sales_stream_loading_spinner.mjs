import fs from "node:fs";
import path from "node:path";

const repoRoot = path.resolve(process.argv[2] || process.cwd());

const apiPath = path.join(repoRoot, "src", "redux", "demoSalesApi.js");
const pagePath = path.join(
  repoRoot,
  "src",
  "pages",
  "sales",
  "PrepaidSales.jsx",
);

for (const filePath of [apiPath, pagePath]) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Required file not found: ${filePath}`);
  }
}

function normalizeLf(value) {
  return String(value).replace(/\r\n/g, "\n");
}

function restoreLineEndings(value, original) {
  return original.includes("\r\n") ? value.replace(/\n/g, "\r\n") : value;
}

function countOccurrences(text, search) {
  return search ? text.split(search).length - 1 : 0;
}

function replaceOnce(text, search, replacement, label) {
  const count = countOccurrences(text, search);

  if (count !== 1) {
    throw new Error(
      `${label}: expected exactly one anchor but found ${count}. No files were written.`,
    );
  }

  return text.replace(search, replacement);
}

function countRegex(text, pattern) {
  return [...text.matchAll(
    new RegExp(
      pattern.source,
      pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`,
    ),
  )].length;
}

function replaceRegexOnce(text, pattern, replacement, label) {
  const count = countRegex(text, pattern);

  if (count !== 1) {
    throw new Error(
      `${label}: expected exactly one match but found ${count}. No files were written.`,
    );
  }

  return text.replace(pattern, replacement);
}

function patchApi(source) {
  let text = normalizeLf(source);

  if (!text.includes("onSnapshot")) {
    throw new Error(
      "demoSalesApi.js is not currently using Firestore streaming. No files were written.",
    );
  }

  if (!text.includes("function getTimestampMs(value)")) {
    throw new Error(
      "demoSalesApi.js does not contain the expected timestamp helper. No files were written.",
    );
  }

  if (!text.includes("function toSerializableTimestamp(value)")) {
    text = replaceOnce(
      text,
      "function normalizeTbRefs(value = []) {",
      `function toSerializableTimestamp(value) {
  const milliseconds = getTimestampMs(value);
  return milliseconds > 0 ? new Date(milliseconds).toISOString() : null;
}

function normalizeFieldWork(value) {
  if (!value || typeof value !== "object") return null;

  return {
    ...value,
    submittedAt: toSerializableTimestamp(value.submittedAt),
    updatedAt: toSerializableTimestamp(value.updatedAt),
  };
}

function normalizeTbRefs(value = []) {`,
      "Serializable timestamp helper insertion",
    );
  }

  text = replaceRegexOnce(
    text,
    /date:\s*item\?\.date\s*\?\?\s*item\?\.addedAt\s*\?\?\s*item\?\.createdAt\s*\?\?\s*null,/,
    `date: toSerializableTimestamp(
          item?.date ?? item?.addedAt ?? item?.createdAt ?? null,
        ),`,
    "TB reference date serialization",
  );

  text = replaceRegexOnce(
    text,
    /fieldWork:\s*item\?\.fieldWork\s*&&\s*typeof item\.fieldWork === "object"\s*\?\s*item\.fieldWork\s*:\s*null,/,
    "fieldWork: normalizeFieldWork(item?.fieldWork),",
    "TB field-work timestamp serialization",
  );

  text = replaceRegexOnce(
    text,
    /createdAt:\s*data\.createdAt\s*\|\|\s*null,\s*updatedAt:\s*data\.updatedAt\s*\|\|\s*null,/,
    `createdAt: toSerializableTimestamp(data.createdAt),
    updatedAt: toSerializableTimestamp(data.updatedAt),`,
    "Root Sales timestamp serialization",
  );

  if (!text.includes("function buildDemoSalesRows(")) {
    text = replaceOnce(
      text,
      "export const demoSalesApi = createApi({",
      `function buildDemoSalesRows(snapshot, lmPcode) {
  return snapshot.docs
    .map((documentSnapshot) =>
      normalizeDemoSalesRow(
        documentSnapshot.id,
        documentSnapshot.data(),
        lmPcode,
      ),
    )
    .filter((row) => row.lmPcode === lmPcode)
    .sort(sortDemoSalesRows);
}

function readInitialSalesSnapshot(lmPcode) {
  return new Promise((resolve) => {
    let unsubscribe = () => {};

    unsubscribe = onSnapshot(
      collection(db, DEMO_SALES_COLLECTION),
      (snapshot) => {
        const hasServerResult = snapshot.metadata?.fromCache === false;
        const hasCachedRows = snapshot.docs.length > 0;

        if (!hasServerResult && !hasCachedRows) return;

        const rows = buildDemoSalesRows(snapshot, lmPcode);
        unsubscribe();
        resolve({ data: rows });
      },
      (error) => {
        unsubscribe();
        console.error("demoSalesApi initial stream error:", error);

        resolve({
          error: {
            status: "CUSTOM_ERROR",
            error: error?.message || "Could not load demo prepaid sales.",
          },
        });
      },
    );
  });
}

export const demoSalesApi = createApi({`,
      "Initial Sales stream helper insertion",
    );
  }

  text = replaceOnce(
    text,
    "      queryFn: () => ({ data: [] }),",
    "      queryFn: (lmPcode) => readInitialSalesSnapshot(lmPcode),",
    "Initial Sales loading state",
  );

  const duplicateRowsBlock = `              const rows = snapshot.docs
                .map((documentSnapshot) =>
                  normalizeDemoSalesRow(
                    documentSnapshot.id,
                    documentSnapshot.data(),
                    lmPcode,
                  ),
                )
                .filter((row) => row.lmPcode === lmPcode)
                .sort(sortDemoSalesRows);`;

  text = replaceOnce(
    text,
    duplicateRowsBlock,
    "              const rows = buildDemoSalesRows(snapshot, lmPcode);",
    "Persistent Sales stream row builder",
  );

  if (text.includes("queryFn: () => ({ data: [] })")) {
    throw new Error(
      "Immediate empty Sales query data remains after patching. No files were written.",
    );
  }

  return text;
}

function patchPage(source) {
  let text = normalizeLf(source);

  if (!text.includes("function SalesLoadingState()")) {
    text = replaceOnce(
      text,
      "function SummaryCard({ label, value, subtitle, active, onClick }) {",
      `function SalesLoadingState() {
  return (
    <section style={styles.loadingPanel} aria-live="polite" aria-busy="true">
      <style>
        {\`
          @keyframes irepsSalesSpinner {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        \`}
      </style>

      <div style={styles.loadingSpinner} aria-hidden="true" />

      <div>
        <h2 style={styles.loadingTitle}>Loading prepaid sales...</h2>
        <p style={styles.loadingText}>
          Connecting to the live Sales stream and preparing meter records.
        </p>
      </div>
    </section>
  );
}

function SummaryCard({ label, value, subtitle, active, onClick }) {`,
      "Sales loading component insertion",
    );
  }

  const oldLoadingPanel = `      {isLoading ? (
        <section style={styles.statePanel}>
          <h2>Loading prepaid sales...</h2>
          <p>Reading Endumeni meter sales through Redux Toolkit Query.</p>
        </section>
      ) : null}`;

  text = replaceOnce(
    text,
    oldLoadingPanel,
    `      {isLoading ? <SalesLoadingState /> : null}`,
    "Sales loading panel replacement",
  );

  if (!text.includes("  loadingPanel: {")) {
    text = replaceOnce(
      text,
      "  statePanel: {",
      `  loadingPanel: {
    display: "flex",
    alignItems: "center",
    gap: "1rem",
    marginTop: "1rem",
    padding: "1.4rem 1.5rem",
    border: "1px solid rgba(37, 99, 235, 0.2)",
    borderRadius: "1rem",
    background: "#ffffff",
    boxShadow: "0 12px 28px rgba(15, 23, 42, 0.05)",
  },
  loadingSpinner: {
    width: "2.35rem",
    height: "2.35rem",
    flex: "0 0 auto",
    border: "4px solid #dbeafe",
    borderTopColor: "#2563eb",
    borderRadius: "999px",
    animation: "irepsSalesSpinner 0.8s linear infinite",
  },
  loadingTitle: {
    margin: 0,
    color: "#0f172a",
    fontSize: "1.08rem",
  },
  loadingText: {
    margin: "0.3rem 0 0",
    color: "#64748b",
    fontSize: "0.88rem",
  },
  statePanel: {`,
      "Sales loading styles insertion",
    );
  }

  return text;
}

const apiOriginal = fs.readFileSync(apiPath, "utf8");
const pageOriginal = fs.readFileSync(pagePath, "utf8");

const apiPatchedLf = patchApi(apiOriginal);
const pagePatchedLf = patchPage(pageOriginal);

const apiPatched = restoreLineEndings(apiPatchedLf, apiOriginal);
const pagePatched = restoreLineEndings(pagePatchedLf, pageOriginal);

const writes = [
  [apiPath, apiPatched],
  [pagePath, pagePatched],
];

for (const [filePath, content] of writes) {
  fs.writeFileSync(`${filePath}.spinner-temp`, content, "utf8");
}

for (const [filePath] of writes) {
  fs.renameSync(`${filePath}.spinner-temp`, filePath);
}

console.log("");
console.log("SALES STREAM LOADING SPINNER APPLIED");
console.log(`Updated: ${path.relative(repoRoot, apiPath)}`);
console.log(`Updated: ${path.relative(repoRoot, pagePath)}`);
console.log("");
console.log("Implemented:");
console.log("- Spinner remains visible until the first Firestore Sales snapshot arrives");
console.log("- No premature 'No prepaid sales found' state during initial streaming");
console.log("- Persistent onSnapshot streaming remains active after initial load");
console.log("- Firestore Timestamp values are converted before entering Redux state");
console.log("- TB reference and field-work dates remain available as ISO strings");
