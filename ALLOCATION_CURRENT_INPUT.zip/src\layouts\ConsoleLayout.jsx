import { useEffect, useMemo, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { signOut } from "firebase/auth";

import { useAuth } from "../auth/useAuth";
import { useWarehouse } from "../context/WarehouseContext";
import { auth } from "../firebase";

const ALL_OPERATIONAL_ROLES = ["SPU", "ADM", "MNG", "SPV", "FWR"];
const MANAGEMENT_ROLES = ["SPU", "ADM", "MNG", "SPV"];
const ADMIN_ROLES = ["SPU", "ADM", "MNG"];
const MREAD_STAGING_CONTROLLER_ROLES = ["SPU", "MNG", "SPV"];

const APP_ENV_VALUE =
  import.meta.env.VITE_APP_ENV || import.meta.env.MODE || "dev";

const ENVIRONMENT_BADGE_CONFIG = {
  dev: {
    label: "DEV",
    background: "#dbeafe",
    color: "#1e40af",
    borderColor: "rgba(37, 99, 235, 0.32)",
  },
  development: {
    label: "DEV",
    background: "#dbeafe",
    color: "#1e40af",
    borderColor: "rgba(37, 99, 235, 0.32)",
  },
  local: {
    label: "DEV",
    background: "#dbeafe",
    color: "#1e40af",
    borderColor: "rgba(37, 99, 235, 0.32)",
  },
  test: {
    label: "TEST",
    background: "#fef3c7",
    color: "#92400e",
    borderColor: "rgba(245, 158, 11, 0.34)",
  },
  testing: {
    label: "TEST",
    background: "#fef3c7",
    color: "#92400e",
    borderColor: "rgba(245, 158, 11, 0.34)",
  },
  trial: {
    label: "TRIAL",
    background: "#ede9fe",
    color: "#5b21b6",
    borderColor: "rgba(124, 58, 237, 0.34)",
  },
  trials: {
    label: "TRIAL",
    background: "#ede9fe",
    color: "#5b21b6",
    borderColor: "rgba(124, 58, 237, 0.34)",
  },
  prod: {
    label: "LIVE",
    background: "#dcfce7",
    color: "#166534",
    borderColor: "rgba(34, 197, 94, 0.32)",
  },
  production: {
    label: "LIVE",
    background: "#dcfce7",
    color: "#166534",
    borderColor: "rgba(34, 197, 94, 0.32)",
  },
  live: {
    label: "LIVE",
    background: "#dcfce7",
    color: "#166534",
    borderColor: "rgba(34, 197, 94, 0.32)",
  },
};

const navSections = [
  {
    items: [
      {
        label: "Map",
        path: "/ward-scope/map",
        allowedRoles: MANAGEMENT_ROLES,
      },
      {
        label: "Sales",
        path: "/sales",
        allowedRoles: MANAGEMENT_ROLES,
      },
    ],
    groups: [
      {
        label: "Registries",
        items: [
          {
            label: "Ward Registry",
            path: "/registries/wards",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "ERF Registry",
            path: "/registries/erfs",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Premise Registry",
            path: "/registries/premises",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Meter Registry",
            path: "/registries/meters",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "TRN Registry",
            path: "/registries/trns",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "MREAD Registry",
            path: "/registries/mread",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "MREAD Staging",
            path: "/registries/mread-staging",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Account Registry",
            path: "/registries/accounts",
            allowedRoles: MANAGEMENT_ROLES,
          },
        ],
      },
      {
        label: "Reports",
        items: [
          {
            label: "No Access",
            path: "/reports/no-access",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Anomaly",
            path: "/reports/anomaly",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Normalisation",
            path: "/reports/normalisation",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "User Activity",
            path: "/reports/user-activity",
            allowedRoles: MANAGEMENT_ROLES,
          },
        ],
      },
      {
        label: "Operations",
        items: [
          {
            label: "Operations Overview",
            path: "/operations",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "TC Uploads",
            path: "/operations/tc-uploads",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "TB Register",
            path: "/operations/targeted-batches",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "TB Dashboard",
            path: "/operations/tb-dashboard",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "MD BGO",
            path: "/operations/bgo",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "BGO Dashboard",
            path: "/operations/bgo-dashboard",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Operational Teams",
            path: "/operations/teams",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Geo-Fences",
            path: "/operations/geo-fences",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "WMS Dashboard",
            path: "/operations/wms-dashboard",
            allowedRoles: MANAGEMENT_ROLES,
          },
        ],
      },
      {
        label: "Admin",
        items: [
          {
            label: "Service Providers",
            path: "/admin/service-providers",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Users",
            path: "/admin/users",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "Teams",
            path: "/admin/teams",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "FWR Monitoring",
            path: "/admin/fwr-monitoring",
            allowedRoles: MANAGEMENT_ROLES,
          },
          {
            label: "MREAD Staging Controller",
            path: "/admin/mread-staging-controller",
            allowedRoles: MREAD_STAGING_CONTROLLER_ROLES,
          },
          {
            label: "Settings",
            path: "/admin/settings",
            allowedRoles: ADMIN_ROLES,
          },
        ],
      },
    ],
  },
];

const sidebarStyles = {
  mainLink: {
    fontSize: "0.98rem",
    fontWeight: 850,
    letterSpacing: "0.01em",
  },
  groupButton: {
    width: "100%",
    border: 0,
    background: "transparent",
    color: "inherit",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0.66rem 0.75rem",
    borderRadius: "0.85rem",
    fontSize: "0.98rem",
    fontWeight: 850,
    letterSpacing: "0.01em",
    textAlign: "left",
  },
  groupButtonOpen: {
    background: "rgba(15, 23, 42, 0.06)",
  },
  groupArrow: {
    fontSize: "0.78rem",
    fontWeight: 900,
    opacity: 0.72,
  },
  groupItems: {
    marginTop: "0.25rem",
    paddingLeft: "0.45rem",
  },
  childLink: {
    fontSize: "0.88rem",
    fontWeight: 650,
  },
  brandText: {
    minWidth: 0,
  },
  envBadge: {
    display: "inline-flex",
    alignItems: "center",
    width: "fit-content",
    marginTop: "0.12rem",
    padding: "0.08rem 0.38rem",
    borderRadius: "999px",
    fontSize: "0.58rem",
    fontWeight: 900,
    letterSpacing: "0.08em",
    lineHeight: 1.25,
    textTransform: "uppercase",
  },
  wardSelector: {
    minWidth: "150px",
    minHeight: "2.35rem",
    padding: "0.45rem 2rem 0.45rem 0.8rem",
    borderRadius: "999px",
    border: "1px solid rgba(148, 163, 184, 0.42)",
    background: "#ffffff",
    color: "#334155",
    fontSize: "0.82rem",
    fontWeight: 800,
    cursor: "pointer",
  },
};

function getDisplayName(profile, email) {
  return (
    profile?.displayName ||
    profile?.name ||
    profile?.personal?.displayName ||
    profile?.personal?.fullName ||
    email ||
    "iREPS User"
  );
}

function getServiceProviderName(serviceProvider) {
  return serviceProvider?.name || serviceProvider?.id || "NAv";
}

function getActiveWorkbaseName(activeWorkbase) {
  return (
    activeWorkbase?.name ||
    activeWorkbase?.lmName ||
    activeWorkbase?.id ||
    activeWorkbase?.pcode ||
    "NAv"
  );
}


function getActiveLmPcode(activeWorkbase) {
  return (
    activeWorkbase?.lmPcode ||
    activeWorkbase?.pcode ||
    activeWorkbase?.id ||
    activeWorkbase?.localMunicipalityId ||
    null
  );
}

function getWardPcode(ward) {
  return ward?.id || ward?.pcode || ward?.wardPcode || "";
}

function getWardNumber(ward) {
  return ward?.code || ward?.wardNumber || ward?.number || "";
}

function getWardLabel(ward) {
  const wardNumber = getWardNumber(ward);

  return ward?.name || (wardNumber ? `Ward ${wardNumber}` : getWardPcode(ward));
}

function getEnvironmentBadgeConfig(appEnvValue) {
  const key = String(appEnvValue || "dev")
    .trim()
    .toLowerCase();

  return (
    ENVIRONMENT_BADGE_CONFIG[key] || {
      label: key ? key.toUpperCase() : "DEV",
      background: "rgba(148, 163, 184, 0.16)",
      color: "#334155",
      borderColor: "rgba(148, 163, 184, 0.35)",
    }
  );
}

function isItemAllowed(item, role) {
  return item.allowedRoles.includes(role);
}

function getVisibleItems(items = [], role) {
  return items.filter((item) => isItemAllowed(item, role));
}

function getVisibleGroups(groups = [], role) {
  return groups
    .map((group) => ({
      ...group,
      items: getVisibleItems(group.items, role),
    }))
    .filter((group) => group.items.length > 0);
}

function getVisibleSections(role) {
  return navSections
    .map((section) => ({
      ...section,
      items: getVisibleItems(section.items || [], role),
      groups: getVisibleGroups(section.groups || [], role),
    }))
    .filter(
      (section) =>
        (section.items && section.items.length > 0) ||
        (section.groups && section.groups.length > 0),
    );
}

function getFlatNavItems(sections = []) {
  return sections.flatMap((section) => {
    const directItems = section.items || [];
    const groupItems = (section.groups || []).flatMap((group) => group.items);

    return [...directItems, ...groupItems];
  });
}

function getActiveNavItem(items = [], pathname) {
  const isTbDashboardRoute =
    pathname === "/operations/tb-dashboard" ||
    /^\/operations\/targeted-batches\/[^/]+\/dashboard$/.test(pathname);

  if (isTbDashboardRoute) {
    const tbDashboardItem = items.find(
      (item) => item.path === "/operations/tb-dashboard",
    );

    if (tbDashboardItem) {
      return tbDashboardItem;
    }
  }

  if (pathname.includes("/bgo-dashboard")) {
    const bgoDashboardItem = items.find(
      (item) => item.path === "/operations/bgo-dashboard",
    );

    if (bgoDashboardItem) {
      return bgoDashboardItem;
    }
  }

  const matchingItems = items.filter((item) => pathname.startsWith(item.path));

  if (matchingItems.length === 0) {
    return items[0];
  }

  return matchingItems.sort((a, b) => b.path.length - a.path.length)[0];
}

function getPageTitle(activeNavItem, pathname) {
  if (pathname === "/operations/targeted-batches") {
    return "TB Register";
  }

  if (pathname === "/operations/targeted-batches/draft") {
    return "TB Draft";
  }

  if (/^\/operations\/targeted-batches\/[^/]+\/allocation$/.test(pathname)) {
    return "TB Allocation";
  }

  if (
    pathname === "/operations/tb-dashboard" ||
    /^\/operations\/targeted-batches\/[^/]+\/dashboard$/.test(pathname)
  ) {
    return "TB Dashboard";
  }

  if (/^\/operations\/targeted-batches\/[^/]+$/.test(pathname)) {
    return "TB Rows";
  }

  return activeNavItem?.label || "Dashboard";
}

function isGroupActive(group, pathname) {
  return (group?.items || []).some((item) => pathname.startsWith(item.path));
}

function buildToggleKey(groupLabel) {
  return String(groupLabel || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-");
}

export default function ConsoleLayout() {
  const location = useLocation();
  const [openGroups, setOpenGroups] = useState({});
  const [monitoringWardPcode, setMonitoringWardPcode] = useState("");

  const { email, profile, role, serviceProvider, activeWorkbase } = useAuth();
  const { available, scope } = useWarehouse();

  const displayName = getDisplayName(profile, email);
  const serviceProviderName = getServiceProviderName(serviceProvider);
  const activeWorkbaseName = getActiveWorkbaseName(activeWorkbase);
  const activeLmPcode = getActiveLmPcode(activeWorkbase);
  const isFwrMonitoringRoute =
    location.pathname === "/admin/fwr-monitoring";

  const warehouseMatchesActiveWorkbase =
    !scope?.lmPcode || scope.lmPcode === activeLmPcode;

  const monitoringWards = useMemo(() => {
    if (!warehouseMatchesActiveWorkbase) return [];

    return [...(available?.wards || [])].sort((a, b) => {
      const aNumber = Number(getWardNumber(a));
      const bNumber = Number(getWardNumber(b));

      if (Number.isFinite(aNumber) && Number.isFinite(bNumber)) {
        return aNumber - bNumber;
      }

      return getWardLabel(a).localeCompare(getWardLabel(b));
    });
  }, [available?.wards, warehouseMatchesActiveWorkbase]);

  useEffect(() => {
    setMonitoringWardPcode("");
  }, [activeLmPcode]);

  const visibleSections = getVisibleSections(role);
  const visibleNavItems = getFlatNavItems(visibleSections);

  const activeNavItem = getActiveNavItem(visibleNavItems, location.pathname);
  const pageTitle = getPageTitle(activeNavItem, location.pathname);
  const appEnvBadge = getEnvironmentBadgeConfig(APP_ENV_VALUE);
  const hideTopbarForRegistryRoutes =
    location.pathname === "/registries" ||
    location.pathname.startsWith("/registries/");

  function handleToggleGroup(groupLabel) {
    const key = buildToggleKey(groupLabel);

    setOpenGroups((current) => ({
      ...current,
      [key]: !current[key],
    }));
  }

  function isOpenGroup(group) {
    const key = buildToggleKey(group.label);
    return openGroups[key] === true;
  }

  async function handleSignOut() {
    await signOut(auth);
  }

  return (
    <div className="console-shell">
      <aside className="sidebar">
        <div className="sidebar-menu-shell">
          <div className="sidebar-brand">
            <div className="brand-mark">iR</div>

            <div style={sidebarStyles.brandText}>
              <h2>iREPS</h2>
              <span
                style={{
                  ...sidebarStyles.envBadge,
                  background: appEnvBadge.background,
                  color: appEnvBadge.color,
                  border: `1px solid ${appEnvBadge.borderColor}`,
                }}
                title={`iREPS Web environment: ${appEnvBadge.label}`}
              >
                {appEnvBadge.label}
              </span>
            </div>
          </div>

          <nav>
            {visibleSections.map((section, sectionIndex) => (
              <div
                key={section.title || `section-${sectionIndex}`}
                className="sidebar-section"
              >
                {section.title ? (
                  <p className="sidebar-section-title">{section.title}</p>
                ) : null}

                {(section.items || []).map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    className={({ isActive }) => (isActive ? "active" : "")}
                    style={sidebarStyles.mainLink}
                  >
                    {item.label}
                  </NavLink>
                ))}

                {(section.groups || []).map((group) => {
                  const groupOpen = isOpenGroup(group);
                  const groupActive = isGroupActive(group, location.pathname);

                  return (
                    <div key={group.label} className="sidebar-nav-group">
                      <button
                        type="button"
                        className={`sidebar-group-title-button${
                          groupActive ? " active" : ""
                        }`}
                        style={{
                          ...sidebarStyles.groupButton,
                          ...(groupOpen || groupActive
                            ? sidebarStyles.groupButtonOpen
                            : null),
                        }}
                        onClick={() => handleToggleGroup(group.label)}
                        aria-expanded={groupOpen}
                        aria-controls={`sidebar-group-${buildToggleKey(group.label)}`}
                      >
                        <span>{group.label}</span>
                        <span style={sidebarStyles.groupArrow}>
                          {groupOpen ? "▾" : "▸"}
                        </span>
                      </button>

                      {groupOpen ? (
                        <div
                          id={`sidebar-group-${buildToggleKey(group.label)}`}
                          style={sidebarStyles.groupItems}
                        >
                          {group.items.map((item) => (
                            <NavLink
                              key={item.path}
                              to={item.path}
                              className={({ isActive }) =>
                                isActive ? "active" : ""
                              }
                              style={sidebarStyles.childLink}
                            >
                              {item.label}
                            </NavLink>
                          ))}
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            ))}
          </nav>
        </div>

        <div className="sidebar-footer">
          <div className="sidebar-user">
            <strong>{displayName}</strong>
            <span>{email || "NAv"}</span>
            <span>{serviceProviderName}</span>
          </div>

          <NavLink to="/profile" className="secondary-button">
            Profile
          </NavLink>

          <button className="secondary-button" onClick={handleSignOut}>
            Sign out
          </button>
        </div>
      </aside>

      <main className="console-main" style={{ paddingTop: 0 }}>
        {!hideTopbarForRegistryRoutes ? (
          <header className="topbar">
            <div>
              <p className="eyebrow">iREPS Desktop</p>
              <h1>{pageTitle}</h1>
            </div>

            <div className="topbar-right">
              <div className="workbase-pill">{activeWorkbaseName}</div>

              {isFwrMonitoringRoute ? (
                <select
                  aria-label="Select monitoring ward"
                  value={monitoringWardPcode}
                  onChange={(event) =>
                    setMonitoringWardPcode(event.target.value)
                  }
                  style={sidebarStyles.wardSelector}
                  disabled={!monitoringWards.length}
                >
                  <option value="">All Wards</option>

                  {monitoringWards.map((ward) => {
                    const wardPcode = getWardPcode(ward);

                    return (
                      <option key={wardPcode} value={wardPcode}>
                        {getWardLabel(ward)}
                      </option>
                    );
                  })}
                </select>
              ) : null}

              <div className="role-pill">{role || "NAv"}</div>
            </div>
          </header>
        ) : null}

        <Outlet
          context={{
            monitoringWardPcode,
            setMonitoringWardPcode,
          }}
        />
      </main>
    </div>
  );
}
