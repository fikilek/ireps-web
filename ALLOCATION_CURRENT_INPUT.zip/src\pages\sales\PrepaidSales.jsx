/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { skipToken } from "@reduxjs/toolkit/query";

import { useAuth } from "../../auth/useAuth";
import { useGetDemoSalesByLmPcodeQuery } from "../../redux/demoSalesApi";
import { prepareTargetedBatchDraft } from "../../redux/targetedBatchDraftSlice";
import { quickDownloadExcel } from "../../utils/downloads/quickDownloadExcel";
import SalesMetersTable from "./components/SalesMetersTable";
import SalesTrendChart from "./components/SalesTrendChart";
import { normalizeSalesTargetRows } from "../operations/targeted-batches/targetedBatchUtils";
import {
  SALES_TARGET_THRESHOLDS_C,
  TARGET_FILTERS,
  buildMonthKeys,
  formatCompactCurrencyFromCents,
  formatCurrencyFromCents,
  formatNumber,
  getActiveLmPcode,
  getActiveWorkbaseName,
  getMonthLabel,
  getTargetFilterLabel,
} from "./salesUtils";

function SalesLoadingState() {
  return (
    <section style={styles.loadingPanel} aria-live="polite" aria-busy="true">
      <style>
        {`
          @keyframes irepsSalesSpinner {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        `}
      </style>

      <div style={styles.loadingSpinner} aria-hidden="true" />

      <div>
        <h2 style={styles.loadingTitle}>Loading prepaid sales...</h2>
        <p style={styles.loadingText}>
          Connecting to the live Sales stream and preparing meter records.
        </p>
      </div>
    </section>
  );
}

function SummaryCard({ label, value, subtitle, active, onClick }) {
  const interactive = typeof onClick === "function";

  return (
    <button
      type="button"
      style={{
        ...styles.summaryCard,
        ...(interactive ? styles.summaryCardInteractive : null),
        ...(active ? styles.summaryCardActive : null),
      }}
      onClick={onClick}
      disabled={!interactive}
    >
      <span style={styles.summaryLabel}>{label}</span>
      <strong style={styles.summaryValue}>{value}</strong>
      {subtitle ? <span style={styles.summarySubtitle}>{subtitle}</span> : null}
    </button>
  );
}

function TargetingButton({ label, active, onClick }) {
  return (
    <button
      type="button"
      style={{
        ...styles.targetButton,
        ...(active ? styles.targetButtonActive : null),
      }}
      onClick={onClick}
    >
      {label}
    </button>
  );
}

function TargetBatchModal({
  selectedCount,
  scopeError,
  onClose,
  onDownload,
  onOpenTargetedBatch,
}) {
  return (
    <div
      style={styles.modalOverlay}
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div style={styles.modalCard} role="dialog" aria-modal="true">
        <div style={styles.modalHeader}>
          <div>
            <p style={styles.modalEyebrow}>Targeted Field Work</p>
            <h2 style={styles.modalTitle}>Create Target Batch</h2>
          </div>

          <button
            type="button"
            style={styles.modalCloseButton}
            onClick={onClose}
          >
            ✕
          </button>
        </div>

        <div style={styles.modalBody}>
          <div style={styles.modalCountBox}>
            <span>Selected meters</span>
            <strong>{formatNumber(selectedCount)}</strong>
          </div>

          {scopeError ? (
            <div style={styles.modalErrorBox} role="alert">
              {scopeError}
            </div>
          ) : null}

          <p style={styles.modalText}>
            The selected meters will be transferred to the dedicated Targeted
            Batch page as one draft. The selection is preserved across all
            filtered pagination pages.
          </p>

          <p style={styles.modalText}>
            On the Targeted Batch page, review the meter list and confirm the
            draft before backend batch creation and TRN origination are added.
          </p>
        </div>

        <div style={styles.modalFooter}>
          <button
            type="button"
            style={styles.secondaryButton}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            type="button"
            style={styles.secondaryButton}
            onClick={onDownload}
          >
            Download Selected
          </button>
          <button
            type="button"
            style={styles.primaryButton}
            onClick={onOpenTargetedBatch}
          >
            Review Targeted Batch
          </button>
        </div>
      </div>
    </div>
  );
}

export default function PrepaidSales() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { activeWorkbase, role } = useAuth();
  const activeLmPcode = getActiveLmPcode(activeWorkbase);
  const activeWorkbaseName = getActiveWorkbaseName(activeWorkbase);

  const [trendMode, setTrendMode] = useState("SALES");
  const [targetFilter, setTargetFilter] = useState(TARGET_FILTERS.ALL);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [isTargetBatchModalOpen, setIsTargetBatchModalOpen] = useState(false);
  const [targetBatchScopeError, setTargetBatchScopeError] = useState("");

  const {
    data: salesRows = [],
    isLoading,
    isFetching,
    error,
    refetch,
  } = useGetDemoSalesByLmPcodeQuery(activeLmPcode || skipToken);

  useEffect(() => {
    setSelectedIds(new Set());
    setIsTargetBatchModalOpen(false);
    setTargetBatchScopeError("");
  }, [activeLmPcode]);

  const monthKeys = useMemo(() => buildMonthKeys(salesRows), [salesRows]);
  const latestMonthKey = monthKeys[0] || "2026-02";
  const earliestMonthKey = monthKeys[monthKeys.length - 1] || "2023-12";

  const summary = useMemo(() => {
    return salesRows.reduce(
      (accumulator, row) => {
        accumulator.totalMeters += 1;
        accumulator.totalSalesC += Number(row?.totalSalesC || 0);
        if (Number(row?.sales3MonthsC || 0) === 0) accumulator.noSales3M += 1;
        if (Number(row?.sales6MonthsC || 0) === 0) accumulator.noSales6M += 1;
        const latest12MonthsSalesC = Number(row?.sales12MonthsC || 0);
        if (latest12MonthsSalesC === 0) accumulator.noSales12M += 1;
        if (latest12MonthsSalesC < SALES_TARGET_THRESHOLDS_C.BELOW_R400_X_12) {
          accumulator.belowR400X12 += 1;
        }
        if (latest12MonthsSalesC < SALES_TARGET_THRESHOLDS_C.BELOW_R200_X_12) {
          accumulator.belowR200X12 += 1;
        }
        if (Number(row?.totalSalesC || 0) === 0) accumulator.neverVended += 1;
        return accumulator;
      },
      {
        totalMeters: 0,
        totalSalesC: 0,
        noSales3M: 0,
        noSales6M: 0,
        noSales12M: 0,
        belowR400X12: 0,
        belowR200X12: 0,
        neverVended: 0,
      },
    );
  }, [salesRows]);

  const selectedRows = useMemo(() => {
    if (selectedIds.size === 0) return [];
    return salesRows.filter((row) => selectedIds.has(row.id));
  }, [salesRows, selectedIds]);

  const selectedDownloadColumns = useMemo(() => {
    return [
      { header: "Meter Number", value: (row) => row.meterNo || "NAv" },
      { header: "Address", value: (row) => row.addressLine1 || "NAv" },
      { header: "Town", value: (row) => row.town || "NAv" },
      { header: "SG Code", value: (row) => row.standNumber || "NAv" },
      {
        header: "Total Sales (R)",
        value: (row) => Number(row.totalSalesC || 0) / 100,
      },
      ...monthKeys.map((monthKey) => ({
        header: `${getMonthLabel(monthKey)} (R)`,
        value: (row) => Number(row?.monthlySalesC?.[monthKey] || 0) / 100,
      })),
    ];
  }, [monthKeys]);

  function setTarget(target) {
    setTargetFilter(target);
  }

  function handleOpenTargetedBatch() {
    setTargetBatchScopeError("");

    if (!activeLmPcode) {
      setTargetBatchScopeError(
        "Targeted Batch creation is blocked because there is no active Local Municipality workbase.",
      );
      return;
    }

    if (selectedRows.length === 0) {
      setTargetBatchScopeError(
        "Targeted Batch creation is blocked because no Sales meters are selected.",
      );
      return;
    }

    const mismatchedRows = selectedRows.filter(
      (row) => String(row?.lmPcode || "").trim() !== activeLmPcode,
    );

    if (mismatchedRows.length > 0) {
      setTargetBatchScopeError(
        `Targeted Batch creation is blocked because ${formatNumber(
          mismatchedRows.length,
        )} selected meter${
          mismatchedRows.length === 1 ? "" : "s"
        } do not belong to the active LM ${activeLmPcode}. Clear the selection and reload Sales.`,
      );
      return;
    }

    const targetLabel = getTargetFilterLabel(targetFilter);
    const selectionReason =
      targetFilter === TARGET_FILTERS.ALL
        ? "Selected from Prepaid Sales filters"
        : targetLabel;

    const displayRows = normalizeSalesTargetRows(
      selectedRows,
      selectionReason,
    );
    const salesAllMeterIds = displayRows
      .map((row) => row.salesAllMeterId)
      .filter(Boolean);

    dispatch(
      prepareTargetedBatchDraft({
        source: {
          type: "PREPAID_SALES",
          label: "Prepaid Sales",
          sourceId: null,
          fileName: null,
        },
        scope: {
          lmPcode: activeLmPcode || "",
          lmName: activeWorkbaseName,
        },
        selection: {
          reason: selectionReason,
          salesPeriodFrom: earliestMonthKey,
          salesPeriodTo: latestMonthKey,
        },
        authoritativeIds: {
          salesAllMeterIds,
          uploadRowIds: [],
        },
        displayRows,
        validation: {
          status: "PASSED",
          passed: true,
          totalRows: displayRows.length,
          acceptedRows: displayRows.length,
          rejectedRows: 0,
          duplicateRowNos: [],
          duplicateMeterNos: [],
          invalidRowDetails: [],
          errors: [],
          warnings: [],
        },
      }),
    );

    setIsTargetBatchModalOpen(false);
    navigate("/operations/targeted-batches/draft");
  }

  function handleDownloadSelected() {
    if (selectedRows.length === 0) return;

    quickDownloadExcel({
      rows: selectedRows,
      columns: selectedDownloadColumns,
      fileBaseName: "selected_prepaid_sales_meters",
      registryName: "Selected Prepaid Sales Meters",
      scope: {
        lmName: activeWorkbaseName,
        lmPcode: activeLmPcode || "NAv",
        wardLabel: "Targeted Meter Selection",
      },
    });

    setIsTargetBatchModalOpen(false);
  }

  return (
    <div style={styles.page}>
      <section style={styles.hero}>
        <div>
          <div style={styles.heroEyebrowRow}>
            <p style={styles.heroEyebrow}>Prepaid Sales</p>
            <span style={styles.demoBadge}>Demo Data</span>
          </div>

          <h1 style={styles.heroTitle}>
            Meter vending performance and targeted field-work identification
          </h1>

          <p style={styles.heroSubtitle}>
            {activeLmPcode || "NAv"} · {activeWorkbaseName} · Data period:{" "}
            {getMonthLabel(earliestMonthKey)} to {getMonthLabel(latestMonthKey)}
          </p>
        </div>

        <div style={styles.heroActions}>
          <div style={styles.roleBadge}>{role || "NAv"}</div>
          <button
            type="button"
            style={styles.refreshButton}
            onClick={() => refetch()}
            disabled={!activeLmPcode || isFetching}
          >
            {isFetching ? "Refreshing..." : "Refresh Sales"}
          </button>
        </div>
      </section>

      {!activeLmPcode ? (
        <section style={styles.statePanel}>
          <h2>No active workbase</h2>
          <p>
            Activate a Local Municipality workbase before opening Prepaid Sales.
          </p>
        </section>
      ) : null}

      {error ? (
        <section style={{ ...styles.statePanel, ...styles.errorPanel }}>
          <h2>Could not load prepaid sales</h2>
          <p>
            Check Firestore access to demo_sales_meters and confirm that the
            records contain lmPcode {activeLmPcode}.
          </p>
        </section>
      ) : null}

      {isLoading ? <SalesLoadingState /> : null}

      {!isLoading && activeLmPcode && !error && salesRows.length === 0 ? (
        <section style={styles.statePanel}>
          <h2>No prepaid sales found</h2>
          <p>No demo sales meters were returned for {activeLmPcode}.</p>
        </section>
      ) : null}

      {salesRows.length > 0 ? (
        <>
          <section style={styles.summaryGrid}>
            <SummaryCard
              label="Total Meters"
              value={formatNumber(summary.totalMeters)}
              subtitle="Loaded prepaid sales meters"
            />
            <SummaryCard
              label="Total Sales"
              value={formatCompactCurrencyFromCents(summary.totalSalesC)}
              subtitle={formatCurrencyFromCents(summary.totalSalesC)}
            />
            <SummaryCard
              label="No Sales 3M"
              value={formatNumber(summary.noSales3M)}
              subtitle="Click to target"
              active={targetFilter === TARGET_FILTERS.NO_SALES_3M}
              onClick={() => setTarget(TARGET_FILTERS.NO_SALES_3M)}
            />
            <SummaryCard
              label="No Sales 6M"
              value={formatNumber(summary.noSales6M)}
              subtitle="Click to target"
              active={targetFilter === TARGET_FILTERS.NO_SALES_6M}
              onClick={() => setTarget(TARGET_FILTERS.NO_SALES_6M)}
            />
            <SummaryCard
              label="No Sales 12M"
              value={formatNumber(summary.noSales12M)}
              subtitle="Click to target"
              active={targetFilter === TARGET_FILTERS.NO_SALES_12M}
              onClick={() => setTarget(TARGET_FILTERS.NO_SALES_12M)}
            />
            <SummaryCard
              label="Below R400 × 12M"
              value={formatNumber(summary.belowR400X12)}
              subtitle="Latest 12 months below R4,800"
              active={targetFilter === TARGET_FILTERS.BELOW_R400_X_12}
              onClick={() => setTarget(TARGET_FILTERS.BELOW_R400_X_12)}
            />
            <SummaryCard
              label="Below R200 × 12M"
              value={formatNumber(summary.belowR200X12)}
              subtitle="Latest 12 months below R2,400"
              active={targetFilter === TARGET_FILTERS.BELOW_R200_X_12}
              onClick={() => setTarget(TARGET_FILTERS.BELOW_R200_X_12)}
            />
            <SummaryCard
              label="Never Vended"
              value={formatNumber(summary.neverVended)}
              subtitle="Click to target"
              active={targetFilter === TARGET_FILTERS.NEVER_VENDED}
              onClick={() => setTarget(TARGET_FILTERS.NEVER_VENDED)}
            />
          </section>

          <SalesTrendChart
            rows={salesRows}
            monthKeys={monthKeys}
            mode={trendMode}
            onModeChange={setTrendMode}
          />

          <section style={styles.targetPanel}>
            <div>
              <p style={styles.targetEyebrow}>Targeting Shortcuts</p>
              <h2 style={styles.targetTitle}>
                Identify meters for field investigation
              </h2>
            </div>

            <div style={styles.targetButtons}>
              <TargetingButton
                label="No sales 3 months"
                active={targetFilter === TARGET_FILTERS.NO_SALES_3M}
                onClick={() => setTarget(TARGET_FILTERS.NO_SALES_3M)}
              />
              <TargetingButton
                label="No sales 6 months"
                active={targetFilter === TARGET_FILTERS.NO_SALES_6M}
                onClick={() => setTarget(TARGET_FILTERS.NO_SALES_6M)}
              />
              <TargetingButton
                label="No sales 12 months"
                active={targetFilter === TARGET_FILTERS.NO_SALES_12M}
                onClick={() => setTarget(TARGET_FILTERS.NO_SALES_12M)}
              />
              <TargetingButton
                label="Below R400 × 12 months"
                active={targetFilter === TARGET_FILTERS.BELOW_R400_X_12}
                onClick={() => setTarget(TARGET_FILTERS.BELOW_R400_X_12)}
              />
              <TargetingButton
                label="Below R200 × 12 months"
                active={targetFilter === TARGET_FILTERS.BELOW_R200_X_12}
                onClick={() => setTarget(TARGET_FILTERS.BELOW_R200_X_12)}
              />
              <TargetingButton
                label="Never purchased"
                active={targetFilter === TARGET_FILTERS.NEVER_VENDED}
                onClick={() => setTarget(TARGET_FILTERS.NEVER_VENDED)}
              />
              <TargetingButton
                label={`${getMonthLabel(latestMonthKey)} sales = R0`}
                active={targetFilter === TARGET_FILTERS.LATEST_MONTH_ZERO}
                onClick={() => setTarget(TARGET_FILTERS.LATEST_MONTH_ZERO)}
              />
              <TargetingButton
                label="Clear targeting"
                active={targetFilter === TARGET_FILTERS.ALL}
                onClick={() => setTarget(TARGET_FILTERS.ALL)}
              />
            </div>
          </section>

          <SalesMetersTable
            rows={salesRows}
            monthKeys={monthKeys}
            targetFilter={targetFilter}
            selectedIds={selectedIds}
            onSelectedIdsChange={setSelectedIds}
          />

          {selectedRows.length > 0 ? (
            <section style={styles.selectionBar}>
              <div>
                <strong style={styles.selectionCount}>
                  {formatNumber(selectedRows.length)} meters selected
                </strong>
                <span style={styles.selectionHint}>
                  Selection is retained while paging and filtering.
                </span>
              </div>

              <div style={styles.selectionActions}>
                <button
                  type="button"
                  style={styles.secondaryButton}
                  onClick={() => setSelectedIds(new Set())}
                >
                  Clear Selection
                </button>
                <button
                  type="button"
                  style={styles.secondaryButton}
                  onClick={handleDownloadSelected}
                >
                  Download Selected
                </button>
                <button
                  type="button"
                  style={styles.primaryButton}
                  onClick={() => {
                    setTargetBatchScopeError("");
                    setIsTargetBatchModalOpen(true);
                  }}
                >
                  Create Target Batch
                </button>
              </div>
            </section>
          ) : null}
        </>
      ) : null}

      {isTargetBatchModalOpen ? (
        <TargetBatchModal
          selectedCount={selectedRows.length}
          scopeError={targetBatchScopeError}
          onClose={() => {
            setTargetBatchScopeError("");
            setIsTargetBatchModalOpen(false);
          }}
          onDownload={handleDownloadSelected}
          onOpenTargetedBatch={handleOpenTargetedBatch}
        />
      ) : null}
    </div>
  );
}

const styles = {
  page: {
    display: "grid",
    gap: "1rem",
    padding: "1rem 1.25rem 5.5rem",
  },
  hero: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "1rem",
    padding: "1.15rem",
    borderRadius: "1rem",
    background: "linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%)",
    color: "#ffffff",
    boxShadow: "0 16px 32px rgba(15, 23, 42, 0.16)",
    flexWrap: "wrap",
  },
  heroEyebrowRow: {
    display: "flex",
    alignItems: "center",
    gap: "0.55rem",
  },
  heroEyebrow: {
    margin: 0,
    color: "#bfdbfe",
    fontSize: "0.74rem",
    fontWeight: 900,
    letterSpacing: "0.11em",
    textTransform: "uppercase",
  },
  demoBadge: {
    display: "inline-flex",
    alignItems: "center",
    borderRadius: "999px",
    padding: "0.18rem 0.5rem",
    background: "rgba(254, 240, 138, 0.18)",
    border: "1px solid rgba(254, 240, 138, 0.48)",
    color: "#fef08a",
    fontSize: "0.66rem",
    fontWeight: 900,
    textTransform: "uppercase",
  },
  heroTitle: {
    maxWidth: "760px",
    margin: "0.4rem 0 0",
    fontSize: "1.5rem",
    lineHeight: 1.25,
  },
  heroSubtitle: {
    margin: "0.55rem 0 0",
    color: "#cbd5e1",
    fontSize: "0.9rem",
  },
  heroActions: {
    display: "flex",
    alignItems: "center",
    gap: "0.55rem",
    flexWrap: "wrap",
  },
  roleBadge: {
    borderRadius: "999px",
    padding: "0.42rem 0.7rem",
    background: "rgba(255, 255, 255, 0.12)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    fontSize: "0.75rem",
    fontWeight: 900,
  },
  refreshButton: {
    border: "1px solid rgba(255, 255, 255, 0.32)",
    borderRadius: "0.7rem",
    padding: "0.55rem 0.75rem",
    background: "rgba(255, 255, 255, 0.1)",
    color: "#ffffff",
    fontWeight: 850,
    cursor: "pointer",
  },
  loadingPanel: {
    display: "flex",
    alignItems: "center",
    gap: "1rem",
    marginTop: "1rem",
    padding: "1.4rem 1.5rem",
    border: "1px solid rgba(37, 99, 235, 0.2)",
    borderRadius: "1rem",
    background: "#ffffff",
    boxShadow: "0 12px 28px rgba(15, 23, 42, 0.05)",
  },
  loadingSpinner: {
    width: "2.35rem",
    height: "2.35rem",
    flex: "0 0 auto",
    border: "4px solid #dbeafe",
    borderTopColor: "#2563eb",
    borderRadius: "999px",
    animation: "irepsSalesSpinner 0.8s linear infinite",
  },
  loadingTitle: {
    margin: 0,
    color: "#0f172a",
    fontSize: "1.08rem",
  },
  loadingText: {
    margin: "0.3rem 0 0",
    color: "#64748b",
    fontSize: "0.88rem",
  },
  statePanel: {
    padding: "1.25rem",
    borderRadius: "1rem",
    background: "#ffffff",
    border: "1px solid rgba(148, 163, 184, 0.28)",
    color: "#475569",
  },
  errorPanel: {
    borderColor: "rgba(220, 38, 38, 0.3)",
    background: "#fef2f2",
  },
  summaryGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))",
    gap: "0.8rem",
  },
  summaryCard: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    minHeight: "112px",
    padding: "0.95rem",
    borderRadius: "0.95rem",
    border: "1px solid rgba(148, 163, 184, 0.26)",
    background: "#ffffff",
    color: "#0f172a",
    textAlign: "left",
    boxShadow: "0 12px 26px rgba(15, 23, 42, 0.05)",
  },
  summaryCardInteractive: {
    cursor: "pointer",
  },
  summaryCardActive: {
    border: "2px solid #2563eb",
    background: "#eff6ff",
  },
  summaryLabel: {
    color: "#64748b",
    fontSize: "0.78rem",
    fontWeight: 850,
    textTransform: "uppercase",
    letterSpacing: "0.05em",
  },
  summaryValue: {
    marginTop: "0.45rem",
    fontSize: "1.55rem",
    lineHeight: 1.1,
  },
  summarySubtitle: {
    marginTop: "auto",
    paddingTop: "0.45rem",
    color: "#64748b",
    fontSize: "0.75rem",
  },
  targetPanel: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "1rem",
    padding: "1rem",
    borderRadius: "1rem",
    background: "#ffffff",
    border: "1px solid rgba(148, 163, 184, 0.26)",
    boxShadow: "0 12px 26px rgba(15, 23, 42, 0.05)",
    flexWrap: "wrap",
  },
  targetEyebrow: {
    margin: 0,
    color: "#2563eb",
    fontSize: "0.72rem",
    fontWeight: 900,
    letterSpacing: "0.08em",
    textTransform: "uppercase",
  },
  targetTitle: {
    margin: "0.2rem 0 0",
    color: "#0f172a",
    fontSize: "1.05rem",
  },
  targetButtons: {
    display: "flex",
    gap: "0.45rem",
    flexWrap: "wrap",
  },
  targetButton: {
    border: "1px solid rgba(148, 163, 184, 0.42)",
    borderRadius: "999px",
    padding: "0.5rem 0.75rem",
    background: "#ffffff",
    color: "#334155",
    fontWeight: 800,
    cursor: "pointer",
  },
  targetButtonActive: {
    borderColor: "#2563eb",
    background: "#2563eb",
    color: "#ffffff",
  },
  selectionBar: {
    position: "fixed",
    right: "1.25rem",
    bottom: "1rem",
    left: "calc(250px + 1.25rem)",
    zIndex: 40,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "1rem",
    padding: "0.85rem 1rem",
    borderRadius: "0.95rem",
    background: "#0f172a",
    color: "#ffffff",
    boxShadow: "0 20px 40px rgba(15, 23, 42, 0.28)",
    flexWrap: "wrap",
  },
  selectionCount: {
    display: "block",
    fontSize: "0.95rem",
  },
  selectionHint: {
    display: "block",
    marginTop: "0.2rem",
    color: "#cbd5e1",
    fontSize: "0.75rem",
  },
  selectionActions: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    flexWrap: "wrap",
  },
  primaryButton: {
    border: "1px solid #2563eb",
    borderRadius: "0.7rem",
    padding: "0.55rem 0.75rem",
    background: "#2563eb",
    color: "#ffffff",
    fontWeight: 850,
    cursor: "pointer",
  },
  secondaryButton: {
    border: "1px solid rgba(148, 163, 184, 0.5)",
    borderRadius: "0.7rem",
    padding: "0.55rem 0.75rem",
    background: "#ffffff",
    color: "#0f172a",
    fontWeight: 850,
    cursor: "pointer",
  },
  modalOverlay: {
    position: "fixed",
    inset: 0,
    zIndex: 100,
    display: "grid",
    placeItems: "center",
    padding: "1rem",
    background: "rgba(15, 23, 42, 0.68)",
  },
  modalCard: {
    width: "min(560px, 100%)",
    borderRadius: "1rem",
    background: "#ffffff",
    boxShadow: "0 28px 70px rgba(15, 23, 42, 0.34)",
    overflow: "hidden",
  },
  modalHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "1rem",
    padding: "1rem 1.1rem",
    borderBottom: "1px solid #e2e8f0",
  },
  modalEyebrow: {
    margin: 0,
    color: "#2563eb",
    fontSize: "0.7rem",
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
  },
  modalTitle: {
    margin: "0.2rem 0 0",
    color: "#0f172a",
  },
  modalCloseButton: {
    border: 0,
    background: "transparent",
    color: "#64748b",
    fontSize: "1rem",
    cursor: "pointer",
  },
  modalBody: {
    display: "grid",
    gap: "0.8rem",
    padding: "1rem 1.1rem",
  },
  modalCountBox: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0.8rem",
    borderRadius: "0.8rem",
    background: "#eff6ff",
    color: "#1e3a8a",
    fontWeight: 850,
  },
  modalErrorBox: {
    padding: "0.75rem 0.8rem",
    border: "1px solid #fecaca",
    borderRadius: "0.7rem",
    background: "#fef2f2",
    color: "#b91c1c",
    fontSize: "0.82rem",
    fontWeight: 800,
    lineHeight: 1.45,
  },
  modalText: {
    margin: 0,
    color: "#475569",
    lineHeight: 1.55,
  },
  modalFooter: {
    display: "flex",
    justifyContent: "flex-end",
    gap: "0.55rem",
    padding: "1rem 1.1rem",
    borderTop: "1px solid #e2e8f0",
  },
};
