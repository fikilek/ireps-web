import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const repoRoot = path.resolve(process.argv[2] || process.cwd());

const apiPath = path.join(repoRoot, "src", "redux", "demoSalesApi.js");
const tablePath = path.join(
  repoRoot,
  "src",
  "pages",
  "sales",
  "components",
  "SalesMetersTable.jsx",
);
const modalPath = path.join(
  repoRoot,
  "src",
  "pages",
  "sales",
  "components",
  "SalesTbRefsModal.jsx",
);
const packagedModalPath = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "SalesTbRefsModal.jsx",
);

for (const filePath of [apiPath, tablePath]) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Required file not found: ${filePath}`);
  }
}

if (!fs.existsSync(packagedModalPath)) {
  throw new Error(`Packaged modal file not found: ${packagedModalPath}`);
}

function normalizeLf(value) {
  return String(value).replace(/\r\n/g, "\n");
}

function restoreLineEndings(value, original) {
  return original.includes("\r\n") ? value.replace(/\n/g, "\r\n") : value;
}

function countOccurrences(text, search) {
  return search ? text.split(search).length - 1 : 0;
}

function replaceOnce(text, search, replacement, label) {
  const count = countOccurrences(text, search);

  if (count !== 1) {
    throw new Error(
      `${label}: expected exactly one anchor but found ${count}. No files were written.`,
    );
  }

  return text.replace(search, replacement);
}

function patchWithinSection(text, startToken, endToken, patcher, label) {
  const start = text.indexOf(startToken);
  const end = text.indexOf(endToken, start + startToken.length);

  if (start < 0 || end < 0 || end <= start) {
    throw new Error(`${label}: section boundaries not found. No files were written.`);
  }

  return (
    text.slice(0, start) +
    patcher(text.slice(start, end)) +
    text.slice(end)
  );
}

function patchApi(source) {
  let text = normalizeLf(source);

  if (!text.includes("function normalizeTbRefs(")) {
    const helper = `function normalizeTbRefs(value = []) {
  const seen = new Set();

  return (Array.isArray(value) ? value : [])
    .map((item) => {
      const id = String(item?.id || item?.tbId || "").trim();
      const rowId = String(item?.rowId || item?.tbRowId || "").trim();

      if (!id) return null;

      return {
        ...item,
        id,
        rowId: rowId || null,
        date: item?.date ?? item?.addedAt ?? item?.createdAt ?? null,
        fieldWork:
          item?.fieldWork && typeof item.fieldWork === "object"
            ? item.fieldWork
            : null,
      };
    })
    .filter((item) => {
      const key = \`\${item.id}::\${item.rowId || ""}\`;

      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((left, right) => {
      const leftDate = String(left?.date || "");
      const rightDate = String(right?.date || "");
      const dateComparison = rightDate.localeCompare(leftDate);

      if (dateComparison !== 0) return dateComparison;

      return String(left.id).localeCompare(String(right.id), undefined, {
        numeric: true,
        sensitivity: "base",
      });
    });
}

`;

    text = replaceOnce(
      text,
      'function normalizeDemoSalesRow(id, data = {}, requestedLmPcode = "") {',
      `${helper}function normalizeDemoSalesRow(id, data = {}, requestedLmPcode = "") {`,
      "demoSalesApi TB normalizer insertion",
    );
  }

  if (!text.includes("tbRefs: normalizeTbRefs(")) {
    text = replaceOnce(
      text,
      "    trnBatchIds: Array.isArray(data.trnBatchIds) ? data.trnBatchIds : [],",
      `    tbRefs: normalizeTbRefs(data.tbRefs || data.TbRefs || []),
    trnBatchIds: Array.isArray(data.trnBatchIds) ? data.trnBatchIds : [],`,
      "demoSalesApi normalized tbRefs field",
    );
  }

  return text;
}

function patchTable(source) {
  let text = normalizeLf(source);

  if (!text.includes('import SalesTbRefsModal from "./SalesTbRefsModal";')) {
    text = replaceOnce(
      text,
      'import MeterLocationModal from "./MeterLocationModal";\n',
      'import MeterLocationModal from "./MeterLocationModal";\nimport SalesTbRefsModal from "./SalesTbRefsModal";\n',
      "Sales table TB modal import",
    );
  }

  if (!text.includes("  tbRefs: true,")) {
    const visibilityAnchor = text.includes("  geofence: true,\n")
      ? "  geofence: true,\n"
      : "  wardNo: true,\n";

    text = replaceOnce(
      text,
      visibilityAnchor,
      `${visibilityAnchor}  tbRefs: true,\n`,
      "Sales table TB default visibility",
    );
  }

  if (!text.includes('{ key: "tbRefs", label: "TB IDs" }')) {
    const optionAnchor = text.includes(
      '  { key: "geofence", label: "Geofences" },\n',
    )
      ? '  { key: "geofence", label: "Geofences" },\n'
      : '  { key: "wardNo", label: "Ward No" },\n';

    text = replaceOnce(
      text,
      optionAnchor,
      `${optionAnchor}  { key: "tbRefs", label: "TB IDs" },\n`,
      "Sales table TB column option",
    );
  }

  if (!text.includes("  tbRefs: 130,")) {
    const widthAnchor = text.includes("  geofence: 220,\n")
      ? "  geofence: 220,\n"
      : "  wardNo: 105,\n";

    text = replaceOnce(
      text,
      widthAnchor,
      `${widthAnchor}  tbRefs: 130,\n`,
      "Sales table TB column width",
    );
  }

  if (!text.includes("function getRowTbRefs(")) {
    const helper = `function getRowTbRefs(row = {}) {
  return Array.isArray(row?.tbRefs)
    ? row.tbRefs.filter((ref) => ref?.id)
    : [];
}

function getTbCountLabel(row = {}) {
  const count = getRowTbRefs(row).length;
  return \`\${count} \${count === 1 ? "TB" : "TBs"}\`;
}

`;

    text = replaceOnce(
      text,
      "function getSortValue(row, sortKey) {",
      `${helper}function getSortValue(row, sortKey) {`,
      "Sales table TB helper insertion",
    );
  }

  if (!text.includes('if (sortKey === "tbRefs")')) {
    const sortAnchor = text.includes(
      '  if (sortKey === "geofence") return getRowGeofenceLabel(row);\n',
    )
      ? '  if (sortKey === "geofence") return getRowGeofenceLabel(row);\n'
      : '  if (sortKey === "wardNo") return row?.wardNumberLabel || "";\n';

    text = replaceOnce(
      text,
      sortAnchor,
      `${sortAnchor}  if (sortKey === "tbRefs") return getRowTbRefs(row).length;\n`,
      "Sales table TB count sort",
    );
  }

  if (!text.includes("  const [tbRefsRow, setTbRefsRow] = useState(null);")) {
    text = replaceOnce(
      text,
      "  const [mapRow, setMapRow] = useState(null);\n",
      "  const [mapRow, setMapRow] = useState(null);\n  const [tbRefsRow, setTbRefsRow] = useState(null);\n",
      "Sales table TB modal state",
    );
  }

  if (!text.includes('label="TB IDs"')) {
    const header = `              {columnVisibility.tbRefs ? (
                <th
                  style={{
                    ...styles.headerCell,
                    ...getStickyStyle("tbRefs", stickyLayout, true),
                  }}
                >
                  <SortButton
                    label="TB IDs"
                    sortKey="tbRefs"
                    sortConfig={sortConfig}
                    onSort={handleSort}
                  />
                </th>
              ) : null}

`;

    text = patchWithinSection(
      text,
      "<thead>",
      "</thead>",
      (section) =>
        replaceOnce(
          section,
          "              {columnVisibility.addressLine1 ? (\n",
          `${header}              {columnVisibility.addressLine1 ? (\n`,
          "Sales table TB header position",
        ),
      "Sales table header",
    );
  }

  if (!text.includes("setTbRefsRow(row)")) {
    const body = `                  {columnVisibility.tbRefs ? (
                    <td
                      style={{
                        ...styles.bodyCell,
                        ...getStickyStyle("tbRefs", stickyLayout),
                        textAlign: "center",
                      }}
                    >
                      {getRowTbRefs(row).length > 0 ? (
                        <button
                          type="button"
                          onClick={() => setTbRefsRow(row)}
                          title={\`Open Targeted Batch references for meter \${row.meterNo}\`}
                          style={{
                            border: "1px solid #2563eb",
                            borderRadius: "999px",
                            padding: "0.32rem 0.58rem",
                            background: "#eff6ff",
                            color: "#1d4ed8",
                            fontSize: "0.75rem",
                            fontWeight: 900,
                            cursor: "pointer",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {getTbCountLabel(row)}
                        </button>
                      ) : (
                        <span
                          style={{
                            color: "#94a3b8",
                            fontSize: "0.75rem",
                            fontWeight: 800,
                            whiteSpace: "nowrap",
                          }}
                        >
                          0 TBs
                        </span>
                      )}
                    </td>
                  ) : null}

`;

    text = patchWithinSection(
      text,
      "<tbody>",
      "</tbody>",
      (section) =>
        replaceOnce(
          section,
          "                  {columnVisibility.addressLine1 ? (\n",
          `${body}                  {columnVisibility.addressLine1 ? (\n`,
          "Sales table TB body position",
        ),
      "Sales table body",
    );
  }

  if (!text.includes("<SalesTbRefsModal")) {
    text = replaceOnce(
      text,
      "      {mapRow ? (\n",
      `      {tbRefsRow ? (
        <SalesTbRefsModal
          row={tbRefsRow}
          onClose={() => setTbRefsRow(null)}
        />
      ) : null}

      {mapRow ? (
`,
      "Sales table TB modal render",
    );
  }

  return text;
}

const apiOriginal = fs.readFileSync(apiPath, "utf8");
const tableOriginal = fs.readFileSync(tablePath, "utf8");

const apiPatchedLf = patchApi(apiOriginal);
const tablePatchedLf = patchTable(tableOriginal);

const apiPatched = restoreLineEndings(apiPatchedLf, apiOriginal);
const tablePatched = restoreLineEndings(tablePatchedLf, tableOriginal);
const modalContent = fs.readFileSync(packagedModalPath, "utf8");

const writes = [
  [apiPath, apiPatched],
  [tablePath, tablePatched],
  [modalPath, modalContent],
];

for (const [filePath, content] of writes) {
  const tempPath = `${filePath}.tb-column-temp`;
  fs.writeFileSync(tempPath, content, "utf8");
}

for (const [filePath] of writes) {
  const tempPath = `${filePath}.tb-column-temp`;
  fs.renameSync(tempPath, filePath);
}

console.log("");
console.log("SALES TB IDS COLUMN APPLIED");
console.log(`Updated: ${path.relative(repoRoot, apiPath)}`);
console.log(`Updated: ${path.relative(repoRoot, tablePath)}`);
console.log(`Created: ${path.relative(repoRoot, modalPath)}`);
console.log("");
console.log("Implemented:");
console.log("- TB IDs column visible in Sales table");
console.log("- Cells display 0 TBs, 1 TB or multiple TB count");
console.log("- Non-zero counts open Targeted Batch reference modal");
console.log("- Modal shows current id/date and future rowId/fieldWork details");
console.log("- TB count sorting");
console.log("- No TB filter added in this patch");
