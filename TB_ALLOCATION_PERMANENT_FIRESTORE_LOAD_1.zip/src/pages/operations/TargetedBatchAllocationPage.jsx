/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
} from "firebase/firestore";

import { db } from "../../firebase";
import { useGetAvailableTeamsQuery } from "../../redux/teamsApi";
import { useGetAvailableServiceProvidersQuery } from "../../redux/serviceProvidersApi";
import { useGetUsersDirectoryQuery } from "../../redux/usersApi";
import {
  formatDateTime,
  formatNumber,
} from "./targeted-batches/targetedBatchUtils";
import TargetedBatchAllocationTargetPanel from "./targeted-batches/allocation/TargetedBatchAllocationTargetPanel";
import TargetedBatchAllocationGroupPanel from "./targeted-batches/allocation/TargetedBatchAllocationGroupPanel";
import TargetedBatchAllocationRowsPanel from "./targeted-batches/allocation/TargetedBatchAllocationRowsPanel";
import TargetedBatchAllocationReview from "./targeted-batches/allocation/TargetedBatchAllocationReview";
import {
  Badge,
  InfoCard,
  SummaryDetailRow,
} from "./targeted-batches/allocation/TargetedBatchAllocationPrimitives";
import styles from "./targeted-batches/allocation/targetedBatchAllocationStyles";
import {
  applyAllocationSearch,
  applyQuickFilter,
  asArray,
  buildAllocationReviewRows,
  buildTargetPayload,
  buildUsersById,
  canAllocateRow,
  enrichServiceProvidersWithMembers,
  enrichTeamsWithMembers,
  getBackendAllocation,
  getPageBounds,
  getRowKey,
  getRowOutcome,
  getTargetLabel,
  getTbRowId,
} from "./targeted-batches/allocation/targetedBatchAllocationUtils";


function timestampToIso(value) {
  if (!value) return null;
  if (typeof value === "string") return value;
  if (typeof value?.toDate === "function") return value.toDate().toISOString();
  if (typeof value?.seconds === "number") {
    return new Date(value.seconds * 1000).toISOString();
  }
  return null;
}

function mapPermanentTbRow(rowDoc) {
  const data = rowDoc.data() || {};
  const meterId = data?.refs?.meterId || null;
  const backendAllocation = data?.allocation || {};

  return {
    ...data,
    id: rowDoc.id,
    tbRowId: rowDoc.id,
    uploadRowId: rowDoc.id,
    rowNo: data.rowNo,
    salesAllMeterId: data.salesAllMeterId,
    sourceSalesAllMeterId: data.salesAllMeterId,
    rowDecision: data?.decision?.status || "ACCEPT",
    assessmentDecision: data?.decision?.status || "ACCEPT",
    meterNo: data?.meter?.numberRaw || data?.meter?.numberNormalized || "",
    meterNoNormalized: data?.meter?.numberNormalized || "",
    accountNumber: data?.customer?.accountNumber || "",
    customerName: data?.customer?.customerName || "",
    addressLine1: data?.location?.addressLine1 || "",
    town: data?.location?.town || "",
    standNumber: data?.location?.sgCode || "",
    wardNumberLabel: data?.location?.wardNumberLabel || "",
    wardNumbers: Array.isArray(data?.location?.wardNumbers)
      ? data.location.wardNumbers
      : [],
    actionReason: data?.selection?.actionReason || "",
    totalSalesC: Number(data?.salesSnapshot?.totalSalesC || 0),
    latestMonthSalesC: Number(data?.salesSnapshot?.latestMonthSalesC || 0),
    sales3MonthsC: Number(data?.salesSnapshot?.sales3MonthsC || 0),
    sales6MonthsC: Number(data?.salesSnapshot?.sales6MonthsC || 0),
    sales12MonthsC: Number(data?.salesSnapshot?.sales12MonthsC || 0),
    monthsWithoutSales: Number(data?.salesSnapshot?.monthsWithoutSales || 0),
    lastPositiveSalesMonth:
      data?.salesSnapshot?.lastPositiveSalesMonth || null,
    monthlySalesC: { ...(data?.salesSnapshot?.monthlySalesC || {}) },
    monthlyUnits: { ...(data?.salesSnapshot?.monthlyUnits || {}) },
    astId: meterId,
    astMatchStatus: meterId ? "MATCHED" : "NOT_MATCHED",
    proposedTrnType: meterId ? "METER_INSPECTION" : "METER_DISCOVERY",
    allocation: {
      ...backendAllocation,
      source:
        backendAllocation?.targetId &&
        backendAllocation?.status === "ALLOCATED"
          ? "BACKEND"
          : backendAllocation?.source,
    },
    confirmedAt: timestampToIso(data?.metadata?.createdAt),
  };
}

export default function TargetedBatchAllocationPage() {
  const { tbId } = useParams();

  const [batch, setBatch] = useState(null);
  const [permanentRows, setPermanentRows] = useState([]);
  const [isBatchLoading, setIsBatchLoading] = useState(true);
  const [batchLoadError, setBatchLoadError] = useState("");
  const [plannedAllocationsByRowId, setPlannedAllocationsByRowId] = useState({});

  const [targetType, setTargetType] = useState("TEAM");
  const [targetId, setTargetId] = useState("");
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [activeFilter, setActiveFilter] = useState("ALL");
  const [rowSearch, setRowSearch] = useState("");
  const [pageSize, setPageSize] = useState(25);
  const [pageIndex, setPageIndex] = useState(0);
  const [statusMessage, setStatusMessage] = useState("");

  const decodedTbId = decodeURIComponent(tbId || "");

  useEffect(() => {
    let active = true;

    async function loadPermanentTargetedBatch() {
      setIsBatchLoading(true);
      setBatchLoadError("");
      setBatch(null);
      setPermanentRows([]);
      setPlannedAllocationsByRowId({});
      setSelectedRowKeys([]);
      setStatusMessage("");

      if (!decodedTbId) {
        setBatchLoadError("The Targeted Batch ID is missing from the route.");
        setIsBatchLoading(false);
        return;
      }

      try {
        const parentRef = doc(db, "tb_uploads", decodedTbId);
        const rowsQuery = query(
          collection(db, "tb_rows"),
          where("tbId", "==", decodedTbId),
        );

        const [parentSnapshot, rowsSnapshot] = await Promise.all([
          getDoc(parentRef),
          getDocs(rowsQuery),
        ]);

        if (!active) return;

        if (!parentSnapshot.exists()) {
          setBatchLoadError(
            `Permanent Targeted Batch ${decodedTbId} was not found.`,
          );
          return;
        }

        const permanentBatch = {
          ...parentSnapshot.data(),
          id: parentSnapshot.id,
        };
        const loadedRows = rowsSnapshot.docs
          .map(mapPermanentTbRow)
          .sort((left, right) => Number(left.rowNo) - Number(right.rowNo));

        setBatch(permanentBatch);
        setPermanentRows(loadedRows);
      } catch (error) {
        if (!active) return;
        setBatchLoadError(
          error?.message ||
            "The permanent Targeted Batch could not be loaded from Firestore.",
        );
      } finally {
        if (active) setIsBatchLoading(false);
      }
    }

    loadPermanentTargetedBatch();

    return () => {
      active = false;
    };
  }, [decodedTbId]);

  const sourceType = batch?.source?.type || "";
  const isSalesSource = sourceType === "PREPAID_SALES";
  const isConfirmed = batch?.creation?.state === "READY";

  const rows = useMemo(
    () =>
      permanentRows.map((row, index) => ({
        ...row,
        _rowKey: getRowKey(row, index, batch?.id || decodedTbId),
        _rowOutcome: getRowOutcome(row, sourceType),
        _backendAllocation: getBackendAllocation(row),
      })),
    [batch?.id, decodedTbId, permanentRows, sourceType],
  );

  const allocationRows = useMemo(
    () => rows.filter((row) => row._rowOutcome === "ACCEPT"),
    [rows],
  );

  const allocationsByRowId = useMemo(() => {
    const result = { ...plannedAllocationsByRowId };

    allocationRows.forEach((row) => {
      if (row._backendAllocation?.id) {
        result[row._rowKey] = row._backendAllocation;
      }
    });

    return result;
  }, [allocationRows, plannedAllocationsByRowId]);

  const allocationGroups = useMemo(
    () =>
      buildAllocationReviewRows({
        rows: allocationRows,
        allocationsByRowId,
      }),
    [allocationRows, allocationsByRowId],
  );

  const filteredRows = useMemo(() => {
    const quickFiltered = applyQuickFilter(
      allocationRows,
      activeFilter,
      allocationsByRowId,
    );
    return applyAllocationSearch(quickFiltered, rowSearch);
  }, [activeFilter, allocationRows, allocationsByRowId, rowSearch]);

  const pageBounds = useMemo(
    () =>
      getPageBounds({
        pageIndex,
        pageSize,
        totalRows: filteredRows.length,
      }),
    [filteredRows.length, pageIndex, pageSize],
  );
  const pagedRows = filteredRows.slice(
    pageBounds.startIndex,
    pageBounds.endIndex,
  );

  const selectedRowSet = useMemo(
    () => new Set(selectedRowKeys),
    [selectedRowKeys],
  );
  const selectedRows = useMemo(
    () =>
      allocationRows.filter(
        (row) =>
          selectedRowSet.has(row._rowKey) && canAllocateRow(row, sourceType),
      ),
    [allocationRows, selectedRowSet, sourceType],
  );

  const {
    data: availableTeams = [],
    isLoading: areTeamsLoading,
    isError: areTeamsError,
    error: teamsError,
  } = useGetAvailableTeamsQuery({ limit: 500 });

  const {
    data: availableServiceProviders = [],
    isLoading: areServiceProvidersLoading,
    isError: areServiceProvidersError,
    error: serviceProvidersError,
  } = useGetAvailableServiceProvidersQuery({ limit: 500 });

  const {
    data: usersDirectory = [],
    isLoading: areUsersLoading,
    isError: areUsersError,
    error: usersError,
  } = useGetUsersDirectoryQuery({ limit: 1000 });

  const usersById = useMemo(
    () => buildUsersById(usersDirectory),
    [usersDirectory],
  );
  const availableTeamsWithMembers = useMemo(
    () => enrichTeamsWithMembers(availableTeams, usersById),
    [availableTeams, usersById],
  );
  const availableServiceProvidersWithMembers = useMemo(
    () =>
      enrichServiceProvidersWithMembers(
        availableServiceProviders,
        usersDirectory,
      ),
    [availableServiceProviders, usersDirectory],
  );

  const targetOptions =
    targetType === "SP"
      ? availableServiceProvidersWithMembers
      : availableTeamsWithMembers;
  const selectedTargetOption =
    targetOptions.find((item) => item.id === targetId) || null;
  const selectedTargetPayload = useMemo(
    () => buildTargetPayload(selectedTargetOption),
    [selectedTargetOption],
  );

  const allocatedRowCount = allocationRows.filter((row) =>
    Boolean(allocationsByRowId[row._rowKey]?.id),
  ).length;
  const unallocatedRowCount = Math.max(
    allocationRows.length - allocatedRowCount,
    0,
  );

  const targetContextLoading =
    areTeamsLoading || areServiceProvidersLoading || areUsersLoading;
  const targetContextError =
    areTeamsError || areServiceProvidersError || areUsersError;
  const targetContextErrorMessage =
    teamsError?.message ||
    serviceProvidersError?.message ||
    usersError?.message ||
    teamsError?.data?.message ||
    serviceProvidersError?.data?.message ||
    usersError?.data?.message ||
    "Could not load TEAM/SP allocation targets.";

  function handleTargetTypeChange(nextType) {
    setTargetType(nextType);
    setTargetId("");
    setStatusMessage("");
  }

  function handleSelectTarget(target) {
    const cleanTarget = buildTargetPayload(target);
    if (!cleanTarget) {
      setTargetId("");
      return;
    }

    setTargetType(cleanTarget.type);
    setTargetId(cleanTarget.id);
    setStatusMessage(`${getTargetLabel(cleanTarget)} selected.`);
  }

  function applyTargetToSelectedRows() {
    const cleanTarget = buildTargetPayload(selectedTargetPayload);

    if (!cleanTarget) {
      setStatusMessage("Select a TEAM or Service Provider first.");
      return;
    }

    if (selectedRows.length === 0) {
      setStatusMessage("Select at least one accepted sales row first.");
      return;
    }

    const plannedAt = new Date().toISOString();

    setPlannedAllocationsByRowId((current) => {
      const next = { ...current };

      selectedRows.forEach((row) => {
        if (row._backendAllocation?.id) return;

        next[row._rowKey] = {
          ...cleanTarget,
          source: "FRONTEND_PENDING_BACKEND",
          plannedAt,
        };
      });

      return next;
    });

    setSelectedRowKeys([]);
    setStatusMessage(
      `${selectedRows.length} accepted sales row(s) assigned to ${getTargetLabel(cleanTarget)} in the frontend allocation plan.`,
    );
  }

  function handleToggleRow(rowKey) {
    const row = allocationRows.find((item) => item._rowKey === rowKey);
    if (!row || !canAllocateRow(row, sourceType)) return;

    setSelectedRowKeys((current) =>
      current.includes(rowKey)
        ? current.filter((item) => item !== rowKey)
        : [...current, rowKey],
    );
  }

  function handleToggleAllVisibleRows() {
    const visibleKeys = pagedRows
      .filter((row) => canAllocateRow(row, sourceType))
      .map((row) => row._rowKey);
    const allSelected =
      visibleKeys.length > 0 &&
      visibleKeys.every((rowKey) => selectedRowSet.has(rowKey));

    setSelectedRowKeys((current) => {
      const next = new Set(current);
      visibleKeys.forEach((rowKey) => {
        if (allSelected) next.delete(rowKey);
        else next.add(rowKey);
      });
      return Array.from(next);
    });
  }

  function handleClearSelectedAllocations() {
    const rowKeys = selectedRows
      .filter((row) => allocationsByRowId[row._rowKey]?.source !== "BACKEND")
      .map((row) => row._rowKey);

    if (rowKeys.length === 0) {
      setStatusMessage("No editable frontend allocations were selected.");
      return;
    }

    setPlannedAllocationsByRowId((current) => {
      const next = { ...current };
      rowKeys.forEach((rowKey) => delete next[rowKey]);
      return next;
    });

    setSelectedRowKeys([]);
    setStatusMessage(`${rowKeys.length} frontend allocation(s) cleared.`);
  }

  function handleClearTargetGroup(group) {
    const rowKeys = asArray(group?.rowReferences)
      .map((reference) => reference.rowKey)
      .filter(
        (rowKey) => allocationsByRowId[rowKey]?.source !== "BACKEND",
      );

    if (rowKeys.length === 0) {
      setStatusMessage("No editable frontend allocations were found.");
      return;
    }

    setPlannedAllocationsByRowId((current) => {
      const next = { ...current };
      rowKeys.forEach((rowKey) => delete next[rowKey]);
      return next;
    });

    setSelectedRowKeys((current) =>
      current.filter((rowKey) => !rowKeys.includes(rowKey)),
    );
    setStatusMessage(
      `${getTargetLabel(group.target)} cleared from ${rowKeys.length} frontend row allocation(s).`,
    );
  }

  if (isBatchLoading) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.notice}>
          Loading permanent Targeted Batch and TB Rows...
        </div>
      </section>
    );
  }

  if (batchLoadError || !batch) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.errorNotice}>
          <strong>Targeted Batch not available</strong>
          <p style={styles.noticeText}>
            {batchLoadError ||
              "The requested permanent Targeted Batch could not be loaded."}
          </p>
        </div>
      </section>
    );
  }

  if (!isSalesSource) {
    return (
      <section style={styles.page}>
        <div style={styles.backRow}>
          <Link to="/operations/targeted-batches" style={styles.backLink}>
            ← Back to TB Register
          </Link>
          <Link to="/sales" style={styles.backLink}>
            Open Prepaid Sales
          </Link>
        </div>

        <div style={styles.deferredPanel}>
          <Badge tone="warning">SALES ALLOCATION ONLY</Badge>
          <h2 style={styles.title}>CSV allocation is deferred</h2>
          <p style={styles.subtitle}>
            The current implementation allocates permanent Targeted Batches created
            from the Sales table. Other source types remain deferred.
          </p>
          <Link to="/sales" style={styles.primaryLinkButton}>
            Create a Targeted Batch from Prepaid Sales
          </Link>
        </div>
      </section>
    );
  }

  if (!isConfirmed) {
    return (
      <section style={styles.page}>
        <div style={styles.backRow}>
          <Link
            to="/operations/targeted-batches"
            style={styles.backLink}
          >
            ← Back to TB Register
          </Link>
          <Link to="/sales" style={styles.backLink}>
            Open Prepaid Sales
          </Link>
        </div>

        <div style={styles.deferredPanel}>
          <Badge tone="warning">BATCH NOT READY</Badge>
          <h2 style={styles.title}>Targeted Batch creation is not complete</h2>
          <p style={styles.subtitle}>
            This permanent Targeted Batch has not completed backend creation.
            Allocation is available only after creation reaches READY.
          </p>
          <Link
            to="/operations/targeted-batches"
            style={styles.primaryLinkButton}
          >
            Return to TB Register
          </Link>
        </div>
      </section>
    );
  }

  if (permanentRows.length === 0) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Register
        </Link>
        <div style={styles.errorNotice}>
          <strong>Permanent TB Rows not available</strong>
          <p style={styles.noticeText}>
            No permanent TB rows were found for this batch.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section style={styles.page}>
      <div style={styles.backRow}>
        <Link
          to={`/operations/targeted-batches/${encodeURIComponent(batch.id)}`}
          style={styles.backLink}
        >
          ← Back to TB Rows
        </Link>

        <Link to="/sales" style={styles.backLink}>
          Open Prepaid Sales
        </Link>
      </div>

      <div style={styles.header}>
        <div>
          <p style={styles.eyebrow}>Prepaid Sales / Targeted Batch / Allocation</p>
          <h2 style={styles.title}>Allocate Selected Sales Meters</h2>
          <p style={styles.subtitle}>
            Choose a TEAM or Service Provider, select the accepted meters from
            this confirmed sales batch, and assign those exact rows. Direct FWR
            allocation is not permitted.
          </p>
        </div>

        <Badge tone="success">PREPAID SALES BATCH</Badge>
      </div>

      <div style={styles.summaryPanel}>
        <div style={styles.summaryMetaColumn}>
          <SummaryDetailRow label="TB ID" value={batch.id} />
          <SummaryDetailRow
            label="Confirmed"
            value={formatDateTime(
              timestampToIso(
                batch?.metadata?.confirmedAt || batch?.creation?.completedAt,
              ),
            )}
          />
          <SummaryDetailRow
            label="Source"
            value={batch?.source?.label || "Sales"}
          />
        </div>

        <div style={styles.summaryMetricGrid}>
          <InfoCard
            label="LM"
            value={`${batch?.scope?.lmPcode || "NAv"} · ${batch?.scope?.lmName || "NAv"}`}
          />
          <InfoCard
            label="Sales Rows"
            value={formatNumber(allocationRows.length)}
          />
          <InfoCard label="Allocated" value={formatNumber(allocatedRowCount)} />
          <InfoCard
            label="Not Allocated"
            value={formatNumber(unallocatedRowCount)}
          />
          <InfoCard
            label="Target Groups"
            value={formatNumber(allocationGroups.length)}
          />
        </div>
      </div>

      <div style={styles.salesFlowBanner}>
        <strong>Sales allocation sequence:</strong>
        <span>1. Choose TEAM or SP</span>
        <span>2. Select accepted sales rows</span>
        <span>3. Assign selected rows</span>
        <span>4. Review the grouped plan</span>
      </div>

      {targetContextLoading ? (
        <div style={styles.notice}>Loading TEAM/SP allocation targets...</div>
      ) : null}

      {targetContextError ? (
        <div style={styles.errorNotice}>{targetContextErrorMessage}</div>
      ) : null}

      <TargetedBatchAllocationTargetPanel
        targetType={targetType}
        targetId={targetId}
        targetOptions={targetOptions}
        selectedTarget={selectedTargetOption}
        onTargetTypeChange={handleTargetTypeChange}
        onSelectTarget={handleSelectTarget}
      />

      <TargetedBatchAllocationRowsPanel
        sourceType={sourceType}
        allocationRows={allocationRows}
        filteredRows={filteredRows}
        pagedRows={pagedRows}
        pageBounds={pageBounds}
        activeFilter={activeFilter}
        rowSearch={rowSearch}
        pageSize={pageSize}
        selectedRowSet={selectedRowSet}
        selectedRows={selectedRows}
        selectedTargetPayload={selectedTargetPayload}
        allocationsByRowId={allocationsByRowId}
        statusMessage={statusMessage}
        onSelectQuickFilter={(nextFilter) => {
          setActiveFilter(nextFilter);
          setPageIndex(0);
        }}
        onRowSearchChange={(value) => {
          setRowSearch(value);
          setPageIndex(0);
        }}
        onPageSizeChange={(value) => {
          setPageSize(Number(value) || 25);
          setPageIndex(0);
        }}
        onToggleAllVisibleRows={handleToggleAllVisibleRows}
        onToggleRow={handleToggleRow}
        onClearSelectedAllocations={handleClearSelectedAllocations}
        onAssignSelectedRows={applyTargetToSelectedRows}
        onFirstPage={() => setPageIndex(0)}
        onPreviousPage={() =>
          setPageIndex((current) => Math.max(current - 1, 0))
        }
        onNextPage={() =>
          setPageIndex((current) =>
            Math.min(current + 1, pageBounds.pageCount - 1),
          )
        }
        onLastPage={() => setPageIndex(pageBounds.pageCount - 1)}
      />

      <TargetedBatchAllocationGroupPanel
        groups={allocationGroups}
        onClearTarget={handleClearTargetGroup}
      />

      <TargetedBatchAllocationReview
        rows={allocationGroups}
        acceptedRowCount={formatNumber(allocationRows.length)}
        allocatedRowCount={formatNumber(allocatedRowCount)}
        unallocatedRowCount={formatNumber(unallocatedRowCount)}
      />
    </section>
  );
}
