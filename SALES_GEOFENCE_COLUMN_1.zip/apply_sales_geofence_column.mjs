import fs from "node:fs";
import path from "node:path";

const repoRoot = path.resolve(process.argv[2] || process.cwd());

const targets = {
  api: path.join(repoRoot, "src", "redux", "demoSalesApi.js"),
  table: path.join(
    repoRoot,
    "src",
    "pages",
    "sales",
    "components",
    "SalesMetersTable.jsx",
  ),
};

for (const [label, filePath] of Object.entries(targets)) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`${label} file not found: ${filePath}`);
  }
}

function detectLineEnding(text) {
  return text.includes("\r\n") ? "\r\n" : "\n";
}

function normalizeLf(text) {
  return text.replace(/\r\n/g, "\n");
}

function countOccurrences(text, search) {
  if (!search) return 0;
  return text.split(search).length - 1;
}

function replaceOnce(text, search, replacement, label) {
  const count = countOccurrences(text, search);

  if (count !== 1) {
    throw new Error(
      `${label}: expected exactly one anchor but found ${count}. No files were written.`,
    );
  }

  return text.replace(search, replacement);
}

function patchDemoSalesApi(source) {
  let text = normalizeLf(source);

  if (!text.includes("function normalizeGeofenceRefs(")) {
    const helper = `function normalizeGeofenceRefs(value = []) {
  const seen = new Set();

  return (Array.isArray(value) ? value : [])
    .map((item) => {
      const id = String(item?.id || "").trim();
      const name = String(item?.name || id).trim();

      if (!id) return null;

      return {
        id,
        name: name || id,
      };
    })
    .filter((item) => {
      if (!item?.id || seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    })
    .sort((left, right) =>
      String(left.name || left.id).localeCompare(
        String(right.name || right.id),
        undefined,
        { numeric: true, sensitivity: "base" },
      ),
    );
}

`;

    text = replaceOnce(
      text,
      "function normalizeDemoSalesRow(id, data = {}, requestedLmPcode = \"\") {",
      `${helper}function normalizeDemoSalesRow(id, data = {}, requestedLmPcode = "") {`,
      "demoSalesApi geofence normalizer insertion",
    );
  }

  if (!text.includes("geofenceRefs: normalizeGeofenceRefs(")) {
    text = replaceOnce(
      text,
      "    trnBatchIds: Array.isArray(data.trnBatchIds) ? data.trnBatchIds : [],",
      `    geofenceRefs: normalizeGeofenceRefs(
      data.geofenceRefs || data.GeoFenceRefs || [],
    ),
    trnBatchIds: Array.isArray(data.trnBatchIds) ? data.trnBatchIds : [],`,
      "demoSalesApi normalized geofenceRefs field",
    );
  }

  return text;
}

function patchSalesMetersTable(source) {
  let text = normalizeLf(source);

  if (!text.includes("  geofence: true,")) {
    text = replaceOnce(
      text,
      "  wardNo: true,\n",
      "  wardNo: true,\n  geofence: true,\n",
      "Sales table default Geofence visibility",
    );
  }

  if (!text.includes('{ key: "geofence", label: "Geofences" }')) {
    text = replaceOnce(
      text,
      '  { key: "wardNo", label: "Ward No" },\n',
      '  { key: "wardNo", label: "Ward No" },\n  { key: "geofence", label: "Geofences" },\n',
      "Sales table Geofence column option",
    );
  }

  if (!text.includes("  geofence: 220,")) {
    text = replaceOnce(
      text,
      "  wardNo: 105,\n",
      "  wardNo: 105,\n  geofence: 220,\n",
      "Sales table Geofence column width",
    );
  }

  if (!text.includes('  geofenceId: "ALL",')) {
    text = replaceOnce(
      text,
      '  wardNo: "ALL",\n',
      '  wardNo: "ALL",\n  geofenceId: "ALL",\n',
      "Sales table Geofence filter state",
    );
  }

  if (!text.includes("function getRowGeofenceRefs(")) {
    const helpers = `function getRowGeofenceRefs(row = {}) {
  return Array.isArray(row?.geofenceRefs)
    ? row.geofenceRefs.filter((ref) => ref?.id)
    : [];
}

function getRowGeofenceLabel(row = {}) {
  const names = getRowGeofenceRefs(row)
    .map((ref) => String(ref?.name || ref?.id || "").trim())
    .filter(Boolean);

  return names.join(", ");
}

`;

    text = replaceOnce(
      text,
      "function getSortValue(row, sortKey) {",
      `${helpers}function getSortValue(row, sortKey) {`,
      "Sales table Geofence row helpers",
    );
  }

  if (!text.includes('if (sortKey === "geofence")')) {
    text = replaceOnce(
      text,
      '  if (sortKey === "wardNo") return row?.wardNumberLabel || "";\n',
      '  if (sortKey === "wardNo") return row?.wardNumberLabel || "";\n  if (sortKey === "geofence") return getRowGeofenceLabel(row);\n',
      "Sales table Geofence sort",
    );
  }

  if (!text.includes("  const geofenceOptions = useMemo(() => {")) {
    const geofenceOptions = `  const geofenceOptions = useMemo(() => {
    const byId = new Map();

    rows.forEach((row) => {
      getRowGeofenceRefs(row).forEach((ref) => {
        if (byId.has(ref.id)) return;

        byId.set(ref.id, {
          id: ref.id,
          name: String(ref.name || ref.id),
        });
      });
    });

    return Array.from(byId.values()).sort((left, right) =>
      compareNatural(left.name, right.name),
    );
  }, [rows]);

`;

    text = replaceOnce(
      text,
      "  useEffect(() => {\n    setCurrentPage(1);\n  }, [targetFilter]);",
      `${geofenceOptions}  useEffect(() => {
    setCurrentPage(1);
  }, [targetFilter]);`,
      "Sales table Geofence filter options",
    );
  }

  if (!text.includes("      const matchesGeofence =")) {
    text = replaceOnce(
      text,
      "      return (\n        matchesTargetFilter(row, targetFilter, latestMonthKey) &&",
      `      const rowGeofenceRefs = getRowGeofenceRefs(row);
      const matchesGeofence =
        filters.geofenceId === "ALL" ||
        (filters.geofenceId === "NONE" && rowGeofenceRefs.length === 0) ||
        rowGeofenceRefs.some((ref) => ref.id === filters.geofenceId);

      return (
        matchesTargetFilter(row, targetFilter, latestMonthKey) &&`,
      "Sales table Geofence matching logic",
    );
  }

  if (!text.includes("        matchesGeofence &&")) {
    text = replaceOnce(
      text,
      '        (filters.wardNo === "ALL" || row?.wardNumbers?.includes(filters.wardNo)) &&\n',
      '        (filters.wardNo === "ALL" || row?.wardNumbers?.includes(filters.wardNo)) &&\n        matchesGeofence &&\n',
      "Sales table Geofence filter condition",
    );
  }

  if (!text.includes('    filters.geofenceId !== "ALL" ||')) {
    text = replaceOnce(
      text,
      '    filters.wardNo !== "ALL" ||\n',
      '    filters.wardNo !== "ALL" ||\n    filters.geofenceId !== "ALL" ||\n',
      "Sales table active Geofence filter detection",
    );
  }

  if (!text.includes('        geofenceId: columnKey === "geofence" ? "ALL" : current.geofenceId,')) {
    text = replaceOnce(
      text,
      '        wardNo: columnKey === "wardNo" ? "ALL" : current.wardNo,\n',
      '        wardNo: columnKey === "wardNo" ? "ALL" : current.wardNo,\n        geofenceId: columnKey === "geofence" ? "ALL" : current.geofenceId,\n',
      "Sales table clear hidden Geofence filter",
    );
  }

  if (!text.includes('label="Geofences"')) {
    const geofenceHeader = `              {columnVisibility.geofence ? (
                <th
                  style={{
                    ...styles.headerCell,
                    ...getStickyStyle("geofence", stickyLayout, true),
                  }}
                >
                  <SortButton
                    label="Geofences"
                    sortKey="geofence"
                    sortConfig={sortConfig}
                    onSort={handleSort}
                  />
                  <select
                    value={filters.geofenceId}
                    onChange={(event) =>
                      updateFilter("geofenceId", event.target.value)
                    }
                    style={styles.headerSelect}
                  >
                    <option value="ALL">All geofences</option>
                    <option value="NONE">No geofence</option>
                    {geofenceOptions.map((geofence) => (
                      <option key={geofence.id} value={geofence.id}>
                        {geofence.name}
                      </option>
                    ))}
                  </select>
                </th>
              ) : null}

`;

    text = replaceOnce(
      text,
      "              {columnVisibility.addressLine1 ? (\n",
      `${geofenceHeader}              {columnVisibility.addressLine1 ? (\n`,
      "Sales table Geofence header",
    );
  }

  if (!text.includes('getStickyStyle("geofence", stickyLayout)')) {
    const geofenceCell = `                  {columnVisibility.geofence ? (
                    <td
                      style={{
                        ...styles.bodyCell,
                        ...getStickyStyle("geofence", stickyLayout),
                      }}
                      title={getRowGeofenceLabel(row) || "No geofence"}
                    >
                      {getRowGeofenceLabel(row) || "No geofence"}
                    </td>
                  ) : null}

`;

    text = replaceOnce(
      text,
      "                  {columnVisibility.addressLine1 ? (\n",
      `${geofenceCell}                  {columnVisibility.addressLine1 ? (\n`,
      "Sales table Geofence body cell",
    );
  }

  return text;
}

const apiOriginal = fs.readFileSync(targets.api, "utf8");
const tableOriginal = fs.readFileSync(targets.table, "utf8");

const apiLineEnding = detectLineEnding(apiOriginal);
const tableLineEnding = detectLineEnding(tableOriginal);

const apiPatchedLf = patchDemoSalesApi(apiOriginal);
const tablePatchedLf = patchSalesMetersTable(tableOriginal);

const apiPatched =
  apiLineEnding === "\r\n" ? apiPatchedLf.replace(/\n/g, "\r\n") : apiPatchedLf;
const tablePatched =
  tableLineEnding === "\r\n"
    ? tablePatchedLf.replace(/\n/g, "\r\n")
    : tablePatchedLf;

fs.writeFileSync(targets.api, apiPatched, "utf8");
fs.writeFileSync(targets.table, tablePatched, "utf8");

console.log("");
console.log("SALES GEOFENCE COLUMN PATCH APPLIED");
console.log(`Updated: ${path.relative(repoRoot, targets.api)}`);
console.log(`Updated: ${path.relative(repoRoot, targets.table)}`);
console.log("");
console.log("Implemented:");
console.log("- Geofence references normalized into Sales rows");
console.log("- Geofences column visible after Ward No");
console.log("- All geofences / No geofence / specific geofence dropdown filter");
console.log("- Geofence sorting and reset behaviour");
