/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector } from "react-redux";

import { useGetAvailableTeamsQuery } from "../../redux/teamsApi";
import { useGetAvailableServiceProvidersQuery } from "../../redux/serviceProvidersApi";
import { useGetUsersDirectoryQuery } from "../../redux/usersApi";
import {
  formatDateTime,
  formatNumber,
} from "./targeted-batches/targetedBatchUtils";
import TargetedBatchAllocationTargetPanel from "./targeted-batches/allocation/TargetedBatchAllocationTargetPanel";
import TargetedBatchAllocationGroupPanel from "./targeted-batches/allocation/TargetedBatchAllocationGroupPanel";
import TargetedBatchAllocationReview from "./targeted-batches/allocation/TargetedBatchAllocationReview";
import {
  Badge,
  InfoCard,
  SummaryDetailRow,
  Td,
  Th,
} from "./targeted-batches/allocation/TargetedBatchAllocationPrimitives";
import styles from "./targeted-batches/allocation/targetedBatchAllocationStyles";
import {
  asArray,
  buildTargetPayload,
  buildUsersById,
  enrichServiceProvidersWithMembers,
  enrichTeamsWithMembers,
  getAstMatchStatus,
  getBackendAllocation,
  getProposedTrnType,
  getRowKey,
  getRowOutcome,
  getTargetLabel,
  getTrnId,
  hasCreatedTrn,
  valueOrNav,
} from "./targeted-batches/allocation/targetedBatchAllocationUtils";

function getGroupDefinition(row = {}) {
  const trnType = getProposedTrnType(row);

  if (trnType === "METER_DISCOVERY") {
    return {
      groupId: "METER_DISCOVERY",
      groupName: "Meter Discovery",
      trnType,
      trnTypeLabel: "Meter Discovery TRNs",
    };
  }

  if (trnType === "METER_INSPECTION") {
    return {
      groupId: "METER_INSPECTION",
      groupName: "Meter Inspection",
      trnType,
      trnTypeLabel: "Meter Inspection TRNs",
    };
  }

  return {
    groupId: "PENDING_ASSESSMENT",
    groupName: "Pending Backend Assessment",
    trnType: "PENDING_ASSESSMENT",
    trnTypeLabel: "TRN route not yet determined",
  };
}

function buildWorkGroups(rows = []) {
  const grouped = new Map();

  rows.forEach((row) => {
    const definition = getGroupDefinition(row);

    if (!grouped.has(definition.groupId)) {
      grouped.set(definition.groupId, {
        ...definition,
        rows: [],
      });
    }

    grouped.get(definition.groupId).rows.push(row);
  });

  const order = [
    "METER_DISCOVERY",
    "METER_INSPECTION",
    "PENDING_ASSESSMENT",
  ];

  return Array.from(grouped.values())
    .map((group) => ({
      ...group,
      rowCount: group.rows.length,
      trnCount: group.rows.filter(hasCreatedTrn).length,
    }))
    .sort(
      (left, right) =>
        order.indexOf(left.groupId) - order.indexOf(right.groupId),
    );
}

function buildAllocationReviewRows({ tbId, groups, allocationsByGroupId }) {
  return groups.map((group, index) => {
    const target = allocationsByGroupId[group.groupId] || null;
    const assigned = Boolean(target?.id);

    return {
      id: group.groupId,
      groupId: group.groupId,
      allocationId: `${tbId}_ALLOC_${String(index + 1).padStart(3, "0")}`,
      groupName: group.groupName,
      rowCount: group.rowCount,
      trnCount: group.trnCount,
      target,
      allocation: assigned ? "ASSIGNED_NOT_CREATED" : "NOT_ALLOCATED",
      status: assigned ? "READY_TO_CREATE" : "WAITING_FOR_TARGET",
    };
  });
}

export default function TargetedBatchAllocationPage() {
  const { tbId } = useParams();
  const draft = useSelector((state) => state.targetedBatchDraft?.draft || null);

  const [selectedGroupId, setSelectedGroupId] = useState(null);
  const [targetType, setTargetType] = useState("TEAM");
  const [targetId, setTargetId] = useState("");
  const [allocationsByGroupId, setAllocationsByGroupId] = useState({});
  const [dragTarget, setDragTarget] = useState(null);
  const [dragOverGroupId, setDragOverGroupId] = useState(null);
  const [statusMessage, setStatusMessage] = useState("");

  const decodedTbId = decodeURIComponent(tbId || "");
  const draftMatchesRoute = draft?.id === decodedTbId;

  const rows = useMemo(
    () =>
      draftMatchesRoute
        ? asArray(draft?.rows).map((row, index) => ({
            ...row,
            _rowKey: getRowKey(row, index),
            _rowOutcome: getRowOutcome(row),
            _backendAllocation: getBackendAllocation(row),
          }))
        : [],
    [draft, draftMatchesRoute],
  );

  const hasAuthoritativeAssessment = useMemo(
    () => rows.some((row) => ["ACCEPT", "REJECT"].includes(row._rowOutcome)),
    [rows],
  );
  const previewMode = !hasAuthoritativeAssessment;

  const allocationRows = useMemo(
    () =>
      previewMode
        ? rows
        : rows.filter((row) => row._rowOutcome === "ACCEPT"),
    [rows, previewMode],
  );
  const rejectedRows = useMemo(
    () => rows.filter((row) => row._rowOutcome === "REJECT"),
    [rows],
  );
  const groups = useMemo(() => buildWorkGroups(allocationRows), [allocationRows]);
  const selectedGroup =
    groups.find((group) => group.groupId === selectedGroupId) || groups[0] || null;

  const {
    data: availableTeams = [],
    isLoading: areTeamsLoading,
    isError: areTeamsError,
    error: teamsError,
  } = useGetAvailableTeamsQuery({ limit: 500 });

  const {
    data: availableServiceProviders = [],
    isLoading: areServiceProvidersLoading,
    isError: areServiceProvidersError,
    error: serviceProvidersError,
  } = useGetAvailableServiceProvidersQuery({ limit: 500 });

  const {
    data: usersDirectory = [],
    isLoading: areUsersLoading,
    isError: areUsersError,
    error: usersError,
  } = useGetUsersDirectoryQuery({ limit: 1000 });

  const usersById = useMemo(
    () => buildUsersById(usersDirectory),
    [usersDirectory],
  );
  const availableTeamsWithMembers = useMemo(
    () => enrichTeamsWithMembers(availableTeams, usersById),
    [availableTeams, usersById],
  );
  const availableServiceProvidersWithMembers = useMemo(
    () =>
      enrichServiceProvidersWithMembers(
        availableServiceProviders,
        usersDirectory,
      ),
    [availableServiceProviders, usersDirectory],
  );

  const targetOptions =
    targetType === "SP"
      ? availableServiceProvidersWithMembers
      : availableTeamsWithMembers;
  const selectedTargetOption =
    targetOptions.find((item) => item.id === targetId) || null;
  const selectedTargetPayload = useMemo(
    () => buildTargetPayload(selectedTargetOption),
    [selectedTargetOption],
  );

  const allocationReviewRows = useMemo(
    () =>
      buildAllocationReviewRows({
        tbId: draft?.id || decodedTbId,
        groups,
        allocationsByGroupId,
      }),
    [draft?.id, decodedTbId, groups, allocationsByGroupId],
  );

  const allocatedGroups = groups.filter(
    (group) => Boolean(allocationsByGroupId[group.groupId]?.id),
  );
  const allocatedRowCount = allocatedGroups.reduce(
    (sum, group) => sum + group.rowCount,
    0,
  );
  const unallocatedGroupCount = Math.max(
    groups.length - allocatedGroups.length,
    0,
  );
  const createdTrnCount = allocationRows.filter(hasCreatedTrn).length;

  const targetContextLoading =
    areTeamsLoading || areServiceProvidersLoading || areUsersLoading;
  const targetContextError =
    areTeamsError || areServiceProvidersError || areUsersError;
  const targetContextErrorMessage =
    teamsError?.message ||
    serviceProvidersError?.message ||
    usersError?.message ||
    teamsError?.data?.message ||
    serviceProvidersError?.data?.message ||
    usersError?.data?.message ||
    "Could not load TEAM/SP allocation targets.";

  function handleTargetTypeChange(nextType) {
    setTargetType(nextType);
    setTargetId("");
    setStatusMessage("");
  }

  function handleSelectTarget(target) {
    setTargetType(target.type);
    setTargetId(target.id);
    setStatusMessage(`${getTargetLabel(target)} selected.`);
  }

  function assignTargetToGroup(group, target = selectedTargetPayload) {
    const cleanTarget = buildTargetPayload(target);

    if (!group?.groupId || !cleanTarget) return;

    setSelectedGroupId(group.groupId);
    setAllocationsByGroupId((current) => ({
      ...current,
      [group.groupId]: {
        ...cleanTarget,
        source: previewMode
          ? "FRONTEND_PREVIEW"
          : "FRONTEND_PENDING_BACKEND",
      },
    }));
    setStatusMessage(
      `${getTargetLabel(cleanTarget)} assigned to ${group.groupName}${
        previewMode ? " in frontend preview" : ""
      }.`,
    );
  }

  function clearTargetFromGroup(groupId) {
    setAllocationsByGroupId((current) => {
      const next = { ...current };
      delete next[groupId];
      return next;
    });
    setStatusMessage("Target allocation cleared.");
  }

  function handleTargetDragStart(event, target) {
    const cleanTarget = buildTargetPayload(target);

    if (!cleanTarget) return;

    setDragTarget(cleanTarget);
    event.dataTransfer.effectAllowed = "copy";
    event.dataTransfer.setData("application/json", JSON.stringify(cleanTarget));
    event.dataTransfer.setData("text/plain", getTargetLabel(cleanTarget));
  }

  function handleTargetDragEnd() {
    setDragTarget(null);
    setDragOverGroupId(null);
  }

  function readDroppedTarget(event) {
    const jsonPayload = event.dataTransfer.getData("application/json");

    if (jsonPayload) {
      try {
        return buildTargetPayload(JSON.parse(jsonPayload));
      } catch (error) {
        console.warn("Could not parse dropped Targeted Batch target", error);
      }
    }

    return buildTargetPayload(dragTarget || selectedTargetPayload);
  }

  function handleDropTargetOnGroup(event, group) {
    event.preventDefault();
    setDragOverGroupId(null);

    const droppedTarget = readDroppedTarget(event);

    if (!droppedTarget) return;

    assignTargetToGroup(group, droppedTarget);
    setDragTarget(null);
  }

  function handleTargetDragEnter(event, group) {
    event.preventDefault();

    if (!group?.groupId || !(dragTarget || selectedTargetPayload)) return;

    event.dataTransfer.dropEffect = "copy";
    setDragOverGroupId(group.groupId);
  }

  function handleTargetDragLeave(event, group) {
    if (!group?.groupId) return;

    const nextElement = event.relatedTarget;

    if (nextElement && event.currentTarget?.contains(nextElement)) return;

    setDragOverGroupId((currentId) =>
      currentId === group.groupId ? null : currentId,
    );
  }

  function handleAllowTargetDrop(event, group) {
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";

    if (group?.groupId && dragOverGroupId !== group.groupId) {
      setDragOverGroupId(group.groupId);
    }
  }

  if (!draftMatchesRoute) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Uploads
        </Link>
        <div style={styles.errorNotice}>
          <strong>TB upload not available</strong>
          <p style={styles.noticeText}>
            The requested TB ID is not present in the current Redux draft. The
            frontend stage does not yet reload permanent TB data after a browser
            refresh.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section style={styles.page}>
      <div style={styles.backRow}>
        <Link
          to={`/operations/targeted-batches/${encodeURIComponent(draft.id)}`}
          style={styles.backLink}
        >
          ← Back to TB Rows
        </Link>

        <Link
          to={`/operations/targeted-batches/${encodeURIComponent(draft.id)}/final-report`}
          style={styles.backLink}
        >
          Final Report (DRAFT)
        </Link>
      </div>

      <div style={styles.header}>
        <div>
          <p style={styles.eyebrow}>Operations / TB Details / Allocation</p>
          <h2 style={styles.title}>Targeted Batch Allocation</h2>
          <p style={styles.subtitle}>
            Targeted Batch allocation starts from reviewed TB rows. This page
            groups the rows by their required work route before TEAM/SP
            allocation and later child TRN creation.
          </p>
        </div>

        <Badge tone={previewMode ? "warning" : "success"}>
          {previewMode ? "FRONTEND PREVIEW" : "ACCEPTED ROWS"}
        </Badge>
      </div>

      <div style={styles.summaryPanel}>
        <div style={styles.summaryMetaColumn}>
          <SummaryDetailRow label="TB ID" value={draft.id} />
          <SummaryDetailRow
            label="Created"
            value={formatDateTime(draft.createdAt)}
          />
        </div>

        <div style={styles.summaryMetricGrid}>
          <InfoCard
            label="LM"
            value={`${draft.lmPcode || "NAv"} · ${draft.lmName || "NAv"}`}
          />
          <InfoCard
            label={previewMode ? "Preview Rows" : "Accepted Rows"}
            value={formatNumber(allocationRows.length)}
          />
          <InfoCard
            label="Rejected Rows"
            value={formatNumber(rejectedRows.length)}
          />
          <InfoCard
            label="Ready Groups"
            value={formatNumber(groups.length)}
          />
          <InfoCard
            label="Allocated Groups"
            value={formatNumber(allocatedGroups.length)}
          />
          <InfoCard
            label="TRNs Created"
            value={formatNumber(createdTrnCount)}
          />
        </div>
      </div>

      <div
        style={{
          ...styles.infoBanner,
          ...(previewMode ? styles.previewBanner : null),
        }}
      >
        <strong>Targeted Batch allocation board:</strong> select or drag a
        TEAM/SP target onto each Targeted Batch work group you want to allocate.
        The Allocation Review table is the single Targeted Batch truth table for
        allocated, assigned, and waiting groups. Individual FWR allocation is
        not allowed.
      </div>

      {previewMode ? (
        <div style={{ ...styles.notice, ...styles.previewBanner }}>
          The current Redux draft has no authoritative backend ACCEPT/REJECT row
          outcomes. The page mirrors the TC BGO allocation interaction, but its
          assignments remain frontend-only until Targeted Batch backend
          validation is connected.
        </div>
      ) : null}

      {targetContextLoading ? (
        <div style={styles.notice}>Loading Targeted Batch context...</div>
      ) : null}

      {targetContextError ? (
        <div style={styles.errorNotice}>{targetContextErrorMessage}</div>
      ) : null}

      {statusMessage ? (
        <div style={styles.statusMessage}>{statusMessage}</div>
      ) : null}

      <section style={styles.boardGrid}>
        <div style={styles.leftColumn}>
          <TargetedBatchAllocationTargetPanel
            targetType={targetType}
            targetId={targetId}
            targetOptions={targetOptions}
            onTargetTypeChange={handleTargetTypeChange}
            onSelectTarget={handleSelectTarget}
            onTargetDragStart={handleTargetDragStart}
            onTargetDragEnd={handleTargetDragEnd}
          />
        </div>

        <TargetedBatchAllocationGroupPanel
          groups={groups}
          selectedGroup={selectedGroup}
          selectedTargetPayload={selectedTargetPayload}
          allocationsByGroupId={allocationsByGroupId}
          dragOverGroupId={dragOverGroupId}
          onSelectGroup={setSelectedGroupId}
          onAssignTarget={assignTargetToGroup}
          onClearTarget={clearTargetFromGroup}
          onTargetDragEnter={handleTargetDragEnter}
          onTargetDragLeave={handleTargetDragLeave}
          onAllowTargetDrop={handleAllowTargetDrop}
          onDropTarget={handleDropTargetOnGroup}
        />
      </section>

      <TargetedBatchAllocationReview
        rows={allocationReviewRows}
        allocatedGroupCount={formatNumber(allocatedGroups.length)}
        allocatedRowCount={formatNumber(allocatedRowCount)}
        unallocatedGroupCount={formatNumber(unallocatedGroupCount)}
        onClearGroup={clearTargetFromGroup}
      />

      <section style={styles.panel}>
        <div style={styles.panelHeader}>
          <div>
            <h3 style={styles.panelTitle}>Selected Targeted Batch Group Rows</h3>
            <p style={styles.panelSubtitle}>
              Preview the rows belonging to the selected allocation group.
            </p>
          </div>

          <Badge tone={selectedGroup ? "success" : "neutral"}>
            {selectedGroup?.rowCount || 0} row(s)
          </Badge>
        </div>

        {!selectedGroup ? (
          <div style={styles.emptyState}>No Targeted Batch group selected.</div>
        ) : (
          <div style={styles.tableWrap}>
            <table style={{ ...styles.table, minWidth: 1050 }}>
              <thead>
                <tr>
                  <Th>Row No</Th>
                  <Th>Meter No</Th>
                  <Th>Address</Th>
                  <Th>Town</Th>
                  <Th>AST Match</Th>
                  <Th>Proposed TRN</Th>
                  <Th>Allocation</Th>
                  <Th>TRN ID</Th>
                </tr>
              </thead>
              <tbody>
                {selectedGroup.rows.map((row, index) => {
                  const target = allocationsByGroupId[selectedGroup.groupId];
                  return (
                    <tr key={row._rowKey || index}>
                      <Td>{row.rowNo || index + 1}</Td>
                      <Td strong>{valueOrNav(row.meterNo)}</Td>
                      <Td>{valueOrNav(row.addressLine1)}</Td>
                      <Td>{valueOrNav(row.town)}</Td>
                      <Td>{getAstMatchStatus(row)}</Td>
                      <Td>{getProposedTrnType(row)}</Td>
                      <Td>{target ? getTargetLabel(target) : "NOT_ALLOCATED"}</Td>
                      <Td>{getTrnId(row) || "NAv"}</Td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </section>
  );
}
