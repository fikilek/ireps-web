/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import styles from "./targetedBatchAllocationStyles";
import { Badge } from "./TargetedBatchAllocationPrimitives";
import { getTargetLabel } from "./targetedBatchAllocationUtils";

export default function TargetedBatchAllocationGroupPanel({
  groups,
  selectedGroup,
  selectedTargetPayload,
  allocationsByGroupId,
  dragOverGroupId,
  onSelectGroup,
  onAssignTarget,
  onClearTarget,
  onTargetDragEnter,
  onTargetDragLeave,
  onAllowTargetDrop,
  onDropTarget,
}) {
  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <h3 style={styles.panelTitle}>Ready Targeted Batch Groups</h3>
          <p style={styles.panelSubtitle}>
            One Targeted Batch allocation group is prepared for each row work
            route. Select or drag a TEAM/SP target onto the group to allocate it.
          </p>
        </div>

        <Badge tone={groups.length > 0 ? "success" : "neutral"}>
          {groups.length} group(s)
        </Badge>
      </div>

      {groups.length === 0 ? (
        <div style={styles.emptyState}>
          No Targeted Batch groups are available. Backend-accepted rows will
          appear here when authoritative row assessment is connected.
        </div>
      ) : (
        <div style={styles.groupList}>
          {groups.map((group) => {
            const active = selectedGroup?.groupId === group.groupId;
            const assignedTarget = allocationsByGroupId[group.groupId] || null;
            const hasAssignedTarget = Boolean(assignedTarget?.id);
            const isDragFocused = dragOverGroupId === group.groupId;

            return (
              <div
                key={group.groupId}
                style={{
                  ...styles.groupCard,
                  ...(active ? styles.groupCardActive : null),
                  ...(hasAssignedTarget ? styles.groupCardAllocated : null),
                  ...(isDragFocused ? styles.groupCardDragFocused : null),
                }}
                onDragEnter={(event) => onTargetDragEnter(event, group)}
                onDragLeave={(event) => onTargetDragLeave(event, group)}
                onDragOver={(event) => onAllowTargetDrop(event, group)}
                onDrop={(event) => onDropTarget(event, group)}
              >
                <div style={styles.groupMain}>
                  <button
                    type="button"
                    style={styles.groupSelectButton}
                    onClick={() => onSelectGroup(group.groupId)}
                    title="Select this Targeted Batch group and preview its rows"
                  >
                    <span style={styles.groupName}>{group.groupName}</span>
                    <span style={styles.groupMeta}>
                      {group.rowCount} row(s) • {group.trnTypeLabel}
                    </span>
                  </button>

                  <div
                    style={{
                      ...styles.groupAllocationBox,
                      ...(hasAssignedTarget
                        ? styles.groupAllocationBoxAssigned
                        : null),
                      ...(isDragFocused
                        ? styles.groupAllocationBoxDragFocused
                        : null),
                    }}
                  >
                    <span style={styles.groupAllocationLabel}>
                      Assigned target
                    </span>
                    <strong style={styles.groupAllocationTarget}>
                      {hasAssignedTarget
                        ? getTargetLabel(assignedTarget)
                        : "No TEAM/SP assigned"}
                    </strong>
                    {hasAssignedTarget ? (
                      <span style={styles.groupAllocationMembers}>
                        {assignedTarget.memberCount || 0} member(s)
                      </span>
                    ) : (
                      <span style={styles.groupAllocationMembers}>
                        {isDragFocused
                          ? "Release to assign this TEAM/SP here."
                          : "Drop a TEAM/SP here."}
                      </span>
                    )}
                  </div>
                </div>

                <div style={styles.groupActions}>
                  {hasAssignedTarget ? (
                    <button
                      type="button"
                      style={styles.clearAssignmentButton}
                      onClick={() => onClearTarget(group.groupId)}
                    >
                      Clear
                    </button>
                  ) : null}

                  <button
                    type="button"
                    style={{
                      ...styles.primaryButton,
                      ...(!selectedTargetPayload ? styles.disabledButton : null),
                    }}
                    onClick={() => onAssignTarget(group, selectedTargetPayload)}
                    disabled={!selectedTargetPayload}
                    title={
                      selectedTargetPayload
                        ? `Assign ${getTargetLabel(selectedTargetPayload)} to ${group.groupName}`
                        : "Select a TEAM or SP target first."
                    }
                  >
                    Assign Selected Target
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
