/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import styles from "./targetedBatchAllocationStyles";
import { Badge, Td, Th } from "./TargetedBatchAllocationPrimitives";
import {
  getAstMatchStatus,
  getProposedTrnType,
  getTargetLabel,
  getTrnId,
  hasCreatedTrn,
} from "./targetedBatchAllocationUtils";

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];
const QUICK_FILTERS = [
  { key: "ALL", label: "All Rows" },
  { key: "UNALLOCATED", label: "Unallocated" },
  { key: "ALLOCATED", label: "Allocated" },
  { key: "METER_DISCOVERY", label: "Meter Discovery" },
  { key: "METER_INSPECTION", label: "Meter Inspection" },
  { key: "TRN_CREATED", label: "TRN Created" },
];

export default function TargetedBatchAllocationRowsPanel({
  previewMode,
  allocationRows,
  filteredRows,
  pagedRows,
  pageBounds,
  activeFilter,
  meterSearch,
  pageSize,
  selectedRowSet,
  selectedRows,
  selectedTargetPayload,
  allocationsByRowId,
  isDropFocused,
  statusMessage,
  onSelectQuickFilter,
  onMeterSearchChange,
  onPageSizeChange,
  onToggleAllVisibleRows,
  onToggleRow,
  onDropTarget,
  onDropFocusChange,
  onClearSelectedAllocations,
  onAssignSelectedRows,
  onFirstPage,
  onPreviousPage,
  onNextPage,
  onLastPage,
}) {
  const selectablePagedRows = pagedRows.filter((row) => !hasCreatedTrn(row));
  const allVisibleSelected =
    selectablePagedRows.length > 0 &&
    selectablePagedRows.every((row) => selectedRowSet.has(row._rowKey));

  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <h3 style={styles.panelTitle}>
            {previewMode
              ? "Draft Rows — Allocation Preview"
              : "Accepted Rows Ready for Allocation"}
          </h3>
          <p style={styles.panelSubtitle}>
            Select rows, then assign the selected TEAM/SP. Dragging a target
            onto the drop zone performs the same frontend assignment.
          </p>
        </div>

        <Badge tone={allocationRows.length > 0 ? "success" : "neutral"}>
          {allocationRows.length} row(s)
        </Badge>
      </div>

      <div style={styles.filterRow}>
        {QUICK_FILTERS.map((filter) => (
          <button
            key={filter.key}
            type="button"
            style={{
              ...styles.filterButton,
              ...(activeFilter === filter.key ? styles.filterButtonActive : null),
            }}
            onClick={() => onSelectQuickFilter(filter.key)}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <div style={styles.rowSearchBar}>
        <label style={styles.searchLabel}>
          Meter search
          <input
            style={styles.searchInput}
            value={meterSearch}
            onChange={(event) => onMeterSearchChange(event.target.value)}
            placeholder="Search meter number"
          />
        </label>

        <label style={styles.pageSizeLabel}>
          Rows per page
          <select
            style={styles.select}
            value={pageSize}
            onChange={(event) => onPageSizeChange(event.target.value)}
          >
            {PAGE_SIZE_OPTIONS.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </label>
      </div>

      <div
        style={{
          ...styles.assignmentDropZone,
          ...(isDropFocused ? styles.assignmentDropZoneActive : null),
        }}
        onDragEnter={(event) => {
          event.preventDefault();
          onDropFocusChange(true);
        }}
        onDragOver={(event) => {
          event.preventDefault();
          event.dataTransfer.dropEffect = "copy";
          onDropFocusChange(true);
        }}
        onDragLeave={(event) => {
          const nextElement = event.relatedTarget;
          if (nextElement && event.currentTarget.contains(nextElement)) return;
          onDropFocusChange(false);
        }}
        onDrop={onDropTarget}
      >
        <div>
          <strong style={styles.dropZoneTitle}>
            {selectedRows.length} row(s) selected
          </strong>
          <p style={styles.dropZoneText}>
            Selected target: {getTargetLabel(selectedTargetPayload || {})}
          </p>
          <p style={styles.dropZoneHint}>
            {isDropFocused
              ? "Release the TEAM/SP to assign it to the selected rows."
              : "Drop a TEAM/SP target here or use Assign Selected Rows."}
          </p>
        </div>

        <div style={styles.assignmentActions}>
          <button
            type="button"
            style={styles.secondaryButton}
            onClick={onClearSelectedAllocations}
            disabled={selectedRows.length === 0}
          >
            Clear Selected Allocation
          </button>
          <button
            type="button"
            style={{
              ...styles.primaryButton,
              ...(!selectedTargetPayload || selectedRows.length === 0
                ? styles.disabledButton
                : null),
            }}
            onClick={onAssignSelectedRows}
            disabled={!selectedTargetPayload || selectedRows.length === 0}
          >
            Assign Selected Rows
          </button>
        </div>
      </div>

      {statusMessage ? <div style={styles.statusMessage}>{statusMessage}</div> : null}

      {filteredRows.length === 0 ? (
        <div style={styles.emptyState}>No rows match this allocation filter.</div>
      ) : (
        <>
          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <Th>
                    <input
                      type="checkbox"
                      aria-label="Select all visible rows"
                      checked={allVisibleSelected}
                      onChange={onToggleAllVisibleRows}
                    />
                  </Th>
                  <Th>Row No</Th>
                  <Th>Meter No</Th>
                  <Th>Address</Th>
                  <Th>Town</Th>
                  <Th>AST Exists?</Th>
                  <Th>Proposed TRN</Th>
                  <Th>Current Allocation</Th>
                  <Th>TRN Created?</Th>
                </tr>
              </thead>
              <tbody>
                {pagedRows.map((row, index) => {
                  const allocation =
                    allocationsByRowId[row._rowKey] || row._backendAllocation;
                  const trnCreated = hasCreatedTrn(row);
                  const proposedTrn = getProposedTrnType(row);
                  const astStatus = getAstMatchStatus(row);

                  return (
                    <tr key={row._rowKey}>
                      <Td>
                        <input
                          type="checkbox"
                          aria-label={`Select row ${row.rowNo || index + 1}`}
                          checked={selectedRowSet.has(row._rowKey)}
                          onChange={() => onToggleRow(row._rowKey)}
                          disabled={trnCreated}
                        />
                      </Td>
                      <Td strong>{row.rowNo || index + 1}</Td>
                      <Td strong>{row.meterNo || "NAv"}</Td>
                      <Td>{row.addressLine1 || "NAv"}</Td>
                      <Td>{row.town || "NAv"}</Td>
                      <Td>
                        <Badge tone={astStatus === "MATCHED" ? "success" : astStatus === "NOT_MATCHED" ? "warning" : "neutral"}>
                          {astStatus === "MATCHED" ? "TRUE" : astStatus === "NOT_MATCHED" ? "FALSE" : "NOT CHECKED"}
                        </Badge>
                      </Td>
                      <Td>
                        <Badge tone={proposedTrn === "METER_DISCOVERY" ? "info" : proposedTrn === "METER_INSPECTION" ? "success" : "neutral"}>
                          {proposedTrn}
                        </Badge>
                      </Td>
                      <Td>
                        {allocation ? (
                          <div style={styles.allocationCell}>
                            <Badge tone="success">
                              {previewMode && allocation.source !== "BACKEND"
                                ? "PREVIEW_ASSIGNED"
                                : "ALLOCATED"}
                            </Badge>
                            <span style={{
                              ...styles.allocationTargetPill,
                              ...(allocation.type === "TEAM"
                                ? styles.allocationTargetPillTeam
                                : styles.allocationTargetPillSp),
                            }}>
                              {getTargetLabel(allocation)}
                            </span>
                          </div>
                        ) : (
                          <Badge tone="warning">NOT_ALLOCATED</Badge>
                        )}
                      </Td>
                      <Td>
                        <Badge tone={trnCreated ? "success" : "neutral"}>
                          {trnCreated ? "TRUE" : "FALSE"}
                        </Badge>
                        {trnCreated ? (
                          <div style={styles.trnIdText}>{getTrnId(row)}</div>
                        ) : null}
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div style={styles.paginationBar}>
            <span>
              Showing {pageBounds.displayStart}–{pageBounds.displayEnd} of{" "}
              {filteredRows.length} rows
            </span>
            <div style={styles.paginationControls}>
              <button type="button" style={styles.paginationButton} onClick={onFirstPage} disabled={pageBounds.safePageIndex === 0}>First</button>
              <button type="button" style={styles.paginationButton} onClick={onPreviousPage} disabled={pageBounds.safePageIndex === 0}>Previous</button>
              <strong>Page {pageBounds.safePageIndex + 1} of {pageBounds.pageCount}</strong>
              <button type="button" style={styles.paginationButton} onClick={onNextPage} disabled={pageBounds.safePageIndex >= pageBounds.pageCount - 1}>Next</button>
              <button type="button" style={styles.paginationButton} onClick={onLastPage} disabled={pageBounds.safePageIndex >= pageBounds.pageCount - 1}>Last</button>
            </div>
          </div>
        </>
      )}
    </section>
  );
}
