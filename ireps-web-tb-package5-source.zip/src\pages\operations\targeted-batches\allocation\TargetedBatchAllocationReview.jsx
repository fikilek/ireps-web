/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import styles from "./targetedBatchAllocationStyles";
import { Badge, Td, Th } from "./TargetedBatchAllocationPrimitives";
import { getTargetLabel } from "./targetedBatchAllocationUtils";

export default function TargetedBatchAllocationReview({
  rows,
  allocatedGroupCount,
  allocatedRowCount,
  unallocatedGroupCount,
  onClearGroup,
}) {
  return (
    <>
      <section style={styles.panel}>
        <div style={styles.panelHeader}>
          <div>
            <h3 style={styles.panelTitle}>Allocation Review</h3>
            <p style={styles.panelSubtitle}>
              This is the single Targeted Batch allocation truth table for
              allocated, assigned, and waiting work groups.
            </p>
          </div>

          <Badge tone={rows.length > 0 ? "success" : "neutral"}>
            {rows.length} group(s)
          </Badge>
        </div>

        {rows.length === 0 ? (
          <div style={styles.emptyState}>
            No Targeted Batch allocation groups are available yet.
          </div>
        ) : (
          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <Th>TB Allocation</Th>
                  <Th>Work Route</Th>
                  <Th>Rows</Th>
                  <Th>TRNs</Th>
                  <Th>Allocation</Th>
                  <Th>Target</Th>
                  <Th>Status</Th>
                  <Th>Actions</Th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.id}>
                    <Td strong>{row.allocationId}</Td>
                    <Td>{row.groupName}</Td>
                    <Td>{row.rowCount}</Td>
                    <Td>{row.trnCount}</Td>
                    <Td>
                      <Badge
                        tone={
                          row.allocation === "ASSIGNED_NOT_CREATED"
                            ? "success"
                            : "warning"
                        }
                      >
                        {row.allocation}
                      </Badge>
                    </Td>
                    <Td>
                      {row.target ? getTargetLabel(row.target) : "NAv"}
                    </Td>
                    <Td>
                      <Badge
                        tone={
                          row.status === "READY_TO_CREATE"
                            ? "success"
                            : "warning"
                        }
                      >
                        {row.status}
                      </Badge>
                    </Td>
                    <Td>
                      {row.target ? (
                        <button
                          type="button"
                          style={styles.clearAssignmentButton}
                          onClick={() => onClearGroup(row.groupId)}
                        >
                          Clear
                        </button>
                      ) : (
                        "NAv"
                      )}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section style={styles.createPanel}>
        <div>
          <h3 style={styles.panelTitle}>Create Targeted Batch TRNs</h3>
          <p style={styles.panelSubtitle}>
            Allocated groups may proceed when backend Targeted Batch validation,
            allocation persistence, and controlled TRN origination are connected.
            Unallocated groups remain available for later allocation.
          </p>
          <div style={styles.createMetrics}>
            <span>{allocatedGroupCount} allocated group(s)</span>
            <span>{allocatedRowCount} allocated row(s)</span>
            <span>{unallocatedGroupCount} waiting group(s)</span>
          </div>
        </div>

        <button
          type="button"
          style={{ ...styles.createButton, ...styles.disabledButton }}
          disabled
          title="Backend Targeted Batch allocation and TRN origination are not connected yet."
        >
          Create Targeted Batch TRNs
        </button>
      </section>
    </>
  );
}
