/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import styles from "./targetedBatchAllocationStyles";
import { Badge } from "./TargetedBatchAllocationPrimitives";
import {
  asArray,
  getTargetOptionMicroText,
  getTargetOptionSubtitle,
  getUserDisplayName,
  getUserRoleLabel,
} from "./targetedBatchAllocationUtils";

function MembersList({ target, maxItems = 4 }) {
  const members = asArray(target?.members);

  if (members.length === 0) {
    return (
      <div style={styles.memberEmpty}>
        {target?.type === "TEAM"
          ? "No team members resolved yet."
          : "No SP members resolved yet."}
      </div>
    );
  }

  const visibleMembers = members.slice(0, maxItems);
  const hiddenCount = Math.max(members.length - visibleMembers.length, 0);

  return (
    <div style={styles.memberList}>
      {visibleMembers.map((member) => (
        <span
          key={member.id || member.uid || getUserDisplayName(member)}
          style={{
            ...styles.memberChip,
            ...(member.missing ? styles.memberChipWarning : null),
          }}
          title={getUserRoleLabel(member)}
        >
          <strong>{getUserDisplayName(member)}</strong>
          <small>{getUserRoleLabel(member)}</small>
        </span>
      ))}

      {hiddenCount > 0 ? (
        <span style={styles.memberMore}>+{hiddenCount} more</span>
      ) : null}
    </div>
  );
}

export default function TargetedBatchAllocationTargetPanel({
  targetType,
  targetId,
  targetOptions,
  onTargetTypeChange,
  onSelectTarget,
  onTargetDragStart,
  onTargetDragEnd,
}) {
  return (
    <section style={styles.panel}>
      <div style={styles.panelHeader}>
        <div>
          <h3 style={styles.panelTitle}>Targeted Batch Target Setup</h3>
          <p style={styles.panelSubtitle}>
            Select or drag an available TEAM or SUBC SP. Drop it onto the
            Targeted Batch work group you want to allocate. Targeted Batch work
            remains collective work, so individual USER/FWR targeting stays
            outside this flow.
          </p>
        </div>

        <Badge tone={targetOptions.length > 0 ? "success" : "warning"}>
          {targetOptions.length} {targetType}(s)
        </Badge>
      </div>

      <div style={styles.targetToggleRow}>
        <button
          type="button"
          style={{
            ...styles.targetToggleButton,
            ...(targetType === "TEAM" ? styles.targetToggleActive : null),
          }}
          onClick={() => onTargetTypeChange("TEAM")}
        >
          TEAM
        </button>

        <button
          type="button"
          style={{
            ...styles.targetToggleButton,
            ...(targetType === "SP" ? styles.targetToggleActive : null),
          }}
          onClick={() => onTargetTypeChange("SP")}
        >
          SP
        </button>
      </div>

      {targetOptions.length === 0 ? (
        <div style={styles.emptyState}>
          No active {targetType === "TEAM" ? "teams" : "SUBC service providers"}{" "}
          found yet.
        </div>
      ) : (
        <div style={styles.targetOptionList}>
          {targetOptions.map((target) => {
            const selected = target.id === targetId;

            return (
              <button
                key={`${target.type}_${target.id}`}
                type="button"
                draggable
                style={{
                  ...styles.targetOptionCard,
                  ...(selected ? styles.targetOptionCardActive : null),
                }}
                onClick={() => onSelectTarget(target)}
                onDragStart={(event) => onTargetDragStart(event, target)}
                onDragEnd={onTargetDragEnd}
                title={`Select or drag ${target.type} ${target.name} onto a Targeted Batch work group`}
              >
                <div style={styles.targetOptionHeader}>
                  <span style={styles.targetType}>{target.type}</span>
                  <strong style={styles.targetTitle}>{target.name}</strong>
                </div>
                <p style={styles.targetSub}>{getTargetOptionSubtitle(target)}</p>
                <MembersList target={target} maxItems={4} />
                <span style={styles.targetMicro}>
                  {getTargetOptionMicroText(target)}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}
