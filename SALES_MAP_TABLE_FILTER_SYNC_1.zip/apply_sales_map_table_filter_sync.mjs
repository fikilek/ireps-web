import fs from "node:fs";
import path from "node:path";

const repoRoot = path.resolve(process.argv[2] || process.cwd());

const tablePath = path.join(
  repoRoot,
  "src",
  "pages",
  "sales",
  "components",
  "SalesMetersTable.jsx",
);

const mapPath = path.join(
  repoRoot,
  "src",
  "pages",
  "sales",
  "components",
  "SalesGpsMapSection.jsx",
);

for (const filePath of [tablePath, mapPath]) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Required file not found: ${filePath}`);
  }
}

function normalizeLf(value) {
  return String(value).replace(/\r\n/g, "\n");
}

function restoreLineEndings(value, original) {
  return original.includes("\r\n") ? value.replace(/\n/g, "\r\n") : value;
}

function replaceOnce(text, search, replacement, label) {
  const first = text.indexOf(search);

  if (first < 0) {
    throw new Error(`${label}: anchor not found. No files were written.`);
  }

  const second = text.indexOf(search, first + search.length);

  if (second >= 0) {
    throw new Error(
      `${label}: anchor occurred more than once. No files were written.`,
    );
  }

  return text.slice(0, first) + replacement + text.slice(first + search.length);
}

function replaceRegexOnce(text, pattern, replacement, label) {
  const matches = [...text.matchAll(new RegExp(pattern.source, pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`))];

  if (matches.length !== 1) {
    throw new Error(
      `${label}: expected exactly one match but found ${matches.length}. No files were written.`,
    );
  }

  return text.replace(pattern, replacement);
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function patchMapFile(source) {
  let text = normalizeLf(source);

  if (
    text.includes("onSelectedGeofenceIdChange") &&
    !text.includes('const [selectedGeofenceId, setSelectedGeofenceId] = useState("");')
  ) {
    return text;
  }

  const oldSignature = `export default function SalesGpsMapSection({
  rows = [],
  wardOptions = [],
  selectedWardNo = "",
  onSelectedWardNoChange,
}) {`;

  const newSignature = `export default function SalesGpsMapSection({
  rows = [],
  wardOptions = [],
  selectedWardNo = "",
  selectedGeofenceId = "",
  onSelectedWardNoChange,
  onSelectedGeofenceIdChange,
}) {`;

  text = replaceOnce(
    text,
    oldSignature,
    newSignature,
    "Sales GPS map controlled prop signature",
  );

  text = replaceOnce(
    text,
    '  const [selectedGeofenceId, setSelectedGeofenceId] = useState("");\n',
    "",
    "Sales GPS map internal Geofence state removal",
  );

  const oldActiveBlock = `  const activeSelectedGeofenceId = wardGeofences.some(
    (geofence) => geofence?.id === selectedGeofenceId,
  )
    ? selectedGeofenceId
    : "";

  const selectedGeofence =
    wardGeofences.find(
      (geofence) => geofence?.id === activeSelectedGeofenceId,
    ) || null;`;

  const newActiveBlock = `  const hasNoGeofenceSelected = selectedGeofenceId === "NONE";

  const activeSelectedGeofenceId = hasNoGeofenceSelected
    ? "NONE"
    : wardGeofences.some(
          (geofence) => geofence?.id === selectedGeofenceId,
        )
      ? selectedGeofenceId
      : "";

  const selectedGeofence =
    activeSelectedGeofenceId && activeSelectedGeofenceId !== "NONE"
      ? wardGeofences.find(
          (geofence) => geofence?.id === activeSelectedGeofenceId,
        ) || null
      : null;`;

  text = replaceOnce(
    text,
    oldActiveBlock,
    newActiveBlock,
    "Sales GPS map active Geofence derivation",
  );

  const oldRowsBlock = `  const mapRows = useMemo(() => {
    if (!activeSelectedGeofenceId) return rows;

    return rows.filter((row) =>
      getRowGeofenceRefs(row).some(
        (ref) => ref?.id === activeSelectedGeofenceId,
      ),
    );
  }, [activeSelectedGeofenceId, rows]);`;

  const newRowsBlock = `  const mapRows = useMemo(() => {
    if (!activeSelectedGeofenceId) return rows;

    if (activeSelectedGeofenceId === "NONE") {
      return rows.filter((row) => getRowGeofenceRefs(row).length === 0);
    }

    return rows.filter((row) =>
      getRowGeofenceRefs(row).some(
        (ref) => ref?.id === activeSelectedGeofenceId,
      ),
    );
  }, [activeSelectedGeofenceId, rows]);`;

  text = replaceOnce(
    text,
    oldRowsBlock,
    newRowsBlock,
    "Sales GPS map No Geofence filtering",
  );

  text = replaceOnce(
    text,
    `                onChange={(event) =>
                  setSelectedGeofenceId(event.target.value)
                }`,
    `                onChange={(event) =>
                  onSelectedGeofenceIdChange?.(event.target.value)
                }`,
    "Sales GPS map Geofence callback",
  );

  text = replaceOnce(
    text,
    `                </option>
                {wardGeofences.map((geofence) => (`,
    `                </option>
                <option value="NONE">No geofence</option>
                {wardGeofences.map((geofence) => (`,
    "Sales GPS map No Geofence option",
  );

  text = replaceOnce(
    text,
    `              onChange={(event) => {
                setSelectedGeofenceId("");
                onSelectedWardNoChange?.(event.target.value);
              }}`,
    `              onChange={(event) => {
                onSelectedGeofenceIdChange?.("");
                onSelectedWardNoChange?.(event.target.value);
              }}`,
    "Sales GPS map Ward callback",
  );

  text = replaceOnce(
    text,
    `          {activeSelectedGeofenceId && !hasSelectedGeofence ? (`,
    `          {activeSelectedGeofenceId &&
          activeSelectedGeofenceId !== "NONE" &&
          !hasSelectedGeofence ? (`,
    "Sales GPS map unavailable Geofence warning",
  );

  text = replaceOnce(
    text,
    `              {hasSelectedGeofence
                ? \`No usable Sales GPS meters were found in \${selectedGeofenceName}.\`
                : \`No usable GPS meters were found for Ward \${selectedWardNo}.\`}`,
    `              {hasSelectedGeofence
                ? \`No usable Sales GPS meters were found in \${selectedGeofenceName}.\`
                : hasNoGeofenceSelected
                  ? "No usable Sales GPS meters without a geofence were found in this ward."
                  : \`No usable GPS meters were found for Ward \${selectedWardNo}.\`}`,
    "Sales GPS map empty-state message",
  );

  text = replaceOnce(
    text,
    `              {hasSelectedGeofence
                ? \` · \${selectedGeofenceName}: polygon loaded\`
                : ""}`,
    `              {hasSelectedGeofence
                ? \` · \${selectedGeofenceName}: polygon loaded\`
                : hasNoGeofenceSelected
                  ? " · No geofence"
                  : ""}`,
    "Sales GPS map footer Geofence state",
  );

  return text;
}

function patchTableFile(source) {
  let text = normalizeLf(source);

  if (
    text.includes("onSelectedGeofenceIdChange") &&
    text.includes('function updateWardFilter(value) {')
  ) {
    return text;
  }

  if (!text.includes("SalesGpsMapSection")) {
    throw new Error(
      "SalesMetersTable does not contain the existing Sales GPS map integration. No files were written.",
    );
  }

  if (!text.includes('geofenceId: "ALL"')) {
    throw new Error(
      "SalesMetersTable does not contain the approved Geofence table filter. No files were written.",
    );
  }

  const updateFilterBlock = `  function updateFilter(key, value) {
    setCurrentPage(1);
    setFilters((current) => ({ ...current, [key]: value }));
  }`;

  const updateFilterReplacement = `  function updateFilter(key, value) {
    setCurrentPage(1);
    setFilters((current) => ({ ...current, [key]: value }));
  }

  function updateWardFilter(value) {
    setCurrentPage(1);
    setFilters((current) => ({
      ...current,
      wardNo: value,
      geofenceId: "ALL",
    }));
  }

  function updateGeofenceFilter(value) {
    updateFilter("geofenceId", value);
  }`;

  text = replaceOnce(
    text,
    updateFilterBlock,
    updateFilterReplacement,
    "Sales table shared Ward and Geofence handlers",
  );

  text = replaceRegexOnce(
    text,
    /value=\{filters\.wardNo\}\s+onChange=\{\(event\) =>\s*updateFilter\("wardNo", event\.target\.value\)\s*\}/,
    `value={filters.wardNo}
                    onChange={(event) =>
                      updateWardFilter(event.target.value)
                    }`,
    "Sales table Ward dropdown synchronization",
  );

  text = replaceRegexOnce(
    text,
    /value=\{filters\.geofenceId\}\s+onChange=\{\(event\) =>\s*updateFilter\("geofenceId", event\.target\.value\)\s*\}/,
    `value={filters.geofenceId}
                    onChange={(event) =>
                      updateGeofenceFilter(event.target.value)
                    }`,
    "Sales table Geofence dropdown synchronization",
  );

  const mapMatch = text.match(/<SalesGpsMapSection[\s\S]*?\/>/);

  if (!mapMatch) {
    throw new Error(
      "SalesMetersTable map component invocation was not found. No files were written.",
    );
  }

  let mapInvocation = mapMatch[0];

  const wardPropMatch = mapInvocation.match(
    /selectedWardNo=\{([A-Za-z_$][\w$]*)\}/,
  );
  const wardCallbackMatch = mapInvocation.match(
    /onSelectedWardNoChange=\{([A-Za-z_$][\w$]*)\}/,
  );

  if (!wardPropMatch || !wardCallbackMatch) {
    throw new Error(
      "SalesMetersTable map Ward state props were not in the expected form. No files were written.",
    );
  }

  const localWardStateName = wardPropMatch[1];
  const localWardSetterName = wardCallbackMatch[1];

  mapInvocation = mapInvocation.replace(
    /selectedWardNo=\{[A-Za-z_$][\w$]*\}/,
    'selectedWardNo={filters.wardNo === "ALL" ? "" : filters.wardNo}',
  );

  mapInvocation = mapInvocation.replace(
    /onSelectedWardNoChange=\{[A-Za-z_$][\w$]*\}/,
    `selectedGeofenceId={
                  filters.geofenceId === "ALL" ? "" : filters.geofenceId
                }
                onSelectedWardNoChange={(wardNo) =>
                  updateWardFilter(wardNo || "ALL")
                }
                onSelectedGeofenceIdChange={(geofenceId) =>
                  updateGeofenceFilter(geofenceId || "ALL")
                }`,
  );

  text = text.replace(mapMatch[0], mapInvocation);

  const statePattern = new RegExp(
    `\\s*const \\[${escapeRegExp(localWardStateName)},\\s*${escapeRegExp(localWardSetterName)}\\] = useState\\(""\\);\\n`,
  );

  const stateMatches = text.match(statePattern);

  if (!stateMatches) {
    throw new Error(
      `Could not remove obsolete map Ward state ${localWardStateName}. No files were written.`,
    );
  }

  text = text.replace(statePattern, "\n");

  const oldToggleReset =
    '        geofenceId: columnKey === "geofence" ? "ALL" : current.geofenceId,';

  if (text.includes(oldToggleReset)) {
    text = text.replace(
      oldToggleReset,
      `        geofenceId:
          columnKey === "wardNo" || columnKey === "geofence"
            ? "ALL"
            : current.geofenceId,`,
    );
  }

  return text;
}

const tableOriginal = fs.readFileSync(tablePath, "utf8");
const mapOriginal = fs.readFileSync(mapPath, "utf8");

const tablePatchedLf = patchTableFile(tableOriginal);
const mapPatchedLf = patchMapFile(mapOriginal);

if (tablePatchedLf === normalizeLf(tableOriginal) &&
    mapPatchedLf === normalizeLf(mapOriginal)) {
  console.log("Sales map/table Ward and Geofence synchronization is already installed.");
  process.exit(0);
}

const tablePatched = restoreLineEndings(tablePatchedLf, tableOriginal);
const mapPatched = restoreLineEndings(mapPatchedLf, mapOriginal);

const tableTemp = `${tablePath}.sync-temp`;
const mapTemp = `${mapPath}.sync-temp`;

fs.writeFileSync(tableTemp, tablePatched, "utf8");
fs.writeFileSync(mapTemp, mapPatched, "utf8");

fs.renameSync(tableTemp, tablePath);
fs.renameSync(mapTemp, mapPath);

console.log("");
console.log("SALES MAP/TABLE FILTER SYNC APPLIED");
console.log(`Updated: ${path.relative(repoRoot, tablePath)}`);
console.log(`Updated: ${path.relative(repoRoot, mapPath)}`);
console.log("");
console.log("Synchronized:");
console.log("- Table Ward -> Map Ward");
console.log("- Map Ward -> Table Ward");
console.log("- Table Geofence -> Map Geofence");
console.log("- Map Geofence -> Table Geofence");
console.log("- Ward changes reset Geofence to All geofences");
console.log("- No geofence is supported on both table and map");
