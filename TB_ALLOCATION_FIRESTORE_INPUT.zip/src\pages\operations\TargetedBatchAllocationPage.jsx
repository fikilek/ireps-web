/* eslint-disable no-unused-vars -- JSX component tags are reported as unused by this project ESLint config. */
import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import { useGetAvailableTeamsQuery } from "../../redux/teamsApi";
import { useGetAvailableServiceProvidersQuery } from "../../redux/serviceProvidersApi";
import { useGetUsersDirectoryQuery } from "../../redux/usersApi";
import {
  TARGETED_BATCH_DRAFT_STATUSES,
  TARGETED_BATCH_SOURCE_TYPES,
} from "../../redux/targetedBatchDraftModel";
import {
  applyTargetedBatchDraftAllocations,
  clearTargetedBatchDraftAllocations,
} from "../../redux/targetedBatchDraftSlice";
import {
  formatDateTime,
  formatNumber,
} from "./targeted-batches/targetedBatchUtils";
import TargetedBatchAllocationTargetPanel from "./targeted-batches/allocation/TargetedBatchAllocationTargetPanel";
import TargetedBatchAllocationGroupPanel from "./targeted-batches/allocation/TargetedBatchAllocationGroupPanel";
import TargetedBatchAllocationRowsPanel from "./targeted-batches/allocation/TargetedBatchAllocationRowsPanel";
import TargetedBatchAllocationReview from "./targeted-batches/allocation/TargetedBatchAllocationReview";
import {
  Badge,
  InfoCard,
  SummaryDetailRow,
} from "./targeted-batches/allocation/TargetedBatchAllocationPrimitives";
import styles from "./targeted-batches/allocation/targetedBatchAllocationStyles";
import {
  applyAllocationSearch,
  applyQuickFilter,
  asArray,
  buildAllocationReviewRows,
  buildTargetPayload,
  buildUsersById,
  canAllocateRow,
  enrichServiceProvidersWithMembers,
  enrichTeamsWithMembers,
  getBackendAllocation,
  getPageBounds,
  getRowKey,
  getRowOutcome,
  getTargetLabel,
  getTbRowId,
} from "./targeted-batches/allocation/targetedBatchAllocationUtils";

export default function TargetedBatchAllocationPage() {
  const { tbId } = useParams();
  const dispatch = useDispatch();
  const draft = useSelector((state) => state.targetedBatchDraft?.draft || null);

  const [targetType, setTargetType] = useState("TEAM");
  const [targetId, setTargetId] = useState("");
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [activeFilter, setActiveFilter] = useState("ALL");
  const [rowSearch, setRowSearch] = useState("");
  const [pageSize, setPageSize] = useState(25);
  const [pageIndex, setPageIndex] = useState(0);
  const [statusMessage, setStatusMessage] = useState("");

  const decodedTbId = decodeURIComponent(tbId || "");
  const draftMatchesRoute = draft?.id === decodedTbId;
  const sourceType = draft?.source?.type || draft?.sourceType || "";
  const isSalesSource =
    sourceType === TARGETED_BATCH_SOURCE_TYPES.PREPAID_SALES;
  const isConfirmed =
    draft?.status === TARGETED_BATCH_DRAFT_STATUSES.READY_FOR_BACKEND;

  const rows = useMemo(
    () =>
      draftMatchesRoute
        ? asArray(draft?.displayRows || draft?.rows).map((row, index) => ({
            ...row,
            _rowKey: getRowKey(row, index, draft?.id || decodedTbId),
            _rowOutcome: getRowOutcome(row, sourceType),
            _backendAllocation: getBackendAllocation(row),
          }))
        : [],
    [decodedTbId, draft, draftMatchesRoute, sourceType],
  );

  const allocationRows = useMemo(
    () => rows.filter((row) => row._rowOutcome === "ACCEPT"),
    [rows],
  );

  const allocationsByRowId = useMemo(() => {
    const result = {};
    allocationRows.forEach((row) => {
      if (row._backendAllocation?.id) {
        result[row._rowKey] = row._backendAllocation;
      }
    });
    return result;
  }, [allocationRows]);

  const allocationGroups = useMemo(
    () =>
      buildAllocationReviewRows({
        rows: allocationRows,
        allocationsByRowId,
      }),
    [allocationRows, allocationsByRowId],
  );

  const filteredRows = useMemo(() => {
    const quickFiltered = applyQuickFilter(
      allocationRows,
      activeFilter,
      allocationsByRowId,
    );
    return applyAllocationSearch(quickFiltered, rowSearch);
  }, [activeFilter, allocationRows, allocationsByRowId, rowSearch]);

  const pageBounds = useMemo(
    () =>
      getPageBounds({
        pageIndex,
        pageSize,
        totalRows: filteredRows.length,
      }),
    [filteredRows.length, pageIndex, pageSize],
  );
  const pagedRows = filteredRows.slice(
    pageBounds.startIndex,
    pageBounds.endIndex,
  );

  const selectedRowSet = useMemo(
    () => new Set(selectedRowKeys),
    [selectedRowKeys],
  );
  const selectedRows = useMemo(
    () =>
      allocationRows.filter(
        (row) =>
          selectedRowSet.has(row._rowKey) && canAllocateRow(row, sourceType),
      ),
    [allocationRows, selectedRowSet, sourceType],
  );

  const {
    data: availableTeams = [],
    isLoading: areTeamsLoading,
    isError: areTeamsError,
    error: teamsError,
  } = useGetAvailableTeamsQuery({ limit: 500 });

  const {
    data: availableServiceProviders = [],
    isLoading: areServiceProvidersLoading,
    isError: areServiceProvidersError,
    error: serviceProvidersError,
  } = useGetAvailableServiceProvidersQuery({ limit: 500 });

  const {
    data: usersDirectory = [],
    isLoading: areUsersLoading,
    isError: areUsersError,
    error: usersError,
  } = useGetUsersDirectoryQuery({ limit: 1000 });

  const usersById = useMemo(
    () => buildUsersById(usersDirectory),
    [usersDirectory],
  );
  const availableTeamsWithMembers = useMemo(
    () => enrichTeamsWithMembers(availableTeams, usersById),
    [availableTeams, usersById],
  );
  const availableServiceProvidersWithMembers = useMemo(
    () =>
      enrichServiceProvidersWithMembers(
        availableServiceProviders,
        usersDirectory,
      ),
    [availableServiceProviders, usersDirectory],
  );

  const targetOptions =
    targetType === "SP"
      ? availableServiceProvidersWithMembers
      : availableTeamsWithMembers;
  const selectedTargetOption =
    targetOptions.find((item) => item.id === targetId) || null;
  const selectedTargetPayload = useMemo(
    () => buildTargetPayload(selectedTargetOption),
    [selectedTargetOption],
  );

  const allocatedRowCount = allocationRows.filter((row) =>
    Boolean(allocationsByRowId[row._rowKey]?.id),
  ).length;
  const unallocatedRowCount = Math.max(
    allocationRows.length - allocatedRowCount,
    0,
  );

  const targetContextLoading =
    areTeamsLoading || areServiceProvidersLoading || areUsersLoading;
  const targetContextError =
    areTeamsError || areServiceProvidersError || areUsersError;
  const targetContextErrorMessage =
    teamsError?.message ||
    serviceProvidersError?.message ||
    usersError?.message ||
    teamsError?.data?.message ||
    serviceProvidersError?.data?.message ||
    usersError?.data?.message ||
    "Could not load TEAM/SP allocation targets.";

  function handleTargetTypeChange(nextType) {
    setTargetType(nextType);
    setTargetId("");
    setStatusMessage("");
  }

  function handleSelectTarget(target) {
    const cleanTarget = buildTargetPayload(target);
    if (!cleanTarget) {
      setTargetId("");
      return;
    }

    setTargetType(cleanTarget.type);
    setTargetId(cleanTarget.id);
    setStatusMessage(`${getTargetLabel(cleanTarget)} selected.`);
  }

  function applyTargetToSelectedRows() {
    const cleanTarget = buildTargetPayload(selectedTargetPayload);

    if (!cleanTarget) {
      setStatusMessage("Select a TEAM or Service Provider first.");
      return;
    }

    if (selectedRows.length === 0) {
      setStatusMessage("Select at least one accepted sales row first.");
      return;
    }

    const plannedAt = new Date().toISOString();
    dispatch(
      applyTargetedBatchDraftAllocations({
        tbId: draft.id,
        plannedAt,
        assignments: selectedRows.map((row) => ({
          rowKey: row._rowKey,
          tbRowId: getTbRowId(row),
          target: cleanTarget,
        })),
      }),
    );

    setSelectedRowKeys([]);
    setStatusMessage(
      `${selectedRows.length} accepted sales row(s) assigned to ${getTargetLabel(cleanTarget)} in the frontend allocation plan.`,
    );
  }

  function handleToggleRow(rowKey) {
    const row = allocationRows.find((item) => item._rowKey === rowKey);
    if (!row || !canAllocateRow(row, sourceType)) return;

    setSelectedRowKeys((current) =>
      current.includes(rowKey)
        ? current.filter((item) => item !== rowKey)
        : [...current, rowKey],
    );
  }

  function handleToggleAllVisibleRows() {
    const visibleKeys = pagedRows
      .filter((row) => canAllocateRow(row, sourceType))
      .map((row) => row._rowKey);
    const allSelected =
      visibleKeys.length > 0 &&
      visibleKeys.every((rowKey) => selectedRowSet.has(rowKey));

    setSelectedRowKeys((current) => {
      const next = new Set(current);
      visibleKeys.forEach((rowKey) => {
        if (allSelected) next.delete(rowKey);
        else next.add(rowKey);
      });
      return Array.from(next);
    });
  }

  function handleClearSelectedAllocations() {
    const rowKeys = selectedRows
      .filter((row) => allocationsByRowId[row._rowKey]?.source !== "BACKEND")
      .map((row) => row._rowKey);

    if (rowKeys.length === 0) {
      setStatusMessage("No editable frontend allocations were selected.");
      return;
    }

    dispatch(
      clearTargetedBatchDraftAllocations({
        tbId: draft.id,
        rowKeys,
      }),
    );
    setSelectedRowKeys([]);
    setStatusMessage(`${rowKeys.length} frontend allocation(s) cleared.`);
  }

  function handleClearTargetGroup(group) {
    const rowKeys = asArray(group?.rowReferences).map(
      (reference) => reference.rowKey,
    );
    if (rowKeys.length === 0) return;

    dispatch(
      clearTargetedBatchDraftAllocations({
        tbId: draft.id,
        rowKeys,
      }),
    );
    setSelectedRowKeys((current) =>
      current.filter((rowKey) => !rowKeys.includes(rowKey)),
    );
    setStatusMessage(
      `${getTargetLabel(group.target)} cleared from ${rowKeys.length} frontend row allocation(s).`,
    );
  }

  if (!draftMatchesRoute) {
    return (
      <section style={styles.page}>
        <Link to="/operations/targeted-batches" style={styles.backLink}>
          ← Back to TB Uploads
        </Link>
        <div style={styles.errorNotice}>
          <strong>TB upload not available</strong>
          <p style={styles.noticeText}>
            The requested TB ID is not present in the current Redux draft. This
            frontend stage does not yet reload permanent TB data after a browser
            refresh.
          </p>
        </div>
      </section>
    );
  }

  if (!isSalesSource) {
    return (
      <section style={styles.page}>
        <div style={styles.backRow}>
          <Link to="/operations/targeted-batches" style={styles.backLink}>
            ← Back to TB Uploads
          </Link>
          <Link to="/sales" style={styles.backLink}>
            Open Prepaid Sales
          </Link>
        </div>

        <div style={styles.deferredPanel}>
          <Badge tone="warning">SALES ALLOCATION ONLY</Badge>
          <h2 style={styles.title}>CSV allocation is deferred</h2>
          <p style={styles.subtitle}>
            The current implementation decision is to allocate Targeted Batches
            created from the Prepaid Sales table. The CSV upload remains
            available for file and row assessment, but it does not enter the
            Package 5 allocation workflow yet.
          </p>
          <Link to="/sales" style={styles.primaryLinkButton}>
            Create a Targeted Batch from Prepaid Sales
          </Link>
        </div>
      </section>
    );
  }

  if (!isConfirmed) {
    return (
      <section style={styles.page}>
        <div style={styles.backRow}>
          <Link
            to="/operations/targeted-batches/draft"
            style={styles.backLink}
          >
            ← Back to Draft Review
          </Link>
          <Link to="/sales" style={styles.backLink}>
            Open Prepaid Sales
          </Link>
        </div>

        <div style={styles.deferredPanel}>
          <Badge tone="warning">DRAFT NOT CONFIRMED</Badge>
          <h2 style={styles.title}>Confirm the sales batch before allocation</h2>
          <p style={styles.subtitle}>
            Review the selected sales meters and confirm the frontend draft.
            Allocation begins only after the sales-origin batch is confirmed.
          </p>
          <Link
            to="/operations/targeted-batches/draft"
            style={styles.primaryLinkButton}
          >
            Return to Draft Review
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section style={styles.page}>
      <div style={styles.backRow}>
        <Link
          to={`/operations/targeted-batches/${encodeURIComponent(draft.id)}`}
          style={styles.backLink}
        >
          ← Back to TB Rows
        </Link>

        <Link to="/sales" style={styles.backLink}>
          Open Prepaid Sales
        </Link>
      </div>

      <div style={styles.header}>
        <div>
          <p style={styles.eyebrow}>Prepaid Sales / Targeted Batch / Allocation</p>
          <h2 style={styles.title}>Allocate Selected Sales Meters</h2>
          <p style={styles.subtitle}>
            Choose a TEAM or Service Provider, select the accepted meters from
            this confirmed sales batch, and assign those exact rows. Direct FWR
            allocation is not permitted.
          </p>
        </div>

        <Badge tone="success">PREPAID SALES BATCH</Badge>
      </div>

      <div style={styles.summaryPanel}>
        <div style={styles.summaryMetaColumn}>
          <SummaryDetailRow label="TB ID" value={draft.id} />
          <SummaryDetailRow
            label="Confirmed"
            value={formatDateTime(draft.confirmedAt)}
          />
          <SummaryDetailRow
            label="Source"
            value={draft?.source?.label || "Prepaid Sales"}
          />
        </div>

        <div style={styles.summaryMetricGrid}>
          <InfoCard
            label="LM"
            value={`${draft.lmPcode || "NAv"} · ${draft.lmName || "NAv"}`}
          />
          <InfoCard
            label="Sales Rows"
            value={formatNumber(allocationRows.length)}
          />
          <InfoCard label="Allocated" value={formatNumber(allocatedRowCount)} />
          <InfoCard
            label="Not Allocated"
            value={formatNumber(unallocatedRowCount)}
          />
          <InfoCard
            label="Target Groups"
            value={formatNumber(allocationGroups.length)}
          />
        </div>
      </div>

      <div style={styles.salesFlowBanner}>
        <strong>Sales allocation sequence:</strong>
        <span>1. Choose TEAM or SP</span>
        <span>2. Select accepted sales rows</span>
        <span>3. Assign selected rows</span>
        <span>4. Review the grouped plan</span>
      </div>

      {targetContextLoading ? (
        <div style={styles.notice}>Loading TEAM/SP allocation targets...</div>
      ) : null}

      {targetContextError ? (
        <div style={styles.errorNotice}>{targetContextErrorMessage}</div>
      ) : null}

      <TargetedBatchAllocationTargetPanel
        targetType={targetType}
        targetId={targetId}
        targetOptions={targetOptions}
        selectedTarget={selectedTargetOption}
        onTargetTypeChange={handleTargetTypeChange}
        onSelectTarget={handleSelectTarget}
      />

      <TargetedBatchAllocationRowsPanel
        sourceType={sourceType}
        allocationRows={allocationRows}
        filteredRows={filteredRows}
        pagedRows={pagedRows}
        pageBounds={pageBounds}
        activeFilter={activeFilter}
        rowSearch={rowSearch}
        pageSize={pageSize}
        selectedRowSet={selectedRowSet}
        selectedRows={selectedRows}
        selectedTargetPayload={selectedTargetPayload}
        allocationsByRowId={allocationsByRowId}
        statusMessage={statusMessage}
        onSelectQuickFilter={(nextFilter) => {
          setActiveFilter(nextFilter);
          setPageIndex(0);
        }}
        onRowSearchChange={(value) => {
          setRowSearch(value);
          setPageIndex(0);
        }}
        onPageSizeChange={(value) => {
          setPageSize(Number(value) || 25);
          setPageIndex(0);
        }}
        onToggleAllVisibleRows={handleToggleAllVisibleRows}
        onToggleRow={handleToggleRow}
        onClearSelectedAllocations={handleClearSelectedAllocations}
        onAssignSelectedRows={applyTargetToSelectedRows}
        onFirstPage={() => setPageIndex(0)}
        onPreviousPage={() =>
          setPageIndex((current) => Math.max(current - 1, 0))
        }
        onNextPage={() =>
          setPageIndex((current) =>
            Math.min(current + 1, pageBounds.pageCount - 1),
          )
        }
        onLastPage={() => setPageIndex(pageBounds.pageCount - 1)}
      />

      <TargetedBatchAllocationGroupPanel
        groups={allocationGroups}
        onClearTarget={handleClearTargetGroup}
      />

      <TargetedBatchAllocationReview
        rows={allocationGroups}
        acceptedRowCount={formatNumber(allocationRows.length)}
        allocatedRowCount={formatNumber(allocatedRowCount)}
        unallocatedRowCount={formatNumber(unallocatedRowCount)}
      />
    </section>
  );
}
